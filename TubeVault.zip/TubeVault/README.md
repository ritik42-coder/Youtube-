# TubeVault
Native Android (Kotlin + Jetpack Compose, no WebView) YouTube downloader.
1. Create a GitHub repo, upload everything in this folder (keep `.github/workflows/build.yml`) - or upload the zip itself.
2. Open Actions -> "Build TubeVault APK" -> Run workflow (it also runs on every push).
3. Download the `TubeVault-APK` artifact -> TubeVault.apk -> install.
Only download videos you own or have permission to save.

## What's new (premium UI pass)
- Cinematic intro (tap to skip), live background: data-stream rain that speeds up while downloading, tilt parallax, tint taken from the video thumbnail, shock-wave on completion.
- Download start: glowing orb flies from the button into the Library tab (+ haptics). Completion: confetti banner, self-drawing check, card glow.
- Premium progress: ring on thumbnail, liquid bar, 4-stage tracker, live speed graph, ETA.
- Features: clipboard link detection, one-tap Best video / Best audio, Vault stats + rank, search & filters, Settings (Wi-Fi only, live background, haptics).

## What's new (in-app player)
Tap **Play** (or the thumbnail) on any finished download - it opens inside TubeVault, no external app.
- **Speed** 0.25x - 8x: animated gauge, log-scale glow slider, 14 presets, -/+ 0.05 fine-tune, **custom input** (0.1x - 8x), natural-pitch switch. Hold the screen = temporary 2x.
- **Animated seek bar**: gradient + moving shimmer, buffered track, comet-tail sparks, pulsing thumb, springy time bubble, haptic ticks.
- **Gestures**: double-tap left/right = -/+10s (stacking ripple), double-tap centre = play/pause, swipe left/right = seek, swipe up/down on left = brightness, right = volume (up to 200% boost).
- **Sound**: volume + boost, mute, brightness panel.
- **More**: loop, Fit/Zoom/Stretch, sleep timer (15/30/60), lock screen, rotate, pop-out (Picture-in-Picture, also auto when you swipe home).
- Audio files get a spinning vinyl + live equaliser stage that follows the speed. Resume where you left off, queue with prev/next + auto-next.

## Version 2.0 - music studio
- **Background music**: songs keep playing with the screen off / app closed, with lock-screen + notification controls (play, next, previous, seek).
- **Dynamic island**: a floating pill with spinning art + live mini bars while music plays; tap to expand (seek, prev/play/next), tap art to open the full player, X to stop.
- **Real visualizer**: bars / ring / wave driven by the actual audio spectrum, kick-reactive vinyl, glow and a VU meter.
- **Playlists**: Library -> Lists. Create playlists, Favourites (heart), Play all / Shuffle, queue panel, "save queue as playlist".
- **Sound Lab**: 10 presets, 5-band EQ, bass boost, 3D width, reverb, echo, 8D spin, DJ filter, hold-to-play DJ pads (Bass drop / Echo out / Wash), volume boost up to 200%.

## IMPORTANT - updating without uninstalling
The APK is now signed with ONE permanent key: `app/tubevault-release.jks`.
1. Keep that file in your GitHub repo forever. Never delete or replace it.
2. Android only lets an APK install over an older one if both use the same key.
   Old builds used a random key made fresh on every GitHub build, which is why you had to uninstall.
3. **One last time**: uninstall the old build, then install this one. From now on every new build installs as an update and keeps your downloads and playlists.
4. Your files stay in Movies/TubeVault and Music/TubeVault. After reinstalling, allow the "Music and audio / Photos and videos" permission and the app puts them back in the Library automatically.

## Version 2.1
- **Floating island over other apps** (Settings -> "Island over other apps", OFF by default). Turning it on opens Android's "display over other apps" screen; allow TubeVault there. The island appears only while you are outside the app and music is loaded. Tap = expand (seek, prev/play/next, open app, close).
- **Notification controller** with its own "TubeVault music player" channel and music icon, plus lock-screen controls.
- **Album colours**: the player, visualizer, island glow and overlay take their colours from the song's artwork.
- **Smart mixes** in Lists: Recently added, Most played, Recently played.
- **Sleep timer** now works with the screen off and fades the music out over the last 15 seconds (5 / 15 / 30 / 60 / 90 min).
- **A-B repeat**: loop any part of a song or video.

## Version 2.2 - Karaoke mode
Open any song -> tap the **mic** button (bottom row) or More -> Karaoke.
- **Create lyrics with Whisper**: the song is transcribed on your phone (nothing is uploaded) and every word gets a time, so lyrics scroll in sync. First time it downloads a speech model once (Fast ~31 MB, Balanced ~57 MB, Best ~181 MB), then it works offline. Pick the song's language yourself for better accuracy. Lyrics are saved, so a song is only processed once.
- Optional **Find synced lyrics online** (LRCLIB) sends the song title to lrclib.net and is usually more accurate than transcribing, when the song is listed there.
- The stage: lyrics glide up, the line being sung is big with a soft light sweeping across each word, finished lines float up, blur and vanish, next lines wait below. Intros and long instrumental parts show a count-in "..." . Tap a line to jump to it. Album colours, glow and sparks follow the music.
- **Lyrics timing** (+ / -) fixes small delays (for example Bluetooth earphones).
- Build note: the workflow downloads whisper.cpp (v1.9.6) and compiles it for 64-bit ARM phones, so the first build takes longer. Keep the `.github/workflows/build.yml` step "Fetch whisper.cpp".

## Version 2.3 - Universal downloader (1,800+ sites)
TubeVault now downloads from almost any video site, not just YouTube. Paste or share any video page link.
- **Two engines**: YouTube links still use NewPipe (fast). Every other link uses **yt-dlp** (the same engine behind most desktop downloaders), bundled inside the app with FFmpeg. If NewPipe ever breaks on a YouTube link, yt-dlp is tried automatically as a backup.
- **Keeps itself working**: yt-dlp updates itself once a day in the background, and again automatically if a site fails, so sites that change their pages keep working without a new APK.
- **Qualities**: every resolution the site offers (up to 4K), saved as MP4 (H.264 + AAC preferred so every phone plays it). **Audio only** saves an M4A.
- **Faster**: HLS sites download 4 pieces at a time, with automatic retries.
- **Clearer errors**: removed, private, paid/login-only, geo-blocked and unsupported links each get a plain message.
- Clipboard detection and the Share menu now accept any video link.
- What it can't do: paid/premium-only videos, DRM-protected streams, live streams that are still running.
- Build note: the APK is bigger now (~40-60 MB) because it carries Python + yt-dlp + FFmpeg for 64-bit ARM. The first link after installing takes a few extra seconds while the engine unpacks.

## Version 2.4 - Private Vault, Save-to choice, no more duplicates
- **Save to (on every download)**: an animated switch above the download buttons.
  - **Private** (default): stays inside TubeVault, hidden from Gallery, Photos and other apps. Note: private files are removed if you uninstall the app.
  - **Gallery**: saved to Movies/TubeVault or Music/TubeVault, like before.
  - **Vault**: encrypted and locked.
  Change the default in Settings -> "Save new downloads to".
- **Private Vault** (lock button in the Library, or long-press the "Library" title):
  - AES-256 encryption. The key is protected by the phone's hardware Keystore, file names are random and even the titles are encrypted.
  - Password/PIN + fingerprint/face unlock. After 5 wrong tries it waits 30 s, after 10 it waits 5 min.
  - Plays videos and songs straight from the encrypted file (seeking works), without writing a decrypted copy.
  - Screenshots and the recent-apps preview are blocked inside the Vault. It locks as soon as you leave the app. Vault songs show only "Private media" on the lock screen and in notifications.
  - Move items out (to Private or Gallery), change password, reset the Vault.
  - "Hide Vault button" in Settings removes the button. Long-press "Library" to open the Vault.
- **Move anything, any time**: tap ⋮ on a Library item -> Save to Gallery / Hide from Gallery / Move to Vault.
- **Fixed: double items** after a restore. Android names the same file two ways (external vs external_primary), so the app now matches files by their media ID and merges existing duplicates automatically.
- **Fixed: black thumbnails after reinstall**: the title, artist and cover art are now written inside every MP4/M4A file. Thumbnails are also saved on the phone. Restored files get their cover from the file, or a frame from the video. Older Gallery songs get their cover written in automatically, once. If nothing is found, a music/video icon shows instead of black.
- **Faster**: a copied link starts loading in the background before you tap, and fetched links are remembered for 15 minutes. YouTube video and audio now download at the same time.

## Version 2.5 - Auto-update (no more sharing APKs)
Every build the workflow makes is also published as a **GitHub Release** (`TubeVault.apk` + `update.json`).
Installed apps read the latest release, show an animated update sheet, download the APK (resumable, size + SHA-256 checked) and install it with one tap.
- **Edit `app/src/main/assets/whatsnew.json` before each release.** Its title, subtitle and highlights appear (1) in the update sheet before installing and (2) as the animated "What's new" screen after the update. Icon names: update, shield, settings, notifications, bolt, music, lock, palette, heart, star, bug, cloud, video, eq, wifi, gauge, spark.
- **Raise `versionName`** in `app/build.gradle.kts` for a new visible version number (the internal versionCode already goes up on every GitHub run).
- **The GitHub repo must be PUBLIC** (the app downloads releases without a login).
- Settings -> App updates: Check now, auto-check on/off, download on Wi-Fi on/off, "See what's new".
- First time only: share this version's APK manually. Every later update arrives by itself.
- Keep `app/tubevault-release.jks` forever: Android only installs an update when the signing key is identical.
