# TubeVault
Native Android (Kotlin + Jetpack Compose, no WebView) YouTube downloader.
1. Create a GitHub repo, upload everything in this folder (keep `.github/workflows/build.yml`) - or upload the zip itself.
2. Open Actions -> "Build TubeVault APK" -> Run workflow (it also runs on every push).
3. Download the `TubeVault-APK` artifact -> TubeVault.apk -> install.
Only download videos you own or have permission to save.

## What's new (premium UI pass)
- Cinematic intro (tap to skip), live background: data-stream rain that speeds up while downloading, tilt parallax, tint taken from the video thumbnail, shock-wave on completion.
- Download start: glowing orb flies from the button into the Library tab (+ haptics). Completion: confetti banner, self-drawing check, card glow.
- Premium progress: ring on thumbnail, liquid bar, 4-stage tracker, live speed graph, ETA.
- Features: clipboard link detection, one-tap Best video / Best audio, Vault stats + rank, search & filters, Settings (Wi-Fi only, live background, haptics).

## What's new (in-app player)
Tap **Play** (or the thumbnail) on any finished download - it opens inside TubeVault, no external app.
- **Speed** 0.25x - 8x: animated gauge, log-scale glow slider, 14 presets, -/+ 0.05 fine-tune, **custom input** (0.1x - 8x), natural-pitch switch. Hold the screen = temporary 2x.
- **Animated seek bar**: gradient + moving shimmer, buffered track, comet-tail sparks, pulsing thumb, springy time bubble, haptic ticks.
- **Gestures**: double-tap left/right = -/+10s (stacking ripple), double-tap centre = play/pause, swipe left/right = seek, swipe up/down on left = brightness, right = volume (up to 200% boost).
- **Sound**: volume + boost, mute, brightness panel.
- **More**: loop, Fit/Zoom/Stretch, sleep timer (15/30/60), lock screen, rotate, pop-out (Picture-in-Picture, also auto when you swipe home).
- Audio files get a spinning vinyl + live equaliser stage that follows the speed. Resume where you left off, queue with prev/next + auto-next.

## Version 2.0 - music studio
- **Background music**: songs keep playing with the screen off / app closed, with lock-screen + notification controls (play, next, previous, seek).
- **Dynamic island**: a floating pill with spinning art + live mini bars while music plays; tap to expand (seek, prev/play/next), tap art to open the full player, X to stop.
- **Real visualizer**: bars / ring / wave driven by the actual audio spectrum, kick-reactive vinyl, glow and a VU meter.
- **Playlists**: Library -> Lists. Create playlists, Favourites (heart), Play all / Shuffle, queue panel, "save queue as playlist".
- **Sound Lab**: 10 presets, 5-band EQ, bass boost, 3D width, reverb, echo, 8D spin, DJ filter, hold-to-play DJ pads (Bass drop / Echo out / Wash), volume boost up to 200%.

## IMPORTANT - updating without uninstalling
The APK is now signed with ONE permanent key: `app/tubevault-release.jks`.
1. Keep that file in your GitHub repo forever. Never delete or replace it.
2. Android only lets an APK install over an older one if both use the same key.
   Old builds used a random key made fresh on every GitHub build, which is why you had to uninstall.
3. **One last time**: uninstall the old build, then install this one. From now on every new build installs as an update and keeps your downloads and playlists.
4. Your files stay in Movies/TubeVault and Music/TubeVault. After reinstalling, allow the "Music and audio / Photos and videos" permission and the app puts them back in the Library automatically.

## Version 2.1
- **Floating island over other apps** (Settings -> "Island over other apps", OFF by default). Turning it on opens Android's "display over other apps" screen; allow TubeVault there. The island appears only while you are outside the app and music is loaded. Tap = expand (seek, prev/play/next, open app, close).
- **Notification controller** with its own "TubeVault music player" channel and music icon, plus lock-screen controls.
- **Album colours**: the player, visualizer, island glow and overlay take their colours from the song's artwork.
- **Smart mixes** in Lists: Recently added, Most played, Recently played.
- **Sleep timer** now works with the screen off and fades the music out over the last 15 seconds (5 / 15 / 30 / 60 / 90 min).
- **A-B repeat**: loop any part of a song or video.
