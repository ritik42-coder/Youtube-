# TubeVault
Native Android (Kotlin + Jetpack Compose, no WebView) YouTube downloader.
1. Create a GitHub repo, upload everything in this folder (keep `.github/workflows/build.yml`) - or upload the zip itself.
2. Open Actions -> "Build TubeVault APK" -> Run workflow (it also runs on every push).
3. Download the `TubeVault-APK` artifact -> TubeVault.apk -> install.
Only download videos you own or have permission to save.

## What's new (premium UI pass)
- Cinematic intro (tap to skip), live background: data-stream rain that speeds up while downloading, tilt parallax, tint taken from the video thumbnail, shock-wave on completion.
- Download start: glowing orb flies from the button into the Library tab (+ haptics). Completion: confetti banner, self-drawing check, card glow.
- Premium progress: ring on thumbnail, liquid bar, 4-stage tracker, live speed graph, ETA.
- Features: clipboard link detection, one-tap Best video / Best audio, Vault stats + rank, search & filters, Settings (Wi-Fi only, live background, haptics).
