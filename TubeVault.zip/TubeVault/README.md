# TubeVault
Native Android (Kotlin + Jetpack Compose, no WebView) YouTube downloader.
1. Create a GitHub repo, upload everything in this folder (keep `.github/workflows/build.yml`) - or upload the zip itself.
2. Open Actions -> "Build TubeVault APK" -> Run workflow (it also runs on every push).
3. Download the `TubeVault-APK` artifact -> TubeVault.apk -> install.
Only download videos you own or have permission to save.
