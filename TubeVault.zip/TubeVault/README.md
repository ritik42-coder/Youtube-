# TubeVault
Native Android (Kotlin + Jetpack Compose, no WebView) YouTube downloader.
1. Create a GitHub repo, upload everything in this folder (keep `.github/workflows/build.yml`) - or upload the zip itself.
2. Open Actions -> "Build TubeVault APK" -> Run workflow (it also runs on every push).
3. Download the `TubeVault-APK` artifact -> TubeVault.apk -> install.
Only download videos you own or have permission to save.

## What's new (premium UI pass)
- Cinematic intro (tap to skip), live background: data-stream rain that speeds up while downloading, tilt parallax, tint taken from the video thumbnail, shock-wave on completion.
- Download start: glowing orb flies from the button into the Library tab (+ haptics). Completion: confetti banner, self-drawing check, card glow.
- Premium progress: ring on thumbnail, liquid bar, 4-stage tracker, live speed graph, ETA.
- Features: clipboard link detection, one-tap Best video / Best audio, Vault stats + rank, search & filters, Settings (Wi-Fi only, live background, haptics).

## What's new (in-app player)
Tap **Play** (or the thumbnail) on any finished download - it opens inside TubeVault, no external app.
- **Speed** 0.25x - 8x: animated gauge, log-scale glow slider, 14 presets, -/+ 0.05 fine-tune, **custom input** (0.1x - 8x), natural-pitch switch. Hold the screen = temporary 2x.
- **Animated seek bar**: gradient + moving shimmer, buffered track, comet-tail sparks, pulsing thumb, springy time bubble, haptic ticks.
- **Gestures**: double-tap left/right = -/+10s (stacking ripple), double-tap centre = play/pause, swipe left/right = seek, swipe up/down on left = brightness, right = volume (up to 200% boost).
- **Sound**: volume + boost, mute, brightness panel.
- **More**: loop, Fit/Zoom/Stretch, sleep timer (15/30/60), lock screen, rotate, pop-out (Picture-in-Picture, also auto when you swipe home).
- Audio files get a spinning vinyl + live equaliser stage that follows the speed. Resume where you left off, queue with prev/next + auto-next.
