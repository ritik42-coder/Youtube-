// JNI bridge between TubeVault (Kotlin) and whisper.cpp.
// It returns the transcript as ONE byte array so that multi-byte (e.g. Devanagari) text is never
// pushed through NewStringUTF in the middle of a character. Format, one record per line:
//   S <TAB> t0 <TAB> t1 <TAB> noSpeechProb*1000
//   T <TAB> tDtw <TAB> t0 <TAB> t1 <TAB> prob*1000 <TAB> raw token bytes
// Times are whisper "centiseconds" (1 unit = 10 ms).
#include <jni.h>
#include <atomic>
#include <string>
#include <vector>
#include <cstring>
#include <cstdio>
#include "whisper.h"

#ifdef __ANDROID__
#include <android/log.h>
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "TubeVaultWhisper", __VA_ARGS__)
#else
#define LOGI(...) do { fprintf(stderr, __VA_ARGS__); fprintf(stderr, "\n"); } while (0)
#endif

static std::atomic<bool> g_abort(false);

struct ProgressCtx {
    JNIEnv *env;
    jobject listener;
    jmethodID method;
    int last;
};

static void on_progress(struct whisper_context *, struct whisper_state *, int progress, void *user) {
    auto *p = static_cast<ProgressCtx *>(user);
    if (!p || !p->listener || !p->method) return;
    if (progress == p->last) return;
    p->last = progress;
    p->env->CallVoidMethod(p->listener, p->method, (jint) progress);
    if (p->env->ExceptionCheck()) p->env->ExceptionClear();
}

static bool on_abort(void *) { return g_abort.load(); }

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_raja_tubevault_core_WhisperNative_nativeInit(JNIEnv *env, jobject, jstring jpath, jint preset) {
    const char *path = env->GetStringUTFChars(jpath, nullptr);
    struct whisper_context_params cp = whisper_context_default_params();
    cp.use_gpu = false;
    // DTW word timing (much better than the default token timing) needs flash attention OFF.
    cp.flash_attn = false;
    cp.dtw_token_timestamps = true;
    switch (preset) {
        case 0: cp.dtw_aheads_preset = WHISPER_AHEADS_TINY; break;
        case 2: cp.dtw_aheads_preset = WHISPER_AHEADS_SMALL; break;
        default: cp.dtw_aheads_preset = WHISPER_AHEADS_BASE; break;
    }
    struct whisper_context *ctx = whisper_init_from_file_with_params(path, cp);
    env->ReleaseStringUTFChars(jpath, path);
    return reinterpret_cast<jlong>(ctx);
}

JNIEXPORT void JNICALL
Java_com_raja_tubevault_core_WhisperNative_nativeFree(JNIEnv *, jobject, jlong handle) {
    auto *ctx = reinterpret_cast<struct whisper_context *>(handle);
    if (ctx) whisper_free(ctx);
}

JNIEXPORT void JNICALL
Java_com_raja_tubevault_core_WhisperNative_nativeAbort(JNIEnv *, jobject, jboolean abort) {
    g_abort.store(abort == JNI_TRUE);
}

JNIEXPORT jbyteArray JNICALL
Java_com_raja_tubevault_core_WhisperNative_nativeTranscribe(
        JNIEnv *env, jobject, jlong handle, jfloatArray jsamples, jstring jlang, jint threads, jobject listener) {
    auto *ctx = reinterpret_cast<struct whisper_context *>(handle);
    if (!ctx) return nullptr;
    g_abort.store(false);

    const jsize n = env->GetArrayLength(jsamples);
    jfloat *samples = env->GetFloatArrayElements(jsamples, nullptr);
    const char *lang = env->GetStringUTFChars(jlang, nullptr);
    std::string language(lang ? lang : "auto");
    if (lang) env->ReleaseStringUTFChars(jlang, lang);

    struct whisper_full_params wp = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    wp.n_threads = threads > 0 ? threads : 4;
    wp.language = language.c_str();
    wp.detect_language = false;
    wp.translate = false;
    wp.print_progress = false;
    wp.print_realtime = false;
    wp.print_special = false;
    wp.print_timestamps = false;
    wp.token_timestamps = true;       // also fills t0/t1 (fallback when DTW is empty)
    wp.no_context = true;             // songs repeat a lot: don't let old text trap the decoder in loops
    wp.suppress_blank = true;
    wp.suppress_nst = true;           // no [MUSIC] / (applause) style tokens
    wp.temperature = 0.0f;
    wp.temperature_inc = 0.2f;
    wp.entropy_thold = 2.4f;
    wp.logprob_thold = -1.0f;
    wp.no_speech_thold = 0.6f;
    wp.abort_callback = on_abort;
    wp.abort_callback_user_data = nullptr;

    ProgressCtx pc{env, nullptr, nullptr, -1};
    if (listener) {
        jclass cls = env->GetObjectClass(listener);
        pc.listener = listener;
        pc.method = env->GetMethodID(cls, "onProgress", "(I)V");
        if (env->ExceptionCheck()) { env->ExceptionClear(); pc.method = nullptr; }
        wp.progress_callback = on_progress;
        wp.progress_callback_user_data = &pc;
    }

    LOGI("transcribing %d samples, lang=%s, threads=%d", (int) n, language.c_str(), wp.n_threads);
    const int rc = whisper_full(ctx, wp, samples, (int) n);
    env->ReleaseFloatArrayElements(jsamples, samples, JNI_ABORT);
    if (rc != 0) {
        LOGI("whisper_full failed: %d", rc);
        return nullptr;
    }

    std::string out;
    const int eot = whisper_token_eot(ctx);
    const int segs = whisper_full_n_segments(ctx);
    char head[160];
    for (int i = 0; i < segs; i++) {
        snprintf(head, sizeof(head), "S\t%lld\t%lld\t%d\n",
                 (long long) whisper_full_get_segment_t0(ctx, i),
                 (long long) whisper_full_get_segment_t1(ctx, i),
                 (int) (whisper_full_get_segment_no_speech_prob(ctx, i) * 1000.f));
        out += head;
        const int nt = whisper_full_n_tokens(ctx, i);
        for (int j = 0; j < nt; j++) {
            whisper_token_data td = whisper_full_get_token_data(ctx, i, j);
            if (td.id >= eot) continue; // timestamp / special tokens
            const char *txt = whisper_full_get_token_text(ctx, i, j);
            if (!txt) continue;
            snprintf(head, sizeof(head), "T\t%lld\t%lld\t%lld\t%d\t",
                     (long long) td.t_dtw, (long long) td.t0, (long long) td.t1, (int) (td.p * 1000.f));
            out += head;
            for (const char *c = txt; *c; ++c) {
                char ch = *c;
                if (ch == '\t' || ch == '\n' || ch == '\r') ch = ' ';
                out.push_back(ch);
            }
            out.push_back('\n');
        }
    }

    jbyteArray arr = env->NewByteArray((jsize) out.size());
    if (arr) env->SetByteArrayRegion(arr, 0, (jsize) out.size(), reinterpret_cast<const jbyte *>(out.data()));
    return arr;
}

} // extern "C"
