cmake_minimum_required(VERSION 3.22.1)
project(tubevault_whisper LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

# whisper.cpp is fetched into ./whisper.cpp by the GitHub workflow (see .github/workflows/build.yml).
# Build it as static libraries so everything ends up inside ONE libtubevault_whisper.so.
set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(WHISPER_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(WHISPER_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(WHISPER_BUILD_SERVER OFF CACHE BOOL "" FORCE)
set(WHISPER_CURL OFF CACHE BOOL "" FORCE)
set(WHISPER_SDL2 OFF CACHE BOOL "" FORCE)
set(GGML_OPENMP OFF CACHE BOOL "" FORCE)
set(GGML_NATIVE OFF CACHE BOOL "" FORCE)
set(GGML_LLAMAFILE OFF CACHE BOOL "" FORCE)

if (NOT EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/whisper.cpp/CMakeLists.txt")
    message(FATAL_ERROR "whisper.cpp source is missing. The GitHub workflow clones it into app/src/main/cpp/whisper.cpp - keep that step.")
endif()
add_subdirectory(whisper.cpp ${CMAKE_CURRENT_BINARY_DIR}/whisper_build)

add_library(tubevault_whisper SHARED whisper_jni.cpp)
target_include_directories(tubevault_whisper PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/whisper.cpp/include)
target_link_libraries(tubevault_whisper PRIVATE whisper)
if (ANDROID)
    target_link_libraries(tubevault_whisper PRIVATE log android)
    # keep the .so small
    target_link_options(tubevault_whisper PRIVATE -Wl,--gc-sections -Wl,-z,max-page-size=16384)
endif()
