package com.raja.tubevault.core

import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

object Errors {
    fun friendly(e: Throwable): String = when {
        e is UnknownHostException -> "No internet connection. Check your network and try again."
        e is SocketTimeoutException -> "The connection timed out. Please try again."
        e is HttpStatusException && e.code == 403 ->
            "YouTube refused this download (403). Tap retry — it usually works on the second try."
        e is HttpStatusException -> "Download failed (${e.message}). Please retry."
        e is IOException && e.message?.contains("ENOSPC") == true -> "Your phone is out of storage space."
        !e.message.isNullOrBlank() -> e.message!!.lineSequence().first().take(200)
        else -> "Something went wrong. Please try again."
    }
}
