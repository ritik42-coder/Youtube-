package com.raja.tubevault.core

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import coil.imageLoader
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Picks two vivid accent colours from a song's artwork so the whole player matches it. */
object AlbumColors {
    private val cache = HashMap<String, Pair<Int, Int>>()

    suspend fun get(ctx: Context, url: String?): Pair<Int, Int>? {
        if (url.isNullOrEmpty()) return null
        cache[url]?.let { return it }
        return withContext(Dispatchers.IO) {
            try {
                val req = ImageRequest.Builder(ctx).data(url).allowHardware(false).size(96).build()
                val d = ctx.imageLoader.execute(req).drawable as? BitmapDrawable ?: return@withContext null
                val small = Bitmap.createScaledBitmap(d.bitmap, 24, 24, true)
                val w = FloatArray(12)
                val sr = FloatArray(12); val sg = FloatArray(12); val sb = FloatArray(12)
                val hsv = FloatArray(3)
                for (y in 0 until 24) for (x in 0 until 24) {
                    val p = small.getPixel(x, y)
                    Color.colorToHSV(p, hsv)
                    if (hsv[2] < 0.2f) continue
                    val weight = hsv[1] * hsv[2] + 0.02f
                    val bin = ((hsv[0] / 30f).toInt()).coerceIn(0, 11)
                    w[bin] += weight
                    sr[bin] += Color.red(p) * weight; sg[bin] += Color.green(p) * weight; sb[bin] += Color.blue(p) * weight
                }
                var best = -1; var second = -1
                for (i in 0 until 12) {
                    if (w[i] <= 0f) continue
                    if (best < 0 || w[i] > w[best]) { second = best; best = i }
                    else if (second < 0 || w[i] > w[second]) second = i
                }
                if (best < 0) return@withContext null
                fun vivid(i: Int): Int {
                    val c = Color.rgb((sr[i] / w[i]).toInt(), (sg[i] / w[i]).toInt(), (sb[i] / w[i]).toInt())
                    val h = FloatArray(3)
                    Color.colorToHSV(c, h)
                    h[1] = h[1].coerceIn(0.55f, 1f)
                    h[2] = h[2].coerceIn(0.85f, 1f)
                    return Color.HSVToColor(h)
                }
                val a = vivid(best)
                val b = if (second >= 0) vivid(second) else {
                    val h = FloatArray(3)
                    Color.colorToHSV(a, h)
                    h[0] = (h[0] + 45f) % 360f
                    Color.HSVToColor(h)
                }
                val r = a to b
                cache[url] = r
                r
            } catch (_: Throwable) {
                null
            }
        }
    }
}
