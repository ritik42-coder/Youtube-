package com.raja.tubevault.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.raja.tubevault.core.DownloadItem
import com.raja.tubevault.core.Playlist
import com.raja.tubevault.core.Playlists

/** Play a list of songs/videos in the in-app player (optionally shuffled). */
fun playQueue(items: List<DownloadItem>, start: Int = 0, shuffle: Boolean = false) {
    if (items.isEmpty()) return
    if (shuffle) PlayerHost.request = PlayRequest(items.shuffled(), 0)
    else PlayerHost.request = PlayRequest(items, start.coerceIn(0, items.lastIndex))
}

/** Round "add to playlist" button for a song card. */
@Composable
fun PlaylistAddButton(item: DownloadItem) {
    var open by remember { mutableStateOf(false) }
    PlayerIconButton(Icons.Rounded.PlaylistAdd, { open = true }, size = 38.dp)
    if (open) AddToPlaylistDialog(item.id) { open = false }
}

@Composable
fun AddToPlaylistDialog(itemId: String, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceDark,
        title = { Text("Add to playlist", color = TextHi, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                Modifier.heightIn(max = 340.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Playlists.all.forEach { p ->
                    val has = itemId in p.ids
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .pressable { if (has) Playlists.remove(p.id, itemId) else Playlists.add(p.id, itemId) }
                            .clip(RoundedCornerShape(16.dp))
                            .background(Glass)
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            if (p.id == Playlists.FAV) Icons.Rounded.Favorite else Icons.Rounded.QueueMusic,
                            null, tint = Pink, modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(p.name, color = TextHi, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${p.ids.size}", color = TextLo, fontSize = 12.sp)
                        Spacer(Modifier.width(8.dp))
                        Icon(
                            if (has) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked, null,
                            tint = if (has) Green else TextLo, modifier = Modifier.size(22.dp)
                        )
                    }
                }
                NameField(name, { name = it }, "New playlist name") {
                    val p = Playlists.create(name)
                    Playlists.add(p.id, itemId)
                    name = ""
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done", color = Pink) } }
    )
}

@Composable
private fun NameField(value: String, onChange: (String) -> Unit, hint: String, onCreate: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(BorderStroke(1.dp, GlassBorder), RoundedCornerShape(16.dp))
            .padding(start = 14.dp, top = 6.dp, bottom = 6.dp, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) Text(hint, color = TextLo, fontSize = 14.sp)
            BasicTextField(
                value = value, onValueChange = { onChange(it.take(40)) }, singleLine = true,
                textStyle = TextStyle(color = TextHi, fontSize = 15.sp), cursorBrush = SolidColor(Pink),
                modifier = Modifier.fillMaxWidth()
            )
        }
        Box(
            Modifier
                .pressable { onCreate() }
                .clip(RoundedCornerShape(50))
                .background(AccentBrush)
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) { Text("Create", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
    }
}

/** "Play all / Shuffle" strip shown above the audio list. */
@Composable
fun AudioActions(songs: List<DownloadItem>) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        PillButton(Icons.Rounded.PlayArrow, "Play all", true) { playQueue(songs) }
        PillButton(Icons.Rounded.Shuffle, "Shuffle", false) { playQueue(songs, shuffle = true) }
    }
}

@Composable
fun PlaylistsTab(library: List<DownloadItem>) {
    var openId by remember { mutableStateOf<String?>(null) }
    var creating by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var deleting by remember { mutableStateOf<Playlist?>(null) }

    AnimatedContent(
        targetState = openId,
        transitionSpec = {
            if (targetState != null)
                (slideInHorizontally(spring(dampingRatio = 0.85f, stiffness = 350f)) { it / 3 } + fadeIn(tween(220))) togetherWith
                    (slideOutHorizontally(tween(200)) { -it / 4 } + fadeOut(tween(150)))
            else
                (slideInHorizontally(spring(dampingRatio = 0.85f, stiffness = 350f)) { -it / 3 } + fadeIn(tween(220))) togetherWith
                    (slideOutHorizontally(tween(200)) { it / 4 } + fadeOut(tween(150)))
        },
        label = "pl"
    ) { id ->
        val pl = Playlists.all.firstOrNull { it.id == id }
        if (id == null || pl == null) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${Playlists.all.size} playlists", color = TextLo, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    PillButton(Icons.Rounded.Add, "New playlist", true) { creating = true }
                }
                Playlists.all.forEach { p ->
                    val songs = Playlists.items(p, library)
                    PlaylistRow(p, songs, onOpen = { openId = p.id }, onPlay = { playQueue(songs) })
                }
            }
        } else {
            val songs = Playlists.items(pl, library)
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PlayerIconButton(Icons.Rounded.KeyboardArrowDown, { openId = null }, size = 40.dp)
                    Column(Modifier.weight(1f)) {
                        Text(pl.name, color = TextHi, fontWeight = FontWeight.Bold, fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${songs.size} song${if (songs.size == 1) "" else "s"}", color = TextLo, fontSize = 13.sp)
                    }
                    if (pl.id != Playlists.FAV) {
                        PlayerIconButton(Icons.Rounded.DeleteOutline, { deleting = pl }, size = 40.dp)
                    }
                }
                if (songs.isEmpty()) {
                    Text(
                        "Empty. Tap the playlist button on any song in All / Audio to add it here.",
                        color = TextLo, fontSize = 14.sp, modifier = Modifier.padding(vertical = 18.dp)
                    )
                } else {
                    AudioActions(songs)
                    songs.forEachIndexed { i, s ->
                        TrackRow(s, onPlay = { playQueue(songs, i) }, onRemove = { Playlists.remove(pl.id, s.id) })
                    }
                }
            }
        }
    }

    if (creating) {
        AlertDialog(
            onDismissRequest = { creating = false },
            containerColor = SurfaceDark,
            title = { Text("New playlist", color = TextHi, fontWeight = FontWeight.Bold) },
            text = {
                NameField(newName, { newName = it }, "Playlist name") {
                    val p = Playlists.create(newName)
                    newName = ""
                    creating = false
                    openId = p.id
                }
            },
            confirmButton = { TextButton(onClick = { creating = false }) { Text("Cancel", color = TextLo) } }
        )
    }
    val d = deleting
    if (d != null) {
        AlertDialog(
            onDismissRequest = { deleting = null },
            containerColor = SurfaceDark,
            title = { Text("Delete playlist?", color = TextHi) },
            text = { Text("Songs stay in your library. Only the playlist is removed.", color = TextLo) },
            confirmButton = {
                TextButton(onClick = {
                    Playlists.delete(d.id)
                    deleting = null
                    openId = null
                }) { Text("Delete", color = Pink) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Keep", color = TextHi) } }
        )
    }
}

@Composable
private fun PlaylistRow(p: Playlist, songs: List<DownloadItem>, onOpen: () -> Unit, onPlay: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .pressable(onOpen)
            .clip(shape)
            .background(Glass)
            .border(BorderStroke(1.dp, GlassBorder), shape)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(
            Modifier
                .size(64.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(AccentBrush2),
            contentAlignment = Alignment.Center
        ) {
            val thumb = songs.firstNotNullOfOrNull { it.thumbnail }
            if (thumb != null && p.id != Playlists.FAV) {
                AsyncImage(model = thumb, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().size(64.dp))
            } else {
                Icon(
                    if (p.id == Playlists.FAV) Icons.Rounded.Favorite else Icons.Rounded.QueueMusic,
                    null, tint = Color.White, modifier = Modifier.size(30.dp)
                )
            }
        }
        Column(Modifier.weight(1f)) {
            Text(p.name, color = TextHi, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${songs.size} song${if (songs.size == 1) "" else "s"}", color = TextLo, fontSize = 13.sp)
        }
        if (songs.isNotEmpty()) PlayerIconButton(Icons.Rounded.PlayArrow, onPlay, size = 44.dp, active = true)
    }
}

@Composable
private fun TrackRow(s: DownloadItem, onPlay: () -> Unit, onRemove: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .pressable(onPlay)
            .clip(shape)
            .background(Glass)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(Violet, Pink)))) {
            if (s.thumbnail != null) {
                AsyncImage(model = s.thumbnail, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.size(48.dp))
            }
        }
        Column(Modifier.weight(1f)) {
            Text(s.title, color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (s.uploader.isNotEmpty()) Text(s.uploader, color = TextLo, fontSize = 12.sp, maxLines = 1)
        }
        PlayerIconButton(Icons.Rounded.Close, onRemove, size = 34.dp)
    }
}
