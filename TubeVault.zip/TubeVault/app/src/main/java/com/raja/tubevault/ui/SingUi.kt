package com.raja.tubevault.ui

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.raja.tubevault.core.DownloadItem
import com.raja.tubevault.core.SingRecorder
import com.raja.tubevault.core.SingResult
import kotlin.math.max

/** "Sing and get a score" block inside the Karaoke panel. */
@Composable
fun SingSection(item: DownloadItem, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) {
            SingRecorder.start(ctx, item)
            onClose()
        } else Toast.makeText(ctx, "Microphone permission is needed to record you", Toast.LENGTH_LONG).show()
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Sing and get a score", color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
        Text(
            "TubeVault records your voice while the lyrics scroll, then shows a score and lets you replay and save your recording.",
            color = TextLo, fontSize = 12.sp
        )
        if (SingRecorder.recording) {
            GradientButton("Stop and see my score", false) { SingRecorder.stop(ctx); onClose() }
        } else {
            GradientButton("Sing and record", false) {
                val has = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                if (has) {
                    SingRecorder.start(ctx, item)
                    onClose()
                } else launcher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
        Text(
            "Tip: use headphones, so only your voice is recorded. The score checks that you sing along in time with each line. It does not judge whether the notes are in tune. Pair it with \"Remove singer's voice\" above.",
            color = TextLo, fontSize = 12.sp
        )
    }
}

/** REC bar while singing + the animated result card. Placed once in the app root. */
@Composable
fun SingHost() {
    val ctx = LocalContext.current
    val res = SingRecorder.result
    val last = remember { arrayOfNulls<SingResult>(1) }
    if (res != null) last[0] = res

    Box(Modifier.fillMaxSize()) {
        // ---------------- live REC bar
        AnimatedVisibility(
            SingRecorder.recording,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn(tween(200)) + slideInVertically(tween(260)) { h -> -h },
            exit = fadeOut(tween(200)) + slideOutVertically(tween(220)) { h -> -h }
        ) {
            val t = rememberInfiniteTransition(label = "rec")
            val blink by t.animateFloat(
                0.3f, 1f,
                infiniteRepeatable(tween(700, easing = FastOutSlowInEasing), RepeatMode.Reverse),
                label = "blink"
            )
            val lv = SingRecorder.level
            Row(
                Modifier
                    .statusBarsPadding()
                    .padding(top = 8.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color(0xE6140A12))
                    .border(BorderStroke(1.dp, Pink.copy(alpha = 0.6f)), RoundedCornerShape(50))
                    .padding(start = 14.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(Color(0xFFFF3B3B).copy(alpha = blink)))
                Spacer(Modifier.width(8.dp))
                val sec = SingRecorder.seconds
                Text("REC %d:%02d".format(sec / 60, sec % 60), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.width(10.dp))
                // voice level
                Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
                    for (i in 0 until 6) {
                        val on = lv * 6f > i
                        Box(
                            Modifier
                                .width(4.dp)
                                .height((6 + i * 3).dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(if (on) Pink else Color(0x33FFFFFF))
                        )
                    }
                }
                Spacer(Modifier.width(10.dp))
                Text("Score ${SingRecorder.liveScore}", color = Color(0xFFFFE066), fontWeight = FontWeight.Black, fontSize = 13.sp)
                if (SingRecorder.combo >= 2) {
                    Spacer(Modifier.width(8.dp))
                    Text("x${SingRecorder.combo} 🔥", color = Orange, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Pink)
                        .clickable { SingRecorder.stop(ctx) },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Stop, null, tint = Color.White, modifier = Modifier.size(20.dp)) }
            }
        }

        // ---------------- result card
        AnimatedVisibility(
            res != null,
            enter = fadeIn(tween(250)),
            exit = fadeOut(tween(200))
        ) {
            val r = last[0]
            if (r != null) ResultOverlay(r)
        }
    }
}

@Composable
private fun ResultOverlay(r: SingResult) {
    val ctx = LocalContext.current
    val count = remember(r) { Animatable(0f) }
    LaunchedEffect(r) { count.animateTo(r.score.toFloat(), tween(1500, easing = FastOutSlowInEasing)) }

    var playing by remember(r) { mutableStateOf(false) }
    val mp = remember(r) { MediaPlayer() }
    DisposableEffect(r) {
        try {
            mp.setDataSource(r.file.absolutePath)
            mp.prepare()
            mp.setOnCompletionListener { playing = false }
        } catch (_: Throwable) {
        }
        onDispose {
            try {
                mp.release()
            } catch (_: Throwable) {
            }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xDD000000))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { },
        contentAlignment = Alignment.Center
    ) {
        if (r.score >= 60) ConfettiBurst(Modifier.fillMaxSize(), 0.5f, 0.3f, 54, 2000)
        GlassCard(Modifier.padding(24.dp).fillMaxWidth(), corner = 28.dp, borderColor = Pink.copy(alpha = 0.6f)) {
            Column(
                Modifier.padding(22.dp).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Your score", color = TextLo, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                RingProgress((count.value / 100f).coerceIn(0f, 1f), Modifier.size(150.dp), stroke = 10.dp) {
                    Text("${count.value.toInt()}", color = TextHi, fontWeight = FontWeight.Black, fontSize = 48.sp)
                }
                Spacer(Modifier.height(12.dp))
                ShimmerTitle(r.grade, 26.sp)
                Spacer(Modifier.height(6.dp))
                Text(r.title, color = TextLo, fontSize = 12.sp, maxLines = 1, textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    ResultStat("Lines", "${r.linesSung}/${r.linesTotal}")
                    ResultStat("Best combo", "x${r.bestCombo}")
                    ResultStat("Time", "%d:%02d".format(r.seconds / 60, r.seconds % 60))
                }
                if (r.linesSung < 2) {
                    Spacer(Modifier.height(8.dp))
                    Text("Sing a little longer to get a real score.", color = Orange, fontSize = 12.sp)
                }
                Spacer(Modifier.height(16.dp))
                PillButton(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (playing) "Pause" else "Listen to my recording", false) {
                    try {
                        if (playing) {
                            mp.pause()
                            playing = false
                        } else {
                            mp.start()
                            playing = true
                        }
                    } catch (_: Throwable) {
                    }
                }
                Spacer(Modifier.height(12.dp))
                GradientButton("Save my recording", false) { SingRecorder.saveRecording(ctx) }
                val msg = SingRecorder.savedMsg
                if (msg != null) {
                    Spacer(Modifier.height(6.dp))
                    Text(msg, color = Orange, fontSize = 12.sp)
                }
                Spacer(Modifier.height(4.dp))
                Row(
                    Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { SingRecorder.discard() }
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Close, null, tint = TextLo, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Discard", color = TextLo, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
private fun ResultStat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = TextHi, fontWeight = FontWeight.Black, fontSize = 18.sp)
        Text(label, color = TextLo, fontSize = 11.sp)
    }
}
