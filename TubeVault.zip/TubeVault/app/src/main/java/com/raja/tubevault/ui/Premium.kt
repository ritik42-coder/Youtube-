package com.raja.tubevault.ui

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.sin
import kotlin.random.Random

/** Premium (ad-free) state. Demo checkout: no real payment is taken. */
object Premium {
    var isPremium by mutableStateOf(false)
        private set
    var openRequest by mutableStateOf(false)
    var plan by mutableStateOf("")
        private set

    fun init(ctx: Context) {
        val sp = ctx.getSharedPreferences("premium", Context.MODE_PRIVATE)
        isPremium = sp.getBoolean("on", false)
        plan = sp.getString("plan", "") ?: ""
    }

    fun activate(ctx: Context, planName: String) {
        ctx.getSharedPreferences("premium", Context.MODE_PRIVATE).edit()
            .putBoolean("on", true).putString("plan", planName).apply()
        isPremium = true
        plan = planName
    }
}

private val PmGold = Color(0xFFFFC83D)
private val PmGoldBrush = Brush.horizontalGradient(listOf(Color(0xFFFFD66B), Color(0xFFFF9A1F)))
private class PmPlan(val name: String, val price: Int, val per: String, val badge: String?)
private val PM_PLANS = listOf(
    PmPlan("Monthly", 49, "per month", null),
    PmPlan("Yearly", 349, "per year", "BEST VALUE · SAVE 40%"),
    PmPlan("Lifetime", 799, "one-time", "PAY ONCE · FOREVER")
)

@Composable
private fun PmT(
    s: String, size: Int, color: Color = Color.White, w: FontWeight = FontWeight.Normal,
    align: TextAlign = TextAlign.Center, mod: Modifier = Modifier
) = Text(s, color = color, fontSize = size.sp, fontWeight = w, textAlign = align, modifier = mod)

@Composable
fun PremiumScreen() {
    val ctx = LocalContext.current
    var step by remember { mutableIntStateOf(0) }
    var sel by remember { mutableIntStateOf(1) }
    var ms by remember { mutableIntStateOf(0) }
    val plan = PM_PLANS[sel]

    BackHandler(true) {
        when (step) { 1 -> step = 0; 2 -> {}; else -> Premium.openRequest = false }
    }
    LaunchedEffect(step) {
        ms = 0
        if (step == 1) {          // QR on screen -> "scanned" -> verify
            while (ms < 6500) { delay(100); ms += 100 }
            step = 2
        } else if (step == 2) {   // verify -> activate
            while (ms < 3000) { delay(100); ms += 100 }
            Premium.activate(ctx, plan.name)
            step = 3
        }
    }
    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0B0712), Color(0xFF07070D), Color(0xFF160B05))))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
    ) {
        AnimatedContent(
            targetState = step,
            transitionSpec = { (fadeIn(tween(450)) + slideInVertically(tween(450)) { it / 14 }) togetherWith fadeOut(tween(200)) },
            label = "pm"
        ) { s ->
            when (s) {
                0 -> PlansStep(sel, { sel = it }, { Premium.openRequest = false }, { step = 1 })
                1 -> QrStep(plan, ms) { step = 0 }
                2 -> VerifyStep(ms)
                else -> SuccessStep(plan) { Premium.openRequest = false }
            }
        }
    }
}

@Composable
private fun PlansStep(sel: Int, onSel: (Int) -> Unit, onClose: () -> Unit, onGo: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "c")
    val pulse by inf.animateFloat(1f, 1.1f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p")
    val glow by inf.animateFloat(0.25f, 0.65f, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "g")
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
            .padding(horizontal = 22.dp).verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.End) {
            Text("✕", color = Color(0x99FFFFFF), fontSize = 22.sp, modifier = Modifier.clickable { onClose() }.padding(10.dp))
        }
        Box(Modifier.size(150.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.size(150.dp).scale(pulse).alpha(glow).background(Brush.radialGradient(listOf(PmGold, Color.Transparent)), CircleShape))
            Text("👑", fontSize = 68.sp, modifier = Modifier.scale(pulse))
        }
        PmT("TubeVault Premium", 28, PmGold, FontWeight.Black)
        Spacer(Modifier.height(6.dp))
        PmT("Download without interruptions", 14, Color(0xFFB8B8C8))
        Spacer(Modifier.height(18.dp))
        listOf("No ads before downloads — ever", "Support the developer", "Premium badge on your account", "Early access to new features").forEach {
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("✓", color = Color(0xFF34D399), fontSize = 16.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.width(10.dp))
                Text(it, color = Color(0xFFEDEDF5), fontSize = 15.sp)
            }
        }
        Spacer(Modifier.height(18.dp))
        PM_PLANS.forEachIndexed { i, p ->
            val on = i == sel
            Box(
                Modifier.fillMaxWidth().padding(vertical = 6.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (on) Color(0x22FFC83D) else Color(0x14FFFFFF))
                    .border(if (on) 2.dp else 1.dp, if (on) PmGold else Color(0x22FFFFFF), RoundedCornerShape(20.dp))
                    .clickable { onSel(i) }
                    .padding(horizontal = 18.dp, vertical = 16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(22.dp).border(2.dp, if (on) PmGold else Color(0x55FFFFFF), CircleShape).padding(5.dp)
                        .background(if (on) PmGold else Color.Transparent, CircleShape))
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p.name, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                        if (p.badge != null) Text(p.badge, color = PmGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("₹${p.price}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                        Text(p.per, color = Color(0xFF9A9AB0), fontSize = 11.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Box(
            Modifier.fillMaxWidth().scale(1f + (pulse - 1f) * 0.35f)
                .clip(RoundedCornerShape(50)).background(PmGoldBrush)
                .clickable { onGo() }.padding(vertical = 17.dp),
            contentAlignment = Alignment.Center
        ) { PmT("Continue · ₹${PM_PLANS[sel].price}", 18, Color.Black, FontWeight.Black) }
        Spacer(Modifier.height(10.dp))
        PmT("Demo checkout · no real charge", 11, Color(0xFF6E6E82))
        Spacer(Modifier.height(16.dp))
    }
}

private fun qrMatrix(n: Int, seed: Long): Array<BooleanArray> {
    val r = java.util.Random(seed)
    val m = Array(n) { BooleanArray(n) { r.nextInt(100) < 48 } }
    fun finder(x0: Int, y0: Int) {
        for (y in -1..7) for (x in -1..7) {
            val xx = x0 + x; val yy = y0 + y
            if (xx !in 0 until n || yy !in 0 until n) continue
            m[yy][xx] = x in 0..6 && y in 0..6 && (x == 0 || x == 6 || y == 0 || y == 6 || (x in 2..4 && y in 2..4))
        }
    }
    finder(0, 0); finder(n - 7, 0); finder(0, n - 7)
    val c = n / 2
    for (y in c - 3..c + 3) for (x in c - 3..c + 3) m[y][x] = false
    return m
}

@Composable
private fun QrStep(plan: PmPlan, ms: Int, onBack: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "q")
    val scan by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1500, easing = LinearEasing), RepeatMode.Reverse), label = "s")
    val blink by inf.animateFloat(0.3f, 1f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "b")
    val m = remember(plan.name) { qrMatrix(29, plan.price.toLong() * 7919L) }
    val rem = 299 - ms / 1000
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.Start) {
            Text("‹ Back", color = Color(0xB3FFFFFF), fontSize = 16.sp, modifier = Modifier.clickable { onBack() }.padding(10.dp))
        }
        Spacer(Modifier.height(10.dp))
        PmT("Scan to pay", 26, Color.White, FontWeight.Black)
        PmT("₹${plan.price}", 44, PmGold, FontWeight.Black)
        PmT("${plan.name} plan · TubeVault Premium", 13, Color(0xFFB8B8C8))
        Spacer(Modifier.height(22.dp))
        Box(
            Modifier.size(300.dp).border(2.dp, PmGold.copy(alpha = blink), RoundedCornerShape(32.dp)).padding(10.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.fillMaxSize().clip(RoundedCornerShape(24.dp)).background(Color.White).padding(18.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val n = m.size
                    val cell = size.width / n
                    for (y in 0 until n) for (x in 0 until n) if (m[y][x]) {
                        drawRoundRect(Color(0xFF111111), Offset(x * cell, y * cell), Size(cell * 0.92f, cell * 0.92f), CornerRadius(cell * 0.25f))
                    }
                    val y = scan * size.height
                    drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color(0x66E11D2E)), startY = y - 140f, endY = y), Offset(0f, y - 140f), Size(size.width, 140f))
                    drawRect(Color(0xFFE11D2E), Offset(0f, y - 2f), Size(size.width, 4f))
                }
                Box(Modifier.size(46.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFE11D2E)), contentAlignment = Alignment.Center) {
                    Text("▶", color = Color.White, fontSize = 20.sp)
                }
            }
        }
        Spacer(Modifier.height(22.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).alpha(blink).background(if (ms < 3500) PmGold else Color(0xFF34D399), CircleShape))
            Spacer(Modifier.width(10.dp))
            PmT(if (ms < 3500) "Waiting for payment…" else "Payment detected · confirming…", 15, Color.White, FontWeight.SemiBold)
        }
        Spacer(Modifier.height(8.dp))
        PmT("Open any UPI app → Scan QR · Expires in 0${rem / 60}:${(rem % 60).toString().padStart(2, '0')}", 12, Color(0xFF9A9AB0))
        Spacer(Modifier.height(18.dp))
        PmT("Demo checkout · no real charge", 11, Color(0xFF6E6E82))
    }
}

@Composable
private fun VerifyStep(ms: Int) {
    val inf = rememberInfiniteTransition(label = "v")
    val rot by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(1000, easing = LinearEasing)), label = "r")
    Column(Modifier.fillMaxSize().statusBarsPadding(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(140.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                drawCircle(Color(0x22FFFFFF), style = Stroke(10f))
                drawArc(PmGold, rot, 110f, false, Offset(8f, 8f), Size(size.width - 16f, size.height - 16f), style = Stroke(10f, cap = StrokeCap.Round))
            }
            Text("₹", color = PmGold, fontSize = 44.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(26.dp))
        PmT("Verifying payment…", 22, Color.White, FontWeight.ExtraBold)
        Spacer(Modifier.height(16.dp))
        listOf("Contacting your bank" to 0, "Confirming transaction" to 1000, "Activating Premium" to 2000).forEach { (t, at) ->
            val done = ms >= at + 900
            Text(
                (if (done) "✓  " else "•  ") + t,
                color = if (done) Color(0xFF34D399) else Color(0xFFB8B8C8),
                fontSize = 15.sp, modifier = Modifier.alpha(if (ms >= at) 1f else 0.25f).padding(vertical = 4.dp)
            )
        }
    }
}

private class PmConf(val x: Float, val sp: Float, val ph: Float, val sz: Float, val c: Color)

@Composable
private fun SuccessStep(plan: PmPlan, onDone: () -> Unit) {
    val prog = remember { Animatable(0f) }
    val burst = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { burst.animateTo(1f, tween(900)) }
        prog.animateTo(1f, tween(700, delayMillis = 250))
    }
    val inf = rememberInfiniteTransition(label = "f")
    val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(3500, easing = LinearEasing)), label = "t")
    val cols = listOf(PmGold, Color(0xFFFF2E63), Color(0xFF34D399), Color(0xFF22D3EE), Color(0xFF8B5CF6))
    val parts = remember { List(44) { PmConf(Random.nextFloat(), 0.6f + Random.nextFloat(), Random.nextFloat(), 8f + Random.nextFloat() * 10f, cols[Random.nextInt(cols.size)]) } }
    val ref = remember { Random.nextInt(100000000, 999999999) }
    Box(Modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            for (p in parts) {
                val y = ((t * p.sp + p.ph) % 1f) * size.height
                val x = p.x * size.width + sin(t * 6.28f * p.sp + p.ph * 6f) * 30f
                drawRect(p.c, Offset(x, y), Size(p.sz, p.sz * 1.6f))
            }
        }
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Canvas(Modifier.size(160.dp)) {
                val c = center; val r = size.minDimension / 2
                drawCircle(Color(0xFF22C55E).copy(alpha = 0.2f * (1f - burst.value)), radius = r * (0.6f + burst.value * 0.9f))
                drawCircle(Brush.linearGradient(listOf(Color(0xFF34D399), Color(0xFF16A34A))), radius = r * 0.62f * minOf(1f, burst.value * 2f))
                val p = prog.value
                val a = Offset(c.x - r * 0.25f, c.y + r * 0.02f)
                val b = Offset(c.x - r * 0.07f, c.y + r * 0.2f)
                val d = Offset(c.x + r * 0.28f, c.y - r * 0.16f)
                val s1 = (p * 2f).coerceIn(0f, 1f)
                val s2 = ((p - 0.5f) * 2f).coerceIn(0f, 1f)
                drawLine(Color.White, a, a + (b - a) * s1, strokeWidth = 14f, cap = StrokeCap.Round)
                if (s2 > 0f) drawLine(Color.White, b, b + (d - b) * s2, strokeWidth = 14f, cap = StrokeCap.Round)
            }
            Spacer(Modifier.height(22.dp))
            PmT("Payment successful", 26, Color.White, FontWeight.Black)
            Spacer(Modifier.height(6.dp))
            PmT("₹${plan.price} · ${plan.name} plan", 16, PmGold, FontWeight.Bold)
            PmT("Ref $ref", 12, Color(0xFF9A9AB0))
            Spacer(Modifier.height(18.dp))
            PmT("👑 Premium activated\nAds removed — enjoy TubeVault!", 16, Color(0xFFEDEDF5))
            Spacer(Modifier.height(28.dp))
            Box(
                Modifier.clip(RoundedCornerShape(50)).background(PmGoldBrush).clickable { onDone() }.padding(horizontal = 56.dp, vertical = 16.dp)
            ) { PmT("Done", 18, Color.Black, FontWeight.Black) }
        }
    }
}
