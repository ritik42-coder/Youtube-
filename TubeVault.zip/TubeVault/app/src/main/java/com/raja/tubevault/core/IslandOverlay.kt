package com.raja.tubevault.core

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import coil.imageLoader
import coil.request.ImageRequest
import coil.transform.CircleCropTransformation
import com.raja.tubevault.MainActivity
import com.raja.tubevault.R
import com.raja.tubevault.ui.AppSettings
import kotlin.math.max
import kotlin.math.min

/** Decides when the floating island should be on screen (app in background + setting on + permission). */
class IslandController(private val ctx: Context) {
    private val handler = Handler(Looper.getMainLooper())
    private var overlay: IslandOverlay? = null
    private var running = false

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            val ok = AppSettings.islandOverlay && canDraw(ctx) && !AppState.foreground && PlayerHub.hasMusic
            if (ok && overlay == null) overlay = IslandOverlay(ctx).also { it.show() }
            else if (!ok && overlay != null) { overlay?.hide(); overlay = null }
            overlay?.update()
            handler.postDelayed(this, 120)
        }
    }

    fun start() { running = true; handler.post(loop) }

    fun stop() {
        running = false
        handler.removeCallbacksAndMessages(null)
        overlay?.hideNow()
        overlay = null
    }

    companion object {
        fun canDraw(c: Context): Boolean = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c)
    }
}

/** The floating "dynamic island" shown over other apps. Built with plain views so it can live in a service. */
class IslandOverlay(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val dm = ctx.resources.displayMetrics
    private fun d(v: Int) = (v * dm.density).toInt()

    private var root: LinearLayout? = null
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var bg: GradientDrawable
    private lateinit var art: ImageView
    private lateinit var bars: BarsView
    private lateinit var title: TextView
    private lateinit var artist: TextView
    private lateinit var playBtn: ImageView
    private lateinit var bigPlay: ImageView
    private lateinit var extra: LinearLayout
    private lateinit var seek: SeekView
    private lateinit var timeL: TextView
    private lateinit var timeR: TextView
    private lateinit var topRow: LinearLayout
    private var spin: ObjectAnimator? = null
    private var sizeAnim: ValueAnimator? = null
    private var expanded = false
    private var lastId: String? = null
    private var lastAccent = 0
    private var gone = false

    private fun icon(res: Int, sizeDp: Int, padDp: Int = 0): ImageView = ImageView(ctx).apply {
        setImageResource(res)
        setColorFilter(0xFFFFFFFF.toInt())
        setPadding(d(padDp), d(padDp), d(padDp), d(padDp))
        layoutParams = LinearLayout.LayoutParams(d(sizeDp), d(sizeDp))
    }

    fun show() {
        bg = GradientDrawable().apply {
            setColor(0xF2050508.toInt()); cornerRadius = d(26).toFloat(); setStroke(d(1), 0x77FF3D77)
        }
        val r = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = bg
            elevation = d(12).toFloat()
            setPadding(d(7), d(6), d(12), d(6))
            setOnClickListener { toggle() }
        }
        topRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        art = ImageView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(d(34), d(34))
            scaleType = ImageView.ScaleType.CENTER_CROP
            setOnClickListener { if (expanded) openApp() else toggle() }
        }
        bars = BarsView(ctx).apply { layoutParams = LinearLayout.LayoutParams(d(26), d(20)).apply { leftMargin = d(9); rightMargin = d(9) } }
        title = TextView(ctx).apply {
            setTextColor(0xFFFFFFFF.toInt()); setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END; maxWidth = d(130)
        }
        playBtn = icon(R.drawable.ic_isl_play, 30, 4).apply {
            (layoutParams as LinearLayout.LayoutParams).leftMargin = d(8)
            setOnClickListener { PlayerHub.playPause(ctx) }
        }
        topRow.addView(art); topRow.addView(bars); topRow.addView(title); topRow.addView(playBtn)

        artist = TextView(ctx).apply {
            setTextColor(0xFFB0B0C0.toInt()); setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f); maxLines = 1
        }
        seek = SeekView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, d(30))
            onSeek = { f -> val p = PlayerHub.player(ctx); if (p.duration > 0) p.seekTo((f * p.duration).toLong()) }
        }
        timeL = TextView(ctx).apply { setTextColor(0xFFB0B0C0.toInt()); setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f) }
        timeR = TextView(ctx).apply { setTextColor(0xFFB0B0C0.toInt()); setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f); gravity = Gravity.END }
        val times = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(timeL, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(timeR, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        bigPlay = icon(R.drawable.ic_isl_play, 54, 14).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFFFF3D77.toInt()) }
            setOnClickListener { PlayerHub.playPause(ctx) }
        }
        val controls = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            fun side(res: Int, act: () -> Unit) = icon(res, 44, 10).also {
                it.setOnClickListener { act() }
                (it.layoutParams as LinearLayout.LayoutParams).apply { leftMargin = d(8); rightMargin = d(8) }
            }
            addView(side(R.drawable.ic_isl_open) { openApp() })
            addView(side(R.drawable.ic_isl_prev) { PlayerHub.previous(ctx) })
            addView(bigPlay)
            addView(side(R.drawable.ic_isl_next) { PlayerHub.next(ctx) })
            addView(side(R.drawable.ic_isl_close) { PlayerHub.stop(ctx) })
        }
        extra = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            setPadding(d(6), d(8), d(2), d(4))
            addView(artist); addView(seek); addView(times)
            addView(controls, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = d(6) })
        }
        r.addView(topRow); r.addView(extra)
        root = r

        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = statusBar() + d(6)
        }
        r.alpha = 0f; r.scaleX = 0.5f; r.scaleY = 0.5f; r.translationY = -d(40).toFloat()
        try {
            wm.addView(r, lp)
            r.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f).setDuration(420)
                .setInterpolator(OvershootInterpolator(1.4f)).start()
        } catch (_: Throwable) {
            root = null
        }
    }

    private fun statusBar(): Int {
        val id = ctx.resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) ctx.resources.getDimensionPixelSize(id) else d(24)
    }

    private fun openApp() {
        try {
            ctx.startActivity(Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        } catch (_: Throwable) {
        }
    }

    private fun toggle() {
        val r = root ?: return
        expanded = !expanded
        sizeAnim?.cancel()
        val from = lp.width.takeIf { it > 0 } ?: r.width
        if (expanded) {
            extra.visibility = View.VISIBLE
            title.maxWidth = Int.MAX_VALUE
            (art.layoutParams as LinearLayout.LayoutParams).apply { width = d(52); height = d(52) }
            art.requestLayout()
        }
        val target = if (expanded) dm.widthPixels - d(24) else compactWidth()
        sizeAnim = ValueAnimator.ofInt(max(from, 1), target).apply {
            duration = 380
            interpolator = OvershootInterpolator(if (expanded) 0.9f else 0.6f)
            addUpdateListener {
                lp.width = it.animatedValue as Int
                try { wm.updateViewLayout(r, lp) } catch (_: Throwable) { }
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) {
                    if (!expanded) {
                        extra.visibility = View.GONE
                        title.maxWidth = d(130)
                        (art.layoutParams as LinearLayout.LayoutParams).apply { width = d(34); height = d(34) }
                        art.requestLayout()
                        lp.width = ViewGroup.LayoutParams.WRAP_CONTENT
                        try { wm.updateViewLayout(r, lp) } catch (_: Throwable) { }
                    }
                }
            })
            start()
        }
        if (!expanded) {
            // shrink the art right away so the pill closes smoothly
            (art.layoutParams as LinearLayout.LayoutParams).apply { width = d(34); height = d(34) }
            title.maxWidth = d(130)
            art.requestLayout()
        }
    }

    private fun compactWidth(): Int {
        val r = root ?: return d(220)
        val saved = extra.visibility
        extra.visibility = View.GONE
        r.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val w = r.measuredWidth
        extra.visibility = saved
        return max(w, d(160))
    }

    fun update() {
        val r = root ?: return
        val item = PlayerHub.current ?: return
        val playing = PlayerHub.isPlaying
        if (item.id != lastId) {
            lastId = item.id
            title.text = item.title
            artist.text = item.uploader.ifEmpty { "TubeVault" }
            try {
                ctx.imageLoader.enqueue(
                    ImageRequest.Builder(ctx).data(item.thumbnail).transformations(CircleCropTransformation())
                        .target(onSuccess = { art.setImageDrawable(it) }).build()
                )
            } catch (_: Throwable) {
            }
            if (!expanded) {
                lp.width = ViewGroup.LayoutParams.WRAP_CONTENT
                try { wm.updateViewLayout(r, lp) } catch (_: Throwable) { }
            }
        }
        val acc = PlayerHub.accentA
        if (acc != lastAccent) {
            lastAccent = acc
            bg.setStroke(d(1), (acc and 0x00FFFFFF) or 0x88000000.toInt())
            (bigPlay.background as? GradientDrawable)?.setColor(acc)
            bars.setColors(acc, PlayerHub.accentB)
            seek.setColors(acc, PlayerHub.accentB)
        }
        playBtn.setImageResource(if (playing) R.drawable.ic_isl_pause else R.drawable.ic_isl_play)
        bigPlay.setImageResource(if (playing) R.drawable.ic_isl_pause else R.drawable.ic_isl_play)
        bars.active = playing
        if (playing) {
            if (spin == null) {
                spin = ObjectAnimator.ofFloat(art, View.ROTATION, art.rotation, art.rotation + 360f).apply {
                    duration = 9000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator(); start()
                }
            }
        } else {
            spin?.cancel(); spin = null
        }
        if (expanded) {
            val p = PlayerHub.player(ctx)
            val dur = p.duration
            val pos = p.currentPosition
            if (dur > 0) seek.setProgress(pos.toFloat() / dur)
            timeL.text = fmt(pos); timeR.text = if (dur > 0) fmt(dur) else "0:00"
        }
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return String.format("%d:%02d", s / 60, s % 60)
    }

    fun hide() {
        val r = root ?: return
        if (gone) return
        gone = true
        spin?.cancel(); spin = null
        r.animate().alpha(0f).scaleX(0.6f).scaleY(0.6f).translationY(-d(30).toFloat()).setDuration(240)
            .withEndAction { try { wm.removeView(r) } catch (_: Throwable) { } }.start()
        root = null
    }

    fun hideNow() {
        val r = root ?: return
        spin?.cancel(); spin = null
        try { wm.removeView(r) } catch (_: Throwable) { }
        root = null
    }
}

/** Five live bars driven by the real audio spectrum. */
class BarsView(c: Context) : View(c) {
    var active = false
    private val buf = FloatArray(Viz.BANDS + 2)
    private val v = FloatArray(5)
    private val idx = intArrayOf(1, 5, 10, 17, 25)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var c1 = 0xFFFF9A3D.toInt()
    private var c2 = 0xFFFF3D77.toInt()

    fun setColors(a: Int, b: Int) { c1 = b; c2 = a; paint.shader = null }

    override fun onDraw(canvas: Canvas) {
        val ok = active && Viz.read(buf)
        for (i in 0 until 5) {
            val t = if (ok) buf[idx[i]] else 0f
            v[i] += (t - v[i]) * (if (t > v[i]) 0.6f else 0.15f)
        }
        if (paint.shader == null) paint.shader = LinearGradient(0f, 0f, 0f, height.toFloat(), c1, c2, Shader.TileMode.CLAMP)
        val gap = 2.5f * resources.displayMetrics.density
        val w = (width - gap * 4) / 5f
        for (i in 0 until 5) {
            val h = max(height * (0.18f + 0.82f * v[i]), 3f * resources.displayMetrics.density)
            rect.set(i * (w + gap), height - h, i * (w + gap) + w, height.toFloat())
            canvas.drawRoundRect(rect, w / 2f, w / 2f, paint)
        }
        if (active || v.any { it > 0.02f }) postInvalidateOnAnimation()
    }
}

/** Thin gradient seek bar with a glowing thumb. */
class SeekView(c: Context) : View(c) {
    var onSeek: ((Float) -> Unit)? = null
    private var frac = 0f
    private var drag = -1f
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x33FFFFFF }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumb = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val rect = RectF()
    private var c1 = 0xFFFF3D77.toInt()
    private var c2 = 0xFFFF9A3D.toInt()

    fun setColors(a: Int, b: Int) { c1 = a; c2 = b; fill.shader = null; invalidate() }
    fun setProgress(f: Float) { if (drag < 0f) { frac = f.coerceIn(0f, 1f); invalidate() } }

    override fun onDraw(canvas: Canvas) {
        val dn = resources.displayMetrics.density
        val pad = 8 * dn
        val w = width - pad * 2
        val cy = height / 2f
        val th = (if (drag >= 0f) 8 else 5) * dn
        val f = if (drag >= 0f) drag else frac
        rect.set(pad, cy - th / 2, pad + w, cy + th / 2)
        canvas.drawRoundRect(rect, th / 2, th / 2, track)
        if (fill.shader == null) fill.shader = LinearGradient(pad, 0f, pad + w, 0f, c1, c2, Shader.TileMode.CLAMP)
        rect.set(pad, cy - th / 2, pad + w * f, cy + th / 2)
        canvas.drawRoundRect(rect, th / 2, th / 2, fill)
        canvas.drawCircle(pad + w * f, cy, (if (drag >= 0f) 8 else 6) * dn, thumb)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val dn = resources.displayMetrics.density
        val pad = 8 * dn
        val f = ((e.x - pad) / (width - pad * 2)).coerceIn(0f, 1f)
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { parent?.requestDisallowInterceptTouchEvent(true); drag = f; invalidate() }
            MotionEvent.ACTION_MOVE -> { drag = f; invalidate() }
            MotionEvent.ACTION_UP -> { onSeek?.invoke(f); frac = f; drag = -1f; invalidate() }
            MotionEvent.ACTION_CANCEL -> { drag = -1f; invalidate() }
        }
        return true
    }
}
