package com.raja.tubevault.core

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.os.SystemClock
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.Player
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import kotlin.math.max
import kotlin.math.min

data class SingResult(
    val score: Int,
    val title: String,
    val linesSung: Int,
    val linesTotal: Int,
    val bestCombo: Int,
    val seconds: Int,
    val leadMs: Long,
    val file: File,
    val song: DownloadItem
) {
    val grade: String
        get() = when {
            score >= 90 -> "Superstar!"
            score >= 75 -> "Great singing!"
            score >= 55 -> "Nice one!"
            score >= 30 -> "Good start"
            else -> "Keep practicing"
        }
}

/**
 * "Sing and record": records your voice with the microphone while the song plays and gives a score.
 * The score checks that you were singing during each lyric line (timing and energy).
 * It does not judge whether the notes are in tune.
 */
object SingRecorder {
    var recording by mutableStateOf(false)
        private set
    var level by mutableFloatStateOf(0f)
        private set
    var liveScore by mutableIntStateOf(0)
        private set
    var combo by mutableIntStateOf(0)
        private set
    var seconds by mutableIntStateOf(0)
        private set
    var result by mutableStateOf<SingResult?>(null)
        private set
    var savedMsg by mutableStateOf<String?>(null)
        private set
    var mixing by mutableStateOf(false)
        private set
    var mixProgress by mutableFloatStateOf(0f)
        private set
    private var elapsedMs by mutableLongStateOf(0L)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private var rec: MediaRecorder? = null
    private var file: File? = null
    private var song: DownloadItem? = null
    private var voiced = IntArray(0)
    private var total = IntArray(0)
    private var bestCombo = 0
    private var lastPos = 0L
    private var recStartRt = 0L
    private var leadMs = 0L
    private var leadSet = false

    @Suppress("DEPRECATION")
    fun start(ctx: Context, item: DownloadItem) {
        if (recording) return
        val lines = Karaoke.timeline
        if (Karaoke.forId != item.id || lines.none { !it.isBreak }) {
            Toast.makeText(ctx, "Create or find the lyrics first", Toast.LENGTH_SHORT).show()
            return
        }
        val app = ctx.applicationContext
        try {
            val dir = File(app.cacheDir, "sing").apply { mkdirs() }
            dir.listFiles()?.forEach { it.delete() }
            val f = File(dir, UUID.randomUUID().toString() + ".m4a")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(app) else MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(128_000)
            r.setAudioSamplingRate(44_100)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            recStartRt = SystemClock.elapsedRealtime()
            rec = r
            file = f
        } catch (e: Throwable) {
            rec = null
            Toast.makeText(ctx, "Couldn't start the microphone: " + (e.message ?: ""), Toast.LENGTH_LONG).show()
            return
        }
        song = item
        result = null
        savedMsg = null
        voiced = IntArray(lines.size)
        total = IntArray(lines.size)
        bestCombo = 0
        combo = 0
        liveScore = 0
        level = 0f
        seconds = 0
        elapsedMs = 0L
        lastPos = 0L
        leadMs = 0L
        leadSet = false
        recording = true
        Karaoke.stageOn = true

        val pl = PlayerHub.player(app)
        pl.seekTo(0L)
        pl.play()
        job?.cancel()
        job = scope.launch { loop(app, lines, pl, item.id) }
    }

    private suspend fun loop(ctx: Context, lines: List<LyricLine>, pl: androidx.media3.exoplayer.ExoPlayer, id: String) {
        var quiet = 600f
        var smooth = 0f
        var lastActive = -1
        var finishedGood = 0
        while (recording) {
            delay(50)
            val r = rec ?: break
            if (PlayerHub.current?.id != id) {
                stop(ctx)
                return
            }
            val amp = try {
                r.maxAmplitude
            } catch (_: Throwable) {
                0
            }
            smooth = smooth * 0.55f + amp * 0.45f
            level = (smooth / 14000f).coerceIn(0f, 1f)
            if (!pl.isPlaying) {
                if (pl.playbackState == Player.STATE_ENDED) {
                    stop(ctx)
                    return
                }
                continue
            }
            if (!leadSet && pl.currentPosition > 100L) {
                // how long the microphone had been running when the song really started
                leadMs = max(0L, SystemClock.elapsedRealtime() - recStartRt - pl.currentPosition)
                leadSet = true
            }
            elapsedMs += 50L
            seconds = (elapsedMs / 1000L).toInt()
            val pos = pl.currentPosition + Karaoke.offsetMs
            lastPos = pos
            var active = -1
            for (i in lines.indices) {
                val ln = lines[i]
                if (!ln.isBreak && pos >= ln.startMs && pos <= ln.endMs) {
                    active = i
                    break
                }
            }
            if (active < 0) {
                quiet = quiet * 0.97f + amp * 0.03f
            } else {
                val thr = max(1500f, quiet * 2.6f)
                total[active]++
                if (amp > thr) voiced[active]++
            }
            // a line just finished: update combo + live score
            if (active != lastActive) {
                if (lastActive >= 0) {
                    if (lineScore(lastActive) >= 0.7f) {
                        finishedGood++
                        combo++
                        if (combo > bestCombo) bestCombo = combo
                    } else {
                        combo = 0
                        finishedGood = 0
                    }
                }
                lastActive = active
                liveScore = currentScore(lines, pos, false)
            }
        }
    }

    private fun lineScore(i: Int): Float {
        val t = total[i]
        if (t < 4) return 0f
        return min(1f, (voiced[i].toFloat() / t) / 0.55f)
    }

    private fun currentScore(lines: List<LyricLine>, pos: Long, includeActive: Boolean): Int {
        var sum = 0f
        var n = 0
        for (i in lines.indices) {
            val ln = lines[i]
            if (ln.isBreak) continue
            val done = if (includeActive) ln.startMs <= pos else ln.endMs < pos
            if (!done) continue
            sum += lineScore(i)
            n++
        }
        return if (n == 0) 0 else Math.round(sum / n * 100f)
    }

    fun stop(ctx: Context) {
        if (!recording) return
        recording = false
        job?.cancel()
        val r = rec
        rec = null
        var ok = true
        try {
            r?.stop()
        } catch (_: Throwable) {
            ok = false
        }
        try {
            r?.release()
        } catch (_: Throwable) {
        }
        try {
            PlayerHub.player(ctx).pause()
        } catch (_: Throwable) {
        }
        val f = file
        val s = song
        val lines = Karaoke.timeline
        level = 0f
        if (!ok || f == null || s == null || !f.exists()) {
            Toast.makeText(ctx, "Recording was too short", Toast.LENGTH_SHORT).show()
            return
        }
        var sung = 0
        var all = 0
        for (i in lines.indices) {
            if (lines[i].isBreak) continue
            all++
            if (lines[i].startMs <= lastPos) sung++
        }
        val score = currentScore(lines, lastPos, true)
        result = SingResult(
            score = if (sung < 2) 0 else score,
            title = s.title,
            linesSung = sung,
            linesTotal = all,
            bestCombo = bestCombo,
            seconds = seconds,
            leadMs = leadMs,
            file = f,
            song = s
        )
    }

    fun saveRecording(ctx: Context) {
        val r = result ?: return
        val app = ctx.applicationContext
        scope.launch {
            try {
                val title = "My cover - " + r.title
                val name = MediaSaver.sanitize(title) + ".m4a"
                val uri = withContext(Dispatchers.IO) {
                    val tagged = Thumbs.embed(r.file, title, "Me", null)
                    LocalStore.save(app, tagged, name)
                }
                val size = withContext(Dispatchers.IO) { LocalStore.fileOf(uri)?.length() ?: 0L }
                Downloads.addFinished(
                    DownloadItem(
                        id = UUID.randomUUID().toString(), title = title, uploader = "You",
                        thumbnail = r.song.thumbnail, label = "My recording", isAudio = true, status = Status.DONE,
                        progress = 1f, speed = 0L, doneBytes = size, totalBytes = size, uri = uri,
                        error = null, createdAt = System.currentTimeMillis(), place = Place.PRIVATE
                    )
                )
                savedMsg = "Saved in your Library (private)"
                Toast.makeText(app, "Saved \"$title\" 🎤", Toast.LENGTH_LONG).show()
                result = null
            } catch (e: Throwable) {
                savedMsg = e.message ?: "Couldn't save the recording"
            }
        }
    }

    /** Voice + AI karaoke track -> one finished song in your Library. */
    fun saveMixed(ctx: Context, voiceGain: Float, musicGain: Float, adjustMs: Long) {
        val r = result ?: return
        if (mixing) return
        val app = ctx.applicationContext
        val backing = AiStems.stemFile(app, r.song.id)
        if (!backing.exists()) {
            savedMsg = "Make the AI karaoke track first"
            return
        }
        mixing = true
        mixProgress = 0f
        savedMsg = null
        scope.launch {
            val tmp = File(app.cacheDir, "sing/mix-" + UUID.randomUUID().toString() + ".m4a")
            try {
                withContext(Dispatchers.IO) {
                    VoiceMixer.mix(
                        app, backing, r.file, voiceGain, musicGain, adjustMs - r.leadMs, tmp,
                        { false }, { p -> mixProgress = p }
                    )
                }
                val title = "My cover - " + r.title
                val name = MediaSaver.sanitize(title) + ".m4a"
                val uri = withContext(Dispatchers.IO) {
                    val tagged = Thumbs.embed(tmp, title, "Me", null)
                    LocalStore.save(app, tagged, name)
                }
                val size = withContext(Dispatchers.IO) { LocalStore.fileOf(uri)?.length() ?: 0L }
                Downloads.addFinished(
                    DownloadItem(
                        id = UUID.randomUUID().toString(), title = title, uploader = "You",
                        thumbnail = r.song.thumbnail, label = "My cover", isAudio = true, status = Status.DONE,
                        progress = 1f, speed = 0L, doneBytes = size, totalBytes = size, uri = uri,
                        error = null, createdAt = System.currentTimeMillis(), place = Place.PRIVATE
                    )
                )
                Toast.makeText(app, "Saved \"$title\" 🎤 (private)", Toast.LENGTH_LONG).show()
                savedMsg = "Saved in your Library (private)"
                result = null
            } catch (e: Throwable) {
                savedMsg = e.message ?: "Couldn't mix the song"
                try {
                    tmp.delete()
                } catch (_: Throwable) {
                }
            } finally {
                mixing = false
            }
        }
    }

    fun discard() {
        try {
            result?.file?.delete()
        } catch (_: Throwable) {
        }
        result = null
        savedMsg = null
    }
}
