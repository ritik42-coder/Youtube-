package com.raja.tubevault.core

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.raja.tubevault.ui.AppSettings
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.ServiceList
import org.schabi.newpipe.extractor.playlist.PlaylistInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem

data class PlItem(val url: String, val title: String, val uploader: String, val durationSec: Long, val thumb: String?)

data class PlData(val title: String, val uploader: String, val items: List<PlItem>, val total: Long)

object PlaylistRepo {
    private const val CAP = 300

    fun isPlaylistUrl(link: String): Boolean {
        val l = link.lowercase()
        return (l.contains("youtube.com/playlist") || l.contains("music.youtube.com/playlist")) && l.contains("list=")
    }

    /** Blocking. Loads the playlist and up to 300 videos. */
    fun load(url: String): PlData {
        val info = PlaylistInfo.getInfo(url)
        val items = ArrayList<PlItem>()
        fun add(list: List<StreamInfoItem>) {
            for (x in list) {
                val u: String = x.url ?: continue
                items.add(PlItem(u, x.name ?: "", x.uploaderName ?: "", x.duration, x.thumbnails.firstOrNull()?.url))
            }
        }
        add(info.relatedItems)
        var page = info.nextPage
        while (page != null && items.size < CAP) {
            val more = PlaylistInfo.getMoreItems(ServiceList.YouTube, url, page)
            add(more.items)
            page = more.nextPage
        }
        return PlData(info.name ?: "Playlist", info.uploaderName ?: "", items, info.streamCount)
    }
}

/** State of the "download a whole playlist" sheet. */
object PlaylistController {
    var visible by mutableStateOf(false)
        private set
    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var data by mutableStateOf<PlData?>(null)
        private set
    var selected by mutableStateOf<Set<String>>(emptySet())
        private set
    var existing by mutableStateOf<Set<String>>(emptySet())
        private set
    var preset by mutableIntStateOf(0)
    var place by mutableStateOf(Place.GALLERY)
    var queuing by mutableStateOf(false)
        private set
    var queued by mutableIntStateOf(0)
        private set
    var failed by mutableIntStateOf(0)
        private set
    var queueTotal by mutableIntStateOf(0)
        private set
    var finished by mutableStateOf(false)
        private set
    var queueProgress by mutableFloatStateOf(0f)
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var loadJob: Job? = null
    private var queueJob: Job? = null

    fun open(url: String) {
        place = AppSettings.defaultPlace
        visible = true
        loading = true
        error = null
        data = null
        selected = emptySet()
        queuing = false
        finished = false
        queued = 0
        failed = 0
        loadJob?.cancel()
        queueJob?.cancel()
        loadJob = scope.launch {
            try {
                val d = withContext(Dispatchers.IO) { PlaylistRepo.load(url) }
                if (d.items.isEmpty()) throw IllegalStateException("This playlist is empty or private")
                val have = Downloads.items.value
                    .filter { it.status == Status.DONE }
                    .map { it.title.trim().lowercase() }
                    .toSet()
                existing = d.items.filter { it.title.trim().lowercase() in have }.map { it.url }.toSet()
                // new videos are ticked, videos you already have are not
                selected = d.items.map { it.url }.filter { it !in existing }.toSet()
                data = d
                loading = false
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                loading = false
                error = Errors.friendly(e)
            }
        }
    }

    fun close() {
        visible = false
        loadJob?.cancel()
        // a running queue keeps going in the background
    }

    fun toggle(url: String) {
        selected = if (url in selected) selected - url else selected + url
    }

    fun selectAll() {
        selected = data?.items?.map { it.url }?.toSet() ?: emptySet()
    }

    fun selectNew() {
        val d = data ?: return
        selected = d.items.map { it.url }.filter { it !in existing }.toSet()
    }

    fun selectNone() {
        selected = emptySet()
    }

    private fun heightOf(o: FormatOption): Int =
        Regex("(\\d{3,4})p").find(o.label)?.groupValues?.get(1)?.toIntOrNull() ?: 0

    private fun pick(info: MediaInfo): FormatOption? {
        val v = info.videoFormats
        val a = info.audioFormats
        val chosen: FormatOption? = when (preset) {
            0 -> a.firstOrNull()
            1 -> v.filter { heightOf(it) in 1..720 }.maxByOrNull { heightOf(it) } ?: v.minByOrNull { heightOf(it) }
            else -> v.maxByOrNull { heightOf(it) } ?: v.firstOrNull()
        }
        return chosen ?: a.firstOrNull() ?: v.firstOrNull()
    }

    fun startDownload() {
        val d = data ?: return
        val urls = d.items.map { it.url }.filter { it in selected }
        if (urls.isEmpty() || queuing) return
        queuing = true
        finished = false
        queued = 0
        failed = 0
        queueTotal = urls.size
        queueProgress = 0f
        val usePlace = place
        queueJob = scope.launch {
            for ((i, u) in urls.withIndex()) {
                try {
                    val info = withContext(Dispatchers.IO) { LinkCache.get(u).await() }
                    val opt = pick(info)
                    if (opt == null) {
                        failed++
                    } else {
                        Downloads.enqueue(info, opt, usePlace)
                        queued++
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    failed++
                }
                queueProgress = (i + 1f) / urls.size
                delay(350)
            }
            queuing = false
            finished = true
        }
    }
}
