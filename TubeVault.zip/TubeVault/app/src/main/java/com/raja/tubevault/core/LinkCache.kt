package com.raja.tubevault.core

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import java.util.concurrent.ConcurrentHashMap

/**
 * Faster fetching: a link starts loading the moment TubeVault sees it (copied to the clipboard,
 * shared to the app), before you even tap. Results are remembered for 15 minutes, so opening
 * the same link again is instant.
 */
object LinkCache {
    private class Entry(val time: Long, val job: Deferred<MediaInfo>)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val map = ConcurrentHashMap<String, Entry>()
    private const val TTL = 15 * 60 * 1000L

    fun get(url: String): Deferred<MediaInfo> {
        val now = System.currentTimeMillis()
        map[url]?.let { if (now - it.time < TTL && !it.job.isCancelled) return it.job }
        val job = scope.async {
            try {
                resolve(url)
            } catch (e: Throwable) {
                map.remove(url) // never cache a failure
                throw e
            }
        }
        map[url] = Entry(now, job)
        if (map.size > 30) map.entries.minByOrNull { it.value.time }?.let { map.remove(it.key) }
        return job
    }

    /** Start loading in the background; errors are ignored here and shown when the user taps. */
    fun prefetch(url: String) {
        try {
            get(url)
        } catch (_: Throwable) {
        }
    }

    fun drop(url: String) {
        map.remove(url)
    }

    /** YouTube -> NewPipe (fast); anything else -> yt-dlp. yt-dlp is also the backup for YouTube. */
    private fun resolve(link: String): MediaInfo =
        if (UniversalRepo.isYouTube(link)) {
            try {
                YouTubeRepo.fetch(link)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                try { UniversalRepo.fetch(link) } catch (_: Throwable) { throw e }
            }
        } else UniversalRepo.fetch(link)
}
