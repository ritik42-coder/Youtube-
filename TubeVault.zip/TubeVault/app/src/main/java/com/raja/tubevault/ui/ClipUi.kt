package com.raja.tubevault.ui

import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.raja.tubevault.core.AudioDecoder
import com.raja.tubevault.core.ClipTools
import com.raja.tubevault.core.DownloadItem
import com.raja.tubevault.core.Downloads
import com.raja.tubevault.core.LocalStore
import com.raja.tubevault.core.MediaSaver
import com.raja.tubevault.core.Place
import com.raja.tubevault.core.PlayerHub
import com.raja.tubevault.core.Status
import com.raja.tubevault.core.Thumbs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** State + actions of the "Trim & ringtone" studio. */
object ClipStudio {
    var item by mutableStateOf<DownloadItem?>(null)
        private set
    var loading by mutableStateOf(false)
        private set
    var progress by mutableFloatStateOf(0f)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var peaks by mutableStateOf<FloatArray?>(null)
        private set
    var flat by mutableStateOf(false)
        private set
    var durMs by mutableLongStateOf(0L)
        private set
    var startMs by mutableLongStateOf(0L)
        private set
    var endMs by mutableLongStateOf(0L)
        private set
    var dragging by mutableStateOf(false)
    var fadeIdx by mutableStateOf(0)
    var ringKind by mutableStateOf(0)
    var busy by mutableStateOf(false)
        private set
    var message by mutableStateOf<String?>(null)
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var pending: Pair<Uri, Int>? = null

    fun open(ctx: Context, it: DownloadItem) {
        if (it.uri == null || it.place == Place.VAULT || !it.isAudio || it.status != Status.DONE) {
            Toast.makeText(ctx, "Only finished songs in your Library can be trimmed", Toast.LENGTH_SHORT).show()
            return
        }
        item = it
        peaks = null
        flat = false
        error = null
        message = null
        busy = false
        fadeIdx = 0
        ringKind = 0
        startMs = 0L
        endMs = 0L
        durMs = 0L
        loading = true
        progress = 0f
        val app = ctx.applicationContext
        scope.launch {
            try {
                val uri = Uri.parse(it.uri)
                val (p, d) = try {
                    ClipTools.waveform(app, uri) { x -> progress = x }
                } catch (e: AudioDecoder.TooLongException) {
                    // too long to draw: still allow cutting on a plain bar
                    flat = true
                    Pair(FloatArray(ClipTools.BARS) { 0.4f }, durationOf(app, uri))
                }
                peaks = p
                durMs = d
                // pick the loudest 30 s as a smart starting point
                val win = min(30_000L, d)
                endMs = win
                if (!flat && d > win) {
                    val w = max(1, (win * ClipTools.BARS / d).toInt())
                    var best = 0f
                    var bestI = 0
                    var run = 0f
                    for (i in 0 until ClipTools.BARS) {
                        run += p[i]
                        if (i >= w) run -= p[i - w]
                        if (i >= w - 1 && run > best) {
                            best = run
                            bestI = i - w + 1
                        }
                    }
                    startMs = (bestI.toLong() * d / ClipTools.BARS).coerceIn(0L, d - win)
                    endMs = startMs + win
                }
                loading = false
            } catch (e: Throwable) {
                loading = false
                error = e.message ?: "Couldn't read this song"
            }
        }
    }

    private fun durationOf(ctx: Context, uri: Uri): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } finally {
            try {
                r.release()
            } catch (_: Throwable) {
            }
        }
    }

    fun close() {
        item = null
        dragging = false
    }

    fun setHandle(which: Int, ms: Long) {
        if (which == 0) startMs = ms.coerceIn(0L, endMs - 500L)
        else endMs = ms.coerceIn(startMs + 500L, durMs)
    }

    fun nudge(which: Int, delta: Long) {
        setHandle(which, (if (which == 0) startMs else endMs) + delta)
    }

    fun setLength(lenMs: Long) {
        val s = min(startMs, max(0L, durMs - 500L))
        startMs = s
        endMs = min(durMs, s + lenMs)
        if (endMs - startMs < 500L) endMs = min(durMs, startMs + 500L)
    }

    private fun fadeMs(): Long = when (fadeIdx) {
        1 -> 1500L
        2 -> 3000L
        else -> 0L
    }

    private fun toast(ctx: Context, t: String) {
        Toast.makeText(ctx, t, Toast.LENGTH_LONG).show()
    }

    /** Cuts to a temp file. */
    private suspend fun cut(app: Context, it: DownloadItem, title: String): File {
        val dir = File(app.cacheDir, "clip").apply { mkdirs() }
        val out = File(dir, UUID.randomUUID().toString() + ".m4a")
        val f = fadeMs()
        withContext(Dispatchers.IO) {
            ClipTools.trim(app, Uri.parse(it.uri), startMs, endMs, if (f > 0) f else 0L, if (f > 0) f else 0L, out)
        }
        return withContext(Dispatchers.IO) { Thumbs.embed(out, title, it.uploader, null) }
    }

    fun saveAsNew(ctx: Context) {
        val src = item ?: return
        if (busy) return
        val app = ctx.applicationContext
        busy = true
        message = null
        scope.launch {
            try {
                val title = src.title + " (clip)"
                val file = cut(app, src, title)
                val name = MediaSaver.sanitize(title) + ".m4a"
                val size = file.length()
                val uri: String = withContext(Dispatchers.IO) {
                    if (src.place == Place.GALLERY) MediaSaver.save(app, file, name, "audio/mp4", true).toString()
                    else LocalStore.save(app, file, name)
                }
                Downloads.addFinished(
                    DownloadItem(
                        id = UUID.randomUUID().toString(), title = title, uploader = src.uploader,
                        thumbnail = src.thumbnail, label = "Clip M4A", isAudio = true, status = Status.DONE,
                        progress = 1f, speed = 0L, doneBytes = size, totalBytes = size, uri = uri,
                        error = null, createdAt = System.currentTimeMillis(), place = src.place
                    )
                )
                withContext(Dispatchers.IO) { file.delete() }
                message = "Saved to your Library"
                toast(app, "Saved \"$title\" to your Library ✂️")
            } catch (e: Throwable) {
                message = e.message ?: "Couldn't save the clip"
            } finally {
                busy = false
            }
        }
    }

    fun setAsRingtone(ctx: Context) {
        val src = item ?: return
        if (busy) return
        val app = ctx.applicationContext
        val kind = ringKind
        busy = true
        message = null
        scope.launch {
            try {
                val title = src.title + when (kind) {
                    1 -> " (notification)"
                    2 -> " (alarm)"
                    else -> " (ringtone)"
                }
                val file = cut(app, src, title)
                val uri = withContext(Dispatchers.IO) { ClipTools.saveToSystemSounds(app, file, title, kind) }
                withContext(Dispatchers.IO) { file.delete() }
                if (ClipTools.canWriteSettings(app)) {
                    ClipTools.setDefault(app, uri, kind)
                    message = "Done! It is now your " + kindName(kind)
                    toast(app, "Set as your " + kindName(kind) + " 🎉")
                } else {
                    pending = Pair(uri, kind)
                    message = "Allow \"Modify system settings\" for TubeVault, then come back."
                    try {
                        ctx.startActivity(
                            Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + app.packageName))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    } catch (_: Throwable) {
                        toast(app, "Saved to Ringtones. Choose it in Settings > Sound.")
                    }
                }
            } catch (e: Throwable) {
                message = e.message ?: "Couldn't create the ringtone"
            } finally {
                busy = false
            }
        }
    }

    private fun kindName(k: Int) = when (k) {
        1 -> "notification sound"
        2 -> "alarm sound"
        else -> "ringtone"
    }

    /** Called from Activity.onResume: finishes a ringtone that was waiting for the permission. */
    fun onResumed(ctx: Context) {
        val p = pending ?: return
        val app = ctx.applicationContext
        if (!ClipTools.canWriteSettings(app)) return
        pending = null
        try {
            ClipTools.setDefault(app, p.first, p.second)
            message = "Done! It is now your " + kindName(p.second)
            toast(app, "Set as your " + kindName(p.second) + " 🎉")
        } catch (e: Throwable) {
            message = e.message ?: "Couldn't set the ringtone"
        }
    }
}

private fun clipTime(ms: Long): String {
    val t = max(0L, ms)
    val m = t / 60000
    val s = (t / 1000) % 60
    val d = (t / 100) % 10
    return "%d:%02d.%d".format(m, s, d)
}

// ============================================================ host

@Composable
fun ClipStudioHost() {
    val it = ClipStudio.item
    val last = remember { arrayOfNulls<DownloadItem>(1) }
    if (it != null) last[0] = it
    BackHandler(enabled = it != null) { ClipStudio.close() }
    AnimatedVisibility(
        it != null,
        enter = fadeIn(tween(250)) + slideInVertically(tween(320)) { h -> h / 8 },
        exit = fadeOut(tween(220)) + slideOutVertically(tween(260)) { h -> h / 8 }
    ) {
        val song = last[0]
        if (song != null) ClipScreen(song)
    }
}

@Composable
private fun ClipChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Text(
        text,
        color = if (selected) Color.White else TextLo,
        fontWeight = FontWeight.SemiBold,
        fontSize = 13.sp,
        modifier = Modifier
            .clip(shape)
            .background(if (selected) AccentBrush else Brush.linearGradient(listOf(Glass, Glass)))
            .border(BorderStroke(1.dp, if (selected) Color.Transparent else GlassBorder), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@Composable
private fun TimeBox(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Glass)
            .border(BorderStroke(1.dp, GlassBorder), RoundedCornerShape(16.dp))
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, color = TextLo, fontSize = 11.sp)
        Text(value, color = TextHi, fontWeight = FontWeight.Black, fontSize = 17.sp)
    }
}

@Composable
private fun ClipScreen(song: DownloadItem) {
    val ctx = LocalContext.current
    val dur = ClipStudio.durMs
    val s = ClipStudio.startMs
    val e = ClipStudio.endMs
    var playing by remember { mutableStateOf(false) }
    var playhead by remember { mutableLongStateOf(0L) }

    val player = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(Unit) {
        try {
            PlayerHub.player(ctx).pause()
        } catch (_: Throwable) {
        }
        onDispose { player.release() }
    }

    // plays ONLY the selected part, looping, so you hear exactly what you will get
    LaunchedEffect(s, e, playing, ClipStudio.dragging, dur) {
        if (!playing || ClipStudio.dragging || dur <= 0L) {
            player.pause()
            return@LaunchedEffect
        }
        val clip = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(s)
            .setEndPositionMs(e)
            .build()
        val mi = MediaItem.Builder().setUri(Uri.parse(song.uri)).setClippingConfiguration(clip).build()
        player.setMediaItem(mi)
        player.repeatMode = Player.REPEAT_MODE_ONE
        player.prepare()
        player.play()
        while (true) {
            playhead = s + player.currentPosition
            delay(40)
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
    ) {
        // soft glows
        val t = rememberInfiniteTransition(label = "clipbg")
        val dr by t.animateFloat(0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse), label = "d")
        Canvas(Modifier.fillMaxSize()) {
            val c1 = Offset(size.width * (0.2f + 0.5f * dr), size.height * 0.12f)
            val c2 = Offset(size.width * (0.9f - 0.4f * dr), size.height * 0.7f)
            drawCircle(Brush.radialGradient(listOf(Pink.copy(alpha = 0.28f), Color.Transparent), center = c1, radius = size.width * 0.8f), size.width * 0.8f, c1)
            drawCircle(Brush.radialGradient(listOf(Violet.copy(alpha = 0.24f), Color.Transparent), center = c2, radius = size.width * 0.8f), size.width * 0.8f, c2)
        }

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Glass)
                        .clickable { ClipStudio.close() },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Close, null, tint = Color.White) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Trim & ringtone", color = TextHi, fontWeight = FontWeight.Black, fontSize = 20.sp)
                    Text(song.title, color = TextLo, fontSize = 12.sp, maxLines = 1)
                }
                Icon(Icons.Rounded.ContentCut, null, tint = Pink)
            }
            Spacer(Modifier.height(16.dp))

            // ---------------- waveform
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(176.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Glass)
                    .border(BorderStroke(1.dp, GlassBorder), RoundedCornerShape(24.dp))
                    .pointerInput(dur) {
                        var which = 0
                        detectDragGestures(
                            onDragStart = { o ->
                                val w = size.width.toFloat()
                                val sx = ClipStudio.startMs.toFloat() / max(1L, dur) * w
                                val ex = ClipStudio.endMs.toFloat() / max(1L, dur) * w
                                which = if (abs(o.x - sx) <= abs(o.x - ex)) 0 else 1
                                ClipStudio.dragging = true
                            },
                            onDragEnd = { ClipStudio.dragging = false },
                            onDragCancel = { ClipStudio.dragging = false },
                            onDrag = { change, _ ->
                                change.consume()
                                val ms = (change.position.x / size.width * dur).toLong()
                                ClipStudio.setHandle(which, ms)
                            }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                val pk = ClipStudio.peaks
                if (ClipStudio.loading || pk == null) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        if (ClipStudio.error == null) {
                            CircularProgressIndicator(Modifier.size(30.dp), color = Pink, strokeWidth = 3.dp)
                            Spacer(Modifier.height(10.dp))
                            Text("Drawing the waveform… ${(ClipStudio.progress * 100).toInt()}%", color = TextLo, fontSize = 13.sp)
                        } else {
                            Text(ClipStudio.error ?: "", color = Pink, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(16.dp))
                        }
                    }
                } else {
                    Canvas(Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        val n = pk.size
                        val slot = w / n
                        val bw = slot * 0.62f
                        val sx = s.toFloat() / max(1L, dur) * w
                        val ex = e.toFloat() / max(1L, dur) * w
                        val hot = Brush.verticalGradient(listOf(Pink, Violet))
                        for (i in 0 until n) {
                            val x = i * slot + (slot - bw) / 2f
                            val bh = max(4.dp.toPx(), pk[i] * h * 0.84f)
                            val inside = x + bw / 2f in sx..ex
                            if (inside) {
                                drawRoundRect(hot, Offset(x, (h - bh) / 2f), Size(bw, bh), CornerRadius(bw / 2f))
                            } else {
                                drawRoundRect(Color.White.copy(alpha = 0.22f), Offset(x, (h - bh) / 2f), Size(bw, bh), CornerRadius(bw / 2f))
                            }
                        }
                        // dim outside the selection
                        drawRect(Color(0x66000000), Offset(0f, 0f), Size(sx, h))
                        drawRect(Color(0x66000000), Offset(ex, 0f), Size(w - ex, h))
                        // handles
                        val hw = 3.dp.toPx()
                        drawRoundRect(Color.White, Offset(sx - hw / 2f, 0f), Size(hw, h), CornerRadius(hw))
                        drawRoundRect(Color.White, Offset(ex - hw / 2f, 0f), Size(hw, h), CornerRadius(hw))
                        drawCircle(Color.White, 9.dp.toPx(), Offset(sx, 14.dp.toPx()))
                        drawCircle(Pink, 5.dp.toPx(), Offset(sx, 14.dp.toPx()))
                        drawCircle(Color.White, 9.dp.toPx(), Offset(ex, h - 14.dp.toPx()))
                        drawCircle(Violet, 5.dp.toPx(), Offset(ex, h - 14.dp.toPx()))
                        if (playing) {
                            val px = (playhead.toFloat() / max(1L, dur) * w).coerceIn(sx, ex)
                            drawRect(Color(0xFFFFE066), Offset(px - 1.dp.toPx(), 0f), Size(2.dp.toPx(), h))
                        }
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(
                if (ClipStudio.flat) "Drag the two white handles. (This long song can't show its waveform, but cutting works.)"
                else "Drag the two white handles to choose your part. Tap play to hear only that part.",
                color = TextLo, fontSize = 12.sp
            )
            Spacer(Modifier.height(12.dp))

            // ---------------- times + fine tune
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TimeBox("Start", clipTime(s), Modifier.weight(1f))
                TimeBox("Length", clipTime(e - s), Modifier.weight(1f))
                TimeBox("End", clipTime(e), Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ClipChip("-0.1s", false) { ClipStudio.nudge(0, -100L) }
                    ClipChip("+0.1s", false) { ClipStudio.nudge(0, 100L) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ClipChip("-0.1s", false) { ClipStudio.nudge(1, -100L) }
                    ClipChip("+0.1s", false) { ClipStudio.nudge(1, 100L) }
                }
            }
            Spacer(Modifier.height(14.dp))

            // ---------------- listen
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(AccentBrush)
                        .clickable { playing = !playing },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(34.dp))
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (playing) "Listening to your cut (loops)" else "Listen to your cut", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Only the selected part plays", color = TextLo, fontSize = 12.sp)
                }
                ClipChip("Last 3 s", false) {
                    if (e - s > 3000L) ClipStudio.setHandle(0, e - 3000L)
                    playing = true
                }
            }
            Spacer(Modifier.height(16.dp))

            // ---------------- quick lengths
            Text("Quick length", color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ClipChip("15 s", false) { ClipStudio.setLength(15_000L) }
                ClipChip("30 s", false) { ClipStudio.setLength(30_000L) }
                ClipChip("45 s", false) { ClipStudio.setLength(45_000L) }
                ClipChip("60 s", false) { ClipStudio.setLength(60_000L) }
            }
            Spacer(Modifier.height(14.dp))
            Text("Fade in and out", color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Spacer(Modifier.height(6.dp))
            Segmented(listOf("None", "Soft", "Long"), ClipStudio.fadeIdx) { ClipStudio.fadeIdx = it }
            Text(
                if (ClipStudio.fadeIdx == 0) "No fade keeps the original quality (instant for most songs)."
                else "Fades re-encode the cut, which takes a few seconds.",
                color = TextLo, fontSize = 12.sp
            )
            Spacer(Modifier.height(18.dp))

            // ---------------- actions
            GradientButton(if (ClipStudio.busy) "Working…" else "Save as new song", ClipStudio.busy) {
                ClipStudio.saveAsNew(ctx)
            }
            Spacer(Modifier.height(16.dp))
            Text("Use as ringtone", color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ClipChip("Phone ringtone", ClipStudio.ringKind == 0) { ClipStudio.ringKind = 0 }
                ClipChip("Notification", ClipStudio.ringKind == 1) { ClipStudio.ringKind = 1 }
                ClipChip("Alarm", ClipStudio.ringKind == 2) { ClipStudio.ringKind = 2 }
            }
            Spacer(Modifier.height(8.dp))
            GradientButton(if (ClipStudio.busy) "Working…" else "Set as my " + when (ClipStudio.ringKind) {
                1 -> "notification sound"
                2 -> "alarm sound"
                else -> "ringtone"
            }, ClipStudio.busy) { ClipStudio.setAsRingtone(ctx) }
            val msg = ClipStudio.message
            if (msg != null) {
                Spacer(Modifier.height(10.dp))
                Text(msg, color = Color(0xFF7CF5B0), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            }
            Text(
                "Android asks once for \"Modify system settings\" the first time you set a ringtone.",
                color = TextLo, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp)
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}
