package com.raja.tubevault.core

import android.content.Context
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.UUID

/**
 * Private Vault: encrypted files in the app's private storage (no other app, Gallery or file
 * manager can see them), with random file names and an encrypted index, so even titles are hidden.
 * Opened with a password or the phone's fingerprint / face unlock. Locks when you leave the app.
 */
object Vault {
    data class Entry(
        val id: String,
        val title: String,
        val uploader: String,
        val label: String,
        val isAudio: Boolean,
        val size: Long,
        val time: Long,
        val file: String,
        val thumb: String?,
        val ext: String
    )

    private lateinit var app: Context
    private val lock = Any()
    private var entries: MutableList<Entry>? = null

    private val _items = MutableStateFlow<List<DownloadItem>>(emptyList())
    /** Visible only while unlocked. */
    val items: StateFlow<List<DownloadItem>> = _items.asStateFlow()

    var unlocked by mutableStateOf(false)
        private set
    /** Vault screen is open */
    var open by mutableStateOf(false)
    var count by mutableStateOf(0)
        private set

    private const val PREFS = "tv_vault"

    fun init(ctx: Context) {
        app = ctx.applicationContext
        Thread {
            try {
                synchronized(lock) { load() }
                count = entries?.size ?: 0
            } catch (_: Throwable) {
            }
        }.start()
    }

    private val dir get() = File(app.filesDir, "vault").apply { mkdirs() }
    private val prefs get() = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ----------------------------------------------------------------- password & lock

    fun hasPassword() = prefs.contains("hash")

    fun setPassword(pw: String) {
        val salt = VaultCrypto.newSalt()
        val h = VaultCrypto.hash(pw, salt)
        prefs.edit()
            .putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("hash", Base64.encodeToString(h, Base64.NO_WRAP))
            .putInt("fails", 0).putLong("lock_until", 0L)
            .apply()
    }

    /** Seconds the user must wait after too many wrong passwords (0 = can try now). */
    fun waitSeconds(): Int {
        val left = prefs.getLong("lock_until", 0L) - System.currentTimeMillis()
        return if (left > 0) ((left + 999) / 1000).toInt() else 0
    }

    /** Blocking (PBKDF2 takes ~0.3 s) – call from a background dispatcher. */
    fun checkPassword(pw: String): Boolean {
        if (waitSeconds() > 0) return false
        val salt = Base64.decode(prefs.getString("salt", "") ?: "", Base64.NO_WRAP)
        val want = Base64.decode(prefs.getString("hash", "") ?: "", Base64.NO_WRAP)
        val ok = want.isNotEmpty() && VaultCrypto.same(VaultCrypto.hash(pw, salt), want)
        if (ok) {
            prefs.edit().putInt("fails", 0).putLong("lock_until", 0L).apply()
        } else {
            val fails = prefs.getInt("fails", 0) + 1
            val wait = when {
                fails >= 10 -> 300_000L
                fails >= 5 -> 30_000L
                else -> 0L
            }
            prefs.edit().putInt("fails", fails).putLong("lock_until", System.currentTimeMillis() + wait).apply()
        }
        return ok
    }

    var biometric: Boolean
        get() = prefs.getBoolean("biometric", false)
        set(v) {
            prefs.edit().putBoolean("biometric", v).apply()
        }

    fun unlock() {
        unlocked = true
        publish()
    }

    fun lock() {
        unlocked = false
        _items.value = emptyList()
    }

    // ----------------------------------------------------------------- items

    private fun load() {
        if (entries != null) return
        val f = File(dir, "index.bin")
        val list = ArrayList<Entry>()
        if (f.exists()) {
            val arr = JSONArray(String(VaultCrypto.open(app, f.readBytes()), Charsets.UTF_8))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    Entry(
                        id = o.getString("id"), title = o.optString("title"), uploader = o.optString("up"),
                        label = o.optString("label"), isAudio = o.optBoolean("audio"), size = o.optLong("size"),
                        time = o.optLong("time"), file = o.getString("file"),
                        thumb = o.optString("thumb").ifEmpty { null }, ext = o.optString("ext", "mp4")
                    )
                )
            }
        }
        entries = list
    }

    private fun save() {
        val arr = JSONArray()
        for (e in entries ?: return) {
            arr.put(
                JSONObject().put("id", e.id).put("title", e.title).put("up", e.uploader).put("label", e.label)
                    .put("audio", e.isAudio).put("size", e.size).put("time", e.time).put("file", e.file)
                    .put("thumb", e.thumb ?: "").put("ext", e.ext)
            )
        }
        val tmp = File(dir, "index.tmp")
        tmp.writeBytes(VaultCrypto.seal(app, arr.toString().toByteArray(Charsets.UTF_8)))
        tmp.renameTo(File(dir, "index.bin"))
    }

    private fun publish() {
        val list = entries ?: emptyList()
        count = list.size
        if (!unlocked) return
        _items.value = list.sortedByDescending { it.time }.map { it.toItem() }
    }

    private fun Entry.toItem() = DownloadItem(
        id = id, title = title, uploader = uploader,
        thumbnail = thumb?.let { "tvthumb://$it" },
        label = label, isAudio = isAudio, status = Status.DONE, progress = 1f, speed = 0L,
        doneBytes = size, totalBytes = size, uri = "tvvault://$id", error = null, createdAt = time,
        place = Place.VAULT
    )

    /** Encrypts [input] into the vault. Blocking. */
    fun add(
        input: InputStream, title: String, uploader: String, label: String, isAudio: Boolean,
        ext: String, thumbJpeg: ByteArray?, onBytes: (Long) -> Unit = {}
    ): Entry {
        val id = "v_" + UUID.randomUUID().toString().replace("-", "")
        val name = UUID.randomUUID().toString().replace("-", "") + ".bin"
        val f = File(dir, name)
        try {
            VaultCrypto.encrypt(app, input, f, onBytes)
        } catch (e: Throwable) {
            f.delete()
            throw e
        }
        var thumbName: String? = null
        if (thumbJpeg != null && thumbJpeg.isNotEmpty()) {
            try {
                val tn = UUID.randomUUID().toString().replace("-", "") + ".thm"
                VaultCrypto.encrypt(app, ByteArrayInputStream(thumbJpeg), File(dir, tn))
                thumbName = tn
            } catch (_: Throwable) {
            }
        }
        val e = Entry(id, title, uploader, label, isAudio, f.length() - 16, System.currentTimeMillis(), name, thumbName, ext)
        synchronized(lock) {
            load()
            entries!!.add(e)
            save()
        }
        publish()
        return e
    }

    fun addFile(src: File, title: String, uploader: String, label: String, isAudio: Boolean, thumbJpeg: ByteArray?): Entry =
        src.inputStream().use { add(it, title, uploader, label, isAudio, src.extension.ifEmpty { if (isAudio) "m4a" else "mp4" }, thumbJpeg) }

    fun entry(id: String): Entry? = synchronized(lock) { load(); entries!!.firstOrNull { it.id == id } }

    fun fileFor(id: String): File? = entry(id)?.let { File(dir, it.file) }?.takeIf { it.exists() }

    fun thumbBytes(name: String): ByteArray? = try {
        val f = File(dir, name)
        if (!f.exists()) null else java.io.ByteArrayOutputStream().also { VaultCrypto.decrypt(app, f, it) }.toByteArray()
    } catch (_: Throwable) {
        null
    }

    /** Decrypts an item to [dest] (used when moving it out of the vault). Blocking. */
    fun exportTo(id: String, dest: File) {
        val f = fileFor(id) ?: throw IllegalStateException("This vault file is missing")
        FileOutputStream(dest).use { VaultCrypto.decrypt(app, f, it) }
    }

    fun delete(id: String) {
        synchronized(lock) {
            load()
            val e = entries!!.firstOrNull { it.id == id } ?: return
            File(dir, e.file).delete()
            e.thumb?.let { File(dir, it).delete() }
            entries!!.remove(e)
            save()
        }
        publish()
    }

    /** Wipes everything: files, index, password and key. */
    fun reset() {
        synchronized(lock) {
            dir.deleteRecursively()
            entries = mutableListOf()
            prefs.edit().clear().commit()
            VaultCrypto.destroy(app)
        }
        lock()
        count = 0
    }

    fun totalBytes(): Long = synchronized(lock) { entries?.sumOf { it.size } ?: 0L }
}
