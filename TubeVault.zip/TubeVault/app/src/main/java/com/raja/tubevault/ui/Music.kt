@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.raja.tubevault.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableFloatState
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.raja.tubevault.core.DownloadItem
import com.raja.tubevault.core.Fx
import com.raja.tubevault.core.PlayerHub
import com.raja.tubevault.core.Viz
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// ============================================================================ live visual data

/** Smoothed, UI-friendly copy of the real spectrum of the song being played. */
class VizState {
    val bands = FloatArray(Viz.BANDS)
    val peaks = FloatArray(Viz.BANDS)
    var level = 0f
    var bass = 0f
    var kick = 0f
    val tick = mutableLongStateOf(0L)
}

@Composable
fun rememberViz(active: Boolean): VizState {
    val st = remember { VizState() }
    val buf = remember { FloatArray(Viz.BANDS + 2) }
    LaunchedEffect(active) {
        var prevBass = 0f
        while (true) {
            val ok = active && Viz.read(buf)
            var energy = 0f
            for (i in 0 until Viz.BANDS) {
                val t = if (ok) buf[i] else 0f
                val c = st.bands[i]
                st.bands[i] = if (t > c) c + (t - c) * 0.65f else c + (t - c) * 0.13f
                st.peaks[i] = max(st.bands[i], st.peaks[i] - 0.010f)
                energy += st.bands[i]
            }
            val tl = if (ok) buf[Viz.BANDS] else 0f
            val tb = if (ok) buf[Viz.BANDS + 1] else 0f
            st.level += (tl - st.level) * (if (tl > st.level) 0.6f else 0.15f)
            st.bass += (tb - st.bass) * (if (tb > st.bass) 0.7f else 0.18f)
            st.kick = max(st.kick * 0.86f, (st.bass - prevBass).coerceAtLeast(0f) * 4f).coerceAtMost(1f)
            prevBass = st.bass
            st.tick.longValue = st.tick.longValue + 1
            if (!ok && energy < 0.05f && st.kick < 0.01f) delay(140) else withFrameNanos { }
        }
    }
    return st
}

/** Rotation that only advances while playing (vinyl feel). */
@Composable
fun rememberSpin(playing: Boolean, degPerSec: Float): MutableFloatState {
    val rot = remember { mutableFloatStateOf(0f) }
    val dps = androidx.compose.runtime.rememberUpdatedState(degPerSec)
    LaunchedEffect(playing) {
        if (playing) {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                rot.floatValue = (rot.floatValue + (now - last) / 1_000_000_000f * dps.value) % 360f
                last = now
            }
        }
    }
    return rot
}

private fun vizColor(t: Float): Color =
    if (t < 0.5f) lerp(Cyan, Violet, t * 2f) else lerp(Violet, Pink, (t - 0.5f) * 2f)

// ============================================================================ full-screen music stage

@Composable
fun AudioStage(item: DownloadItem, playing: Boolean, speed: Float, viz: VizState, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val style = PlayerHub.vizStyle

    val spec: AnimatedContentTransitionScope<DownloadItem>.() -> ContentTransform = {
        val d = PlayerHub.slideDir
        (slideInHorizontally(spring(dampingRatio = 0.8f, stiffness = 280f)) { d * it } +
            fadeIn(tween(260)) + scaleIn(tween(300), 0.82f)) togetherWith
            (slideOutHorizontally(tween(260)) { -d * it / 2 } + fadeOut(tween(160)) + scaleOut(tween(260), 0.82f))
    }

    Box(modifier.fillMaxSize().background(Color(0xFF07070D))) {
        Crossfade(item.thumbnail, animationSpec = tween(600), label = "bg") { t ->
            AsyncImage(
                model = ImageRequest.Builder(ctx).data(t).build(),
                contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().blur(52.dp).graphicsLayer { alpha = 0.45f }
            )
        }
        Canvas(Modifier.fillMaxSize()) {
            val k = viz.tick.longValue
            val b = viz.bass
            drawCircle(
                Brush.radialGradient(
                    listOf(Pink.copy(alpha = 0.10f + 0.34f * b), Color.Transparent),
                    center = Offset(size.width * 0.15f, size.height * 0.22f), radius = size.minDimension * (0.55f + 0.35f * b)
                ), size.minDimension, Offset(size.width * 0.15f, size.height * 0.22f)
            )
            drawCircle(
                Brush.radialGradient(
                    listOf(Violet.copy(alpha = 0.10f + 0.30f * viz.level), Color.Transparent),
                    center = Offset(size.width * 0.9f, size.height * 0.78f), radius = size.minDimension * (0.6f + 0.3f * viz.level)
                ), size.minDimension, Offset(size.width * 0.9f, size.height * 0.78f)
            )
            if (k < 0) drawCircle(Color.Transparent, 1f)
        }
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x66000000), Color(0xDD07070D)))))

        Column(
            Modifier.fillMaxSize().padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            AnimatedContent(item, transitionSpec = spec, contentKey = { it.id }, label = "disc") { it ->
                ArtDisc(it, playing, speed, viz, style)
            }
            Spacer(Modifier.height(6.dp))
            when (style) {
                0 -> BarsVisual(viz, Modifier.fillMaxWidth().height(78.dp))
                2 -> WaveVisual(viz, Modifier.fillMaxWidth().height(78.dp))
                else -> Spacer(Modifier.height(78.dp))
            }
            Spacer(Modifier.height(10.dp))
            AnimatedContent(item, transitionSpec = spec, contentKey = { it.id }, label = "title") { it ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        it.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp,
                        textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                    if (it.uploader.isNotEmpty()) {
                        Text(it.uploader, color = TextLo, fontSize = 13.sp, maxLines = 1)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            LedMeter(viz, Modifier.fillMaxWidth().height(12.dp))
        }
    }
}

@Composable
private fun ArtDisc(item: DownloadItem, playing: Boolean, speed: Float, viz: VizState, style: Int) {
    val ctx = LocalContext.current
    val rot = rememberSpin(playing, 26f * speed.coerceIn(0.25f, 3f))
    Box(Modifier.size(290.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val tk = viz.tick.longValue
            val r = size.minDimension
            val disc = 88.dp.toPx()
            // kick-driven expanding rings
            for (i in 0 until 3) {
                val ph = ((rot.floatValue / 120f) + i / 3f) % 1f
                drawCircle(
                    Pink.copy(alpha = (1f - ph) * (0.08f + 0.45f * viz.level)),
                    disc + ph * r * 0.17f, center, style = Stroke(1.8.dp.toPx())
                )
            }
            drawCircle(
                Brush.radialGradient(
                    listOf(Pink.copy(alpha = 0.15f + 0.5f * viz.kick), Color.Transparent),
                    center = center, radius = disc * 1.7f
                ), disc * 1.7f, center
            )
            if (style == 1) {
                val n = 72
                val inner = disc + 6.dp.toPx()
                val maxLen = r * 0.17f
                for (k in 0 until n) {
                    val bi = if (k < n / 2) k * Viz.BANDS / (n / 2) else (n - 1 - k) * Viz.BANDS / (n / 2)
                    val v = viz.bands[bi.coerceIn(0, Viz.BANDS - 1)]
                    val a = (2.0 * PI * k / n - PI / 2.0).toFloat()
                    val len = 3.dp.toPx() + v * maxLen
                    drawLine(
                        vizColor(k / n.toFloat()),
                        Offset(center.x + inner * cos(a), center.y + inner * sin(a)),
                        Offset(center.x + (inner + len) * cos(a), center.y + (inner + len) * sin(a)),
                        strokeWidth = 3.2.dp.toPx(), cap = StrokeCap.Round
                    )
                }
            }
            if (tk < 0) drawCircle(Color.Transparent, 1f)
        }
        Box(
            Modifier
                .size(176.dp)
                .graphicsLayer {
                    val t = viz.tick.longValue
                    val s = 1f + viz.bass * 0.07f + viz.kick * 0.05f + (if (t < 0) 1f else 0f)
                    scaleX = s; scaleY = s
                }
                .clip(CircleShape)
                .background(Color(0xFF14141E))
                .border(BorderStroke(3.dp, Color(0x40FFFFFF)), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            AsyncImage(
                model = ImageRequest.Builder(ctx).data(item.thumbnail).crossfade(true).build(),
                contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize().padding(9.dp).clip(CircleShape)
                    .graphicsLayer { rotationZ = rot.floatValue }
            )
            Box(Modifier.size(28.dp).clip(CircleShape).background(Color(0xFF07070D)))
        }
    }
}

@Composable
private fun BarsVisual(viz: VizState, modifier: Modifier) {
    Canvas(modifier) {
        val tk = viz.tick.longValue
        val n = Viz.BANDS
        val gap = 3.dp.toPx()
        val bw = (size.width - gap * (n - 1)) / n
        for (i in 0 until n) {
            val v = viz.bands[i]
            val h = (size.height * (0.04f + 0.96f * v)).coerceAtLeast(3.dp.toPx())
            val x = i * (bw + gap)
            drawRoundRect(
                Brush.verticalGradient(listOf(vizColor(i / n.toFloat()), Pink), startY = size.height - h, endY = size.height),
                Offset(x, size.height - h), Size(bw, h), CornerRadius(bw / 2f)
            )
            val ph = (size.height * (0.04f + 0.96f * viz.peaks[i])).coerceAtLeast(3.dp.toPx())
            drawRoundRect(
                Color.White.copy(alpha = 0.85f),
                Offset(x, size.height - ph - 5.dp.toPx()), Size(bw, 2.5.dp.toPx()), CornerRadius(2.dp.toPx())
            )
        }
        if (tk < 0) drawCircle(Color.Transparent, 1f)
    }
}

@Composable
private fun WaveVisual(viz: VizState, modifier: Modifier) {
    Canvas(modifier) {
        val tk = viz.tick.longValue
        val n = Viz.BANDS
        val cy = size.height / 2f
        val dx = size.width / (n - 1)
        val top = Path()
        val bot = Path()
        for (i in 0 until n) {
            val h = (2.dp.toPx() + viz.bands[i] * (size.height / 2f - 2.dp.toPx()))
            val x = i * dx
            if (i == 0) { top.moveTo(x, cy - h); bot.moveTo(x, cy + h) }
            else {
                val px = (i - 1) * dx
                val ph = (2.dp.toPx() + viz.bands[i - 1] * (size.height / 2f - 2.dp.toPx()))
                top.quadraticBezierTo(px, cy - ph, (px + x) / 2f, cy - (ph + h) / 2f)
                bot.quadraticBezierTo(px, cy + ph, (px + x) / 2f, cy + (ph + h) / 2f)
            }
        }
        val brush = Brush.horizontalGradient(listOf(Cyan, Violet, Pink))
        drawPath(top, brush, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
        drawPath(bot, brush, alpha = 0.55f, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
        drawLine(Color.White.copy(alpha = 0.12f), Offset(0f, cy), Offset(size.width, cy), 1.dp.toPx())
        if (tk < 0) drawCircle(Color.Transparent, 1f)
    }
}

/** Studio VU meter driven by the real loudness of the song. */
@Composable
private fun LedMeter(viz: VizState, modifier: Modifier) {
    Canvas(modifier) {
        val tk = viz.tick.longValue
        val n = 34
        val gap = 3.dp.toPx()
        val w = (size.width - gap * (n - 1)) / n
        val lit = (viz.level * n).roundToInt()
        for (i in 0 until n) {
            val on = i < lit
            val base = when {
                i < n * 0.62f -> Color(0xFF39E58C)
                i < n * 0.84f -> Color(0xFFFFC857)
                else -> Pink
            }
            drawRoundRect(
                if (on) base else base.copy(alpha = 0.12f),
                Offset(i * (w + gap), 0f), Size(w, size.height), CornerRadius(3.dp.toPx())
            )
        }
        if (tk < 0) drawCircle(Color.Transparent, 1f)
    }
}

// ============================================================================ Dynamic Island

/** Floating pill at the top of the app while music plays. Tap = expand, tap art = open player. */
@Composable
fun MusicIsland() {
    val show = PlayerHub.hasMusic && PlayerHost.request == null
    var expanded by remember { mutableStateOf(false) }
    LaunchedEffect(show) { if (!show) expanded = false }
    Box(Modifier.fillMaxWidth().statusBarsPadding().padding(top = 6.dp), contentAlignment = Alignment.TopCenter) {
        AnimatedVisibility(
            visible = show,
            enter = slideInVertically(spring(dampingRatio = 0.55f, stiffness = 300f)) { -it * 2 } +
                fadeIn(tween(200)) + scaleIn(spring(dampingRatio = 0.6f, stiffness = 320f), 0.5f),
            exit = slideOutVertically(tween(260)) { -it * 2 } + fadeOut(tween(200)) + scaleOut(tween(220), 0.6f)
        ) {
            IslandBody(expanded) { expanded = !expanded }
        }
    }
}

@Composable
private fun IslandBody(expanded: Boolean, onToggle: () -> Unit) {
    val ctx = LocalContext.current
    val item = PlayerHub.current ?: return
    val playing = PlayerHub.isPlaying
    val viz = rememberViz(playing)
    val haptic = rememberHaptics()
    val corner by animateDpAsState(if (expanded) 30.dp else 26.dp, spring(dampingRatio = 0.7f, stiffness = 320f), label = "ic")
    val glow = if (playing) Pink.copy(alpha = 0.55f) else GlassBorder
    val player = remember { PlayerHub.player(ctx) }

    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var scrub by remember { mutableFloatStateOf(-1f) }
    LaunchedEffect(expanded, playing) {
        while (true) {
            pos = player.currentPosition
            val d = player.duration
            if (d > 0L) dur = d
            delay(if (expanded) 250L else 1000L)
        }
    }

    Box(Modifier.padding(horizontal = 12.dp).animateContentSize(spring(dampingRatio = 0.72f, stiffness = 320f))) {
        Box(
            Modifier
                .then(if (expanded) Modifier.fillMaxWidth() else Modifier)
                .clip(RoundedCornerShape(corner))
                .background(Color(0xF2050508))
                .border(BorderStroke(1.dp, glow), RoundedCornerShape(corner))
        ) {
            Crossfade(expanded, animationSpec = tween(220), label = "isl") { ex ->
                if (!ex) {
                    // ---------- compact
                    Row(
                        Modifier
                            .pressable { haptic(HapticFeedbackType.TextHandleMove); onToggle() }
                            .padding(start = 7.dp, end = 12.dp, top = 6.dp, bottom = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(9.dp)
                    ) {
                        SpinArt(item, playing, 32.dp)
                        MiniBars(viz, Modifier.size(width = 26.dp, height = 20.dp))
                        Text(
                            item.title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 130.dp)
                        )
                        Icon(
                            if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Color.White,
                            modifier = Modifier.size(22.dp).pressable { PlayerHub.playPause(ctx) }
                        )
                    }
                } else {
                    // ---------- expanded
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(Modifier.pressable { PlayerHost.request = PlayRequest(PlayerHub.queue, PlayerHub.index) }) {
                                SpinArt(item, playing, 56.dp)
                            }
                            Column(Modifier.weight(1f).pressable { onToggle() }) {
                                Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    item.uploader.ifEmpty { "TubeVault" }, color = TextLo, fontSize = 12.sp, maxLines = 1
                                )
                            }
                            PlayerIconButton(Icons.Rounded.Close, { PlayerHub.stop(ctx) }, size = 34.dp)
                        }
                        BarsVisual(viz, Modifier.fillMaxWidth().height(34.dp))
                        val frac = if (scrub >= 0f) scrub else if (dur > 0L) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
                        GlowSlider(
                            value = frac,
                            onChange = { scrub = it },
                            onFinished = {
                                if (scrub >= 0f && dur > 0L) player.seekTo((scrub * dur).toLong())
                                scrub = -1f
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = listOf(Pink, Orange)
                        )
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(fmtTime(if (scrub >= 0f) (scrub * dur).toLong() else pos), color = TextLo, fontSize = 11.sp)
                            Spacer(Modifier.weight(1f))
                            Text(fmtTime(dur), color = TextLo, fontSize = 11.sp)
                        }
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            PlayerIconButton(Icons.Rounded.SkipPrevious, { PlayerHub.previous(ctx) }, size = 44.dp)
                            Box(
                                Modifier.size(58.dp).pressable { PlayerHub.playPause(ctx); haptic(HapticFeedbackType.TextHandleMove) }
                                    .clip(CircleShape).background(AccentBrush2),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(32.dp))
                            }
                            PlayerIconButton(Icons.Rounded.SkipNext, { PlayerHub.next(ctx) }, size = 44.dp, enabled = true)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SpinArt(item: DownloadItem, playing: Boolean, size: Dp) {
    val ctx = LocalContext.current
    val rot = rememberSpin(playing, 36f)
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(Color(0xFF14141E))
            .border(BorderStroke(1.5.dp, Color(0x55FFFFFF)), CircleShape)
            .graphicsLayer { rotationZ = rot.floatValue }
    ) {
        AsyncImage(
            model = ImageRequest.Builder(ctx).data(item.thumbnail).crossfade(true).build(),
            contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
private fun MiniBars(viz: VizState, modifier: Modifier) {
    Canvas(modifier) {
        val tk = viz.tick.longValue
        val idx = intArrayOf(1, 5, 10, 17, 25)
        val gap = 2.5.dp.toPx()
        val w = (size.width - gap * (idx.size - 1)) / idx.size
        for ((n, b) in idx.withIndex()) {
            val v = viz.bands[b]
            val h = (size.height * (0.18f + 0.82f * v)).coerceAtLeast(3.dp.toPx())
            drawRoundRect(
                Brush.verticalGradient(listOf(Orange, Pink)),
                Offset(n * (w + gap), size.height - h), Size(w, h), CornerRadius(w / 2f)
            )
        }
        if (tk < 0) drawCircle(Color.Transparent, 1f)
    }
}

// ============================================================================ Sound Lab

@Composable
private fun VerticalGlowSlider(value: Float, onChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    // value in -12..12 dB
    var hPx by remember { mutableFloatStateOf(1f) }
    var dragging by remember { mutableStateOf(false) }
    val haptic = rememberHaptics()
    val grow by animateFloatAsState(if (dragging) 1f else 0f, spring(dampingRatio = 0.5f, stiffness = 400f), label = "vg")
    val shown by animateFloatAsState(value, tween(if (dragging) 0 else 160), label = "vv")
    fun toDb(y: Float) = ((0.5f - (y / hPx)) * 24f).coerceIn(-12f, 12f).let { (it * 2f).roundToInt() / 2f }
    Box(
        modifier
            .onSizeChanged { hPx = it.height.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) { detectTapGestures { o -> onChange(toDb(o.y)); haptic(HapticFeedbackType.TextHandleMove) } }
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { o -> dragging = true; onChange(toDb(o.y)) },
                    onDragEnd = { dragging = false },
                    onDragCancel = { dragging = false },
                    onVerticalDrag = { c, _ -> c.consume(); onChange(toDb(c.position.y)) }
                )
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val pad = 12.dp.toPx()
            val h = size.height - pad * 2f
            val y = pad + h * (0.5f - shown / 24f)
            val mid = pad + h / 2f
            val tw = (5f + 3f * grow).dp.toPx()
            drawRoundRect(Color(0x33FFFFFF), Offset(cx - tw / 2f, pad), Size(tw, h), CornerRadius(tw / 2f))
            drawLine(Color.White.copy(alpha = 0.35f), Offset(cx - 11.dp.toPx(), mid), Offset(cx + 11.dp.toPx(), mid), 1.5.dp.toPx())
            val top = min(y, mid)
            val hh = abs(y - mid)
            if (hh > 0.5f) {
                drawRoundRect(
                    Brush.verticalGradient(if (shown >= 0f) listOf(Pink, Orange) else listOf(Cyan, Violet), startY = top, endY = top + hh),
                    Offset(cx - tw / 2f, top), Size(tw, hh), CornerRadius(tw / 2f)
                )
            }
            val gr = (20f + 8f * grow).dp.toPx()
            drawCircle(Brush.radialGradient(listOf(Pink.copy(alpha = 0.5f), Color.Transparent), center = Offset(cx, y), radius = gr), gr, Offset(cx, y))
            drawCircle(Color.White, (8f + 3f * grow).dp.toPx(), Offset(cx, y))
            drawCircle(Pink, (3.5f + 1.5f * grow).dp.toPx(), Offset(cx, y))
        }
    }
}

@Composable
private fun PresetChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val sc by animateFloatAsState(if (selected) 1.08f else 1f, spring(dampingRatio = 0.5f, stiffness = 500f), label = "pc")
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .pressable(onClick)
            .clip(shape)
            .then(if (selected) Modifier.background(AccentBrush) else Modifier.background(Glass))
            .border(BorderStroke(1.dp, if (selected) Color.Transparent else GlassBorder), shape)
            .padding(horizontal = 15.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
}

@Composable
private fun FxSlider(label: String, value: Float, display: String, onChange: (Float) -> Unit, colors: List<Color> = listOf(Pink, Orange)) {
    Column {
        Row {
            Text(label, color = TextLo, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text(display, color = TextHi, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        GlowSlider(value, onChange, Modifier.fillMaxWidth(), colors = colors)
    }
}

@Composable
private fun DjPad(label: String, sub: String, held: Boolean, modifier: Modifier, onHold: (Boolean) -> Unit) {
    val haptic = rememberHaptics()
    val sc by animateFloatAsState(if (held) 0.93f else 1f, spring(dampingRatio = 0.5f, stiffness = 600f), label = "pad")
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .clip(shape)
            .then(if (held) Modifier.background(AccentBrush2) else Modifier.background(Glass))
            .border(BorderStroke(1.dp, if (held) Color.Transparent else GlassBorder), shape)
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    onHold(true)
                    haptic(HapticFeedbackType.LongPress)
                    tryAwaitRelease()
                    onHold(false)
                })
            }
            .padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
        Text(sub, color = if (held) Color.White else TextLo, fontSize = 11.sp)
    }
}

/**
 * Presets, 5-band EQ, bass, 3D width, reverb, echo, 8D, DJ filter and hold-to-play DJ pads.
 * [onSpeed] lets presets like Nightcore / Slowed set playback speed and pitch.
 */
@Composable
fun SoundLabContent(onSpeed: (Float, Boolean) -> Unit) {
    val ctx = LocalContext.current
    val viz = rememberViz(PlayerHub.isPlaying)
    DisposableEffect(Unit) { onDispose { Fx.save(ctx) } }
    val eq = Fx.eq
    val names = Fx.presets.map { it.name } + "Nightcore"

    Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Sound Lab", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Live studio effects on the real audio", color = TextLo, fontSize = 12.sp)
            }
            PremiumSwitch(Fx.enabled) { Fx.enabled = it; Fx.touch() }
        }
        BarsVisual(viz, Modifier.fillMaxWidth().height(54.dp))

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(names) { n ->
                PresetChip(n, Fx.preset == n) {
                    if (n == "Nightcore") {
                        Fx.apply(com.raja.tubevault.core.FxPreset("Nightcore", listOf(0f, 0f, 1f, 3f, 4f), width = 0.3f, reverb = 0.12f))
                        onSpeed(1.25f, false)
                    } else {
                        val p = Fx.presets.first { it.name == n }
                        Fx.apply(p)
                        if (n == "Slowed Reverb") onSpeed(0.85f, false)
                    }
                }
            }
        }

        // ---- EQ
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            for (b in 0 until 5) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        (if (eq[b] > 0f) "+" else "") + (if (eq[b] % 1f == 0f) eq[b].toInt().toString() else eq[b].toString()),
                        color = if (abs(eq[b]) > 0.1f) Pink else TextLo, fontSize = 12.sp, fontWeight = FontWeight.Bold
                    )
                    VerticalGlowSlider(eq[b], { Fx.setBand(b, it) }, Modifier.width(46.dp).height(150.dp))
                    Text(Fx.BAND_LABELS[b], color = TextLo, fontSize = 11.sp)
                }
            }
        }

        FxSlider("Bass boost", Fx.bass, "${(Fx.bass * 100).roundToInt()}%", { Fx.bass = it; Fx.preset = "Custom"; Fx.touch() })
        FxSlider("3D width", Fx.width, "${(Fx.width * 100).roundToInt()}%", { Fx.width = it; Fx.preset = "Custom"; Fx.touch() }, listOf(Cyan, Violet))
        FxSlider("Reverb", Fx.reverb, "${(Fx.reverb * 100).roundToInt()}%", { Fx.reverb = it; Fx.preset = "Custom"; Fx.touch() }, listOf(Violet, Pink))
        FxSlider("Echo", Fx.echo, "${(Fx.echo * 100).roundToInt()}%", { Fx.echo = it; Fx.preset = "Custom"; Fx.touch() }, listOf(Cyan, Pink))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("8D spin", color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Text("Sound circles around your head (use earphones)", color = TextLo, fontSize = 12.sp)
            }
            PremiumSwitch(Fx.spin8d) { Fx.spin8d = it; Fx.preset = "Custom"; Fx.touch() }
        }

        // ---- DJ
        Text("DJ deck", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        val dj = Fx.dj
        FxSlider(
            "DJ filter  (left = muffle, right = thin)",
            (dj + 1f) / 2f,
            when {
                dj < -0.02f -> "Low-pass"
                dj > 0.02f -> "High-pass"
                else -> "Off"
            },
            { v -> Fx.dj = if (abs(v - 0.5f) < 0.03f) 0f else (v * 2f - 1f); Fx.touch() },
            listOf(Orange, Pink)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            DjPad("BASS DROP", "hold", Fx.padBass, Modifier.weight(1f)) { Fx.padBass = it }
            DjPad("ECHO OUT", "hold", Fx.padEcho, Modifier.weight(1f)) { Fx.padEcho = it }
            DjPad("WASH", "hold", Fx.padWash, Modifier.weight(1f)) { Fx.padWash = it }
        }
        Box(
            Modifier
                .pressable {
                    Fx.apply(Fx.presets.first())
                    onSpeed(1f, true)
                }
                .clip(RoundedCornerShape(50))
                .background(Glass)
                .border(BorderStroke(1.dp, GlassBorder), RoundedCornerShape(50))
                .padding(horizontal = 18.dp, vertical = 9.dp)
                .align(Alignment.CenterHorizontally)
        ) { Text("Reset everything", color = TextHi, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
        Spacer(Modifier.height(14.dp))
    }
}
