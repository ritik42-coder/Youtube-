package com.raja.tubevault.core

import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONObject
import java.io.File
import java.util.Locale

/**
 * Universal engine: every non-YouTube link goes through yt-dlp (1,800+ supported sites).
 * yt-dlp keeps itself up to date (once a day, and again whenever a site fails),
 * so sites that change their pages keep working without a new APK.
 */
object UniversalRepo {
    private lateinit var app: Context
    @Volatile private var ready = false
    @Volatile private var updatedThisSession = false
    private val lock = Any()

    private const val PREFS = "tubevault_engine"
    private const val KEY_LAST_UPDATE = "last_update"
    private const val DAY = 24L * 60 * 60 * 1000

    /** "out.mp4" – not the leftovers "out.f137.mp4", "out.mp4.part", "out.temp.mp4". */
    private val FINAL = Regex("^out\\.(mp4|m4a|webm|mkv|mp3|opus|ogg|m4v|3gp|flv|mov|aac)$", RegexOption.IGNORE_CASE)

    private val YT = Regex("^https?://([\\w-]+\\.)?(youtube\\.com|youtu\\.be|youtube-nocookie\\.com)/", RegexOption.IGNORE_CASE)

    fun isYouTube(url: String) = YT.containsMatchIn(url.trim())

    /** Called from App.onCreate: unpacks the engine in the background so the first link is fast. */
    fun warmUp(ctx: Context) {
        app = ctx.applicationContext
        Thread {
            try {
                ensureReady()
                val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                if (System.currentTimeMillis() - prefs.getLong(KEY_LAST_UPDATE, 0L) > DAY) updateEngine()
            } catch (_: Throwable) {
            }
        }.apply { isDaemon = true; name = "tv-engine-warmup" }.start()
    }

    private fun ensureReady() {
        if (ready) return
        synchronized(lock) {
            if (ready) return
            YoutubeDL.getInstance().init(app)
            FFmpeg.getInstance().init(app)
            ready = true
        }
    }

    /** Downloads the newest yt-dlp. Returns true when it ran without error. */
    fun updateEngine(): Boolean = try {
        ensureReady()
        YoutubeDL.getInstance().updateYoutubeDL(app, YoutubeDL.UpdateChannel.STABLE)
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putLong(KEY_LAST_UPDATE, System.currentTimeMillis()).apply()
        updatedThisSession = true
        true
    } catch (_: Throwable) {
        false
    }

    fun engineVersion(): String? = try {
        ensureReady(); YoutubeDL.getInstance().version(app)
    } catch (_: Throwable) {
        null
    }

    // ------------------------------------------------------------------ info

    /** Blocking – call from a background dispatcher. */
    fun fetch(url: String): MediaInfo {
        ensureReady()
        val json = try {
            dumpJson(url)
        } catch (e: Throwable) {
            // Sites change all the time: grab the newest yt-dlp once and try again.
            if (!updatedThisSession && !isPermanent(e) && updateEngine()) dumpJson(url) else throw e
        }
        return parse(url, JSONObject(json))
    }

    private fun dumpJson(url: String): String {
        val req = YoutubeDLRequest(url).apply {
            addOption("--dump-single-json")
            addOption("--no-playlist")
            addOption("--playlist-items", "1")
            addOption("--no-warnings")
            addOption("--socket-timeout", "20")
        }
        val out = YoutubeDL.getInstance().execute(req).out
        // If a page is a playlist/gallery, the first entry is used.
        val start = out.indexOf('{')
        if (start < 0) throw IllegalStateException("This page didn't return any video.")
        return out.substring(start)
    }

    private fun parse(url: String, root: JSONObject): MediaInfo {
        val o = root.optJSONArray("entries")?.optJSONObject(0) ?: root
        if (o.optBoolean("is_live")) {
            throw IllegalStateException("Live streams can't be downloaded. Try again after the stream has ended.")
        }
        val duration = o.optDouble("duration", 0.0).let { if (it.isNaN()) 0L else it.toLong() }
        val formats = o.optJSONArray("formats")

        data class F(val height: Int, val fps: Int, val size: Long)
        val vids = ArrayList<F>()
        var hasAudioOnly = false
        if (formats != null) {
            for (i in 0 until formats.length()) {
                val f = formats.optJSONObject(i) ?: continue
                val vcodec = f.str("vcodec", "")
                val acodec = f.str("acodec", "")
                val proto = f.str("protocol", "")
                if (proto.contains("mhtml") || f.str("format_note").contains("storyboard", true)) continue
                val h = f.optInt("height", 0)
                if (vcodec == "none") {
                    if (acodec.isNotEmpty() && acodec != "none") hasAudioOnly = true
                    continue
                }
                if (h <= 0) continue
                var size = f.optLong("filesize", 0L).takeIf { it > 0 } ?: f.optLong("filesize_approx", 0L)
                if (size <= 0) {
                    val tbr = f.optDouble("tbr", 0.0)
                    if (!tbr.isNaN() && tbr > 0 && duration > 0) size = (tbr * 1000 / 8 * duration).toLong()
                }
                vids.add(F(h, f.optDouble("fps", 0.0).let { if (it.isNaN()) 0 else it.toInt() }, size))
            }
        }
        if (vids.isEmpty() && o.optInt("height", 0) > 0) vids.add(F(o.optInt("height"), 0, 0L))

        val videoFormats = vids.groupBy { it.height }
            .map { (_, g) -> g.maxByOrNull { it.size }!! }
            .sortedByDescending { it.height }
            .take(8)
            .map { f ->
                val tag = when {
                    f.height >= 2160 -> "4K"
                    f.height >= 1440 -> "2K"
                    f.height >= 1080 -> "Full HD"
                    f.height >= 720 -> "HD"
                    else -> "SD"
                }
                val fps = if (f.fps > 30) " ${f.fps}fps" else ""
                FormatOption(
                    key = "u-${f.height}",
                    label = "${f.height}p$fps",
                    detail = "MP4 • $tag" + (if (f.size > 0) " • ~${formatBytes(f.size)}" else ""),
                    isAudio = false, video = null, audio = null, needsMerge = false,
                    sizeBytes = f.size,
                    ytdlpFormat = "bv*[height<=${f.height}]+ba/b[height<=${f.height}]/bv*+ba/b"
                )
            }.toMutableList()

        if (videoFormats.isEmpty()) {
            // Site gives no resolution info: just take the best it has.
            videoFormats.add(
                FormatOption(
                    key = "u-best", label = "Best", detail = "MP4 • Best available",
                    isAudio = false, video = null, audio = null, needsMerge = false,
                    sizeBytes = 0L, ytdlpFormat = "bv*+ba/b"
                )
            )
        }

        val audioFormats = listOf(
            FormatOption(
                key = "u-audio", label = "M4A",
                detail = "AAC • " + if (hasAudioOnly) "Best quality" else "Taken from the video",
                isAudio = true, video = null, audio = null, needsMerge = false,
                sizeBytes = 0L, ytdlpFormat = "ba[ext=m4a]/ba/b"
            )
        )

        val thumb = o.str("thumbnail").ifBlank { null }
            ?: o.optJSONArray("thumbnails")?.let { arr ->
                (arr.length() - 1 downTo 0).firstNotNullOfOrNull { arr.optJSONObject(it)?.str("url")?.ifBlank { null } }
            }

        val pageUrl = o.str("webpage_url").ifBlank { url }
        return MediaInfo(
            id = o.str("id").ifBlank { pageUrl.hashCode().toString() },
            url = pageUrl,
            title = o.str("title").ifBlank { o.str("fulltitle").ifBlank { "Video" } },
            uploader = o.str("uploader").ifBlank { o.str("channel").ifBlank { o.str("extractor_key") } },
            durationSec = duration,
            thumbnail = thumb,
            videoFormats = videoFormats,
            audioFormats = audioFormats
        )
    }

    /** Android's optString turns JSON null into the text "null" – treat that as empty. */
    private fun JSONObject.str(key: String, fallback: String = ""): String {
        if (isNull(key)) return fallback
        return optString(key, fallback)
    }

    // ------------------------------------------------------------------ download

    class Progress(val fraction: Float, val speed: Long, val postProcessing: Boolean)

    /**
     * Downloads [opt] into [dir] and returns the finished file. Blocking.
     * [processId] lets [cancel] stop it.
     */
    fun download(
        url: String,
        opt: FormatOption,
        dir: File,
        processId: String,
        onProgress: (Progress) -> Unit
    ): File {
        ensureReady()
        val req = YoutubeDLRequest(url).apply {
            addOption("-f", opt.ytdlpFormat ?: "bv*+ba/b")
            // Phone-friendly first: H.264 video + AAC audio in MP4 when the site offers it.
            addOption("-S", "res,vcodec:h264,acodec:m4a,ext:mp4")
            addOption("-o", File(dir, "out.%(ext)s").absolutePath)
            addOption("--no-playlist")
            addOption("--playlist-items", "1")
            addOption("--no-mtime")
            addOption("--no-warnings")
            addOption("--newline")
            addOption("-N", "4")                // parallel fragments: much faster on HLS sites
            addOption("--retries", "10")
            addOption("--fragment-retries", "10")
            addOption("--socket-timeout", "20")
            addOption("--cache-dir", File(app.cacheDir, "ytdlp-cache").absolutePath)
            if (opt.isAudio) {
                addOption("-x")
                addOption("--audio-format", "m4a")
                addOption("--audio-quality", "0")
            } else {
                addOption("--merge-output-format", "mp4")
                addOption("--remux-video", "mp4")
            }
        }

        var phase = 0
        var last = 0f
        var lastEmit = 0L
        val speedRx = Regex("at\\s+([\\d.]+)\\s*([KMG]?)i?B/s")
        val run = {
            YoutubeDL.getInstance().execute(req, processId = processId, callback = { pct: Float, _: Long, line: String ->
                val post = line.startsWith("[Merger]") || line.startsWith("[ExtractAudio]") ||
                    line.startsWith("[VideoRemuxer]") || line.startsWith("[FixupM3u8]") || line.startsWith("[Fixup")
                val now = android.os.SystemClock.elapsedRealtime()
                if (post) {
                    onProgress(Progress(-1f, 0L, true))
                } else if (pct >= 0f && (now - lastEmit >= 250 || pct >= 100f)) {
                    lastEmit = now
                    // Video + audio download one after another: show it as one smooth bar.
                    if (last > 90f && pct < 10f) phase++
                    last = pct
                    val frac = pct / 100f
                    val speed = speedRx.find(line)?.let { m ->
                        val n = m.groupValues[1].toDoubleOrNull() ?: 0.0
                        val mul = when (m.groupValues[2]) { "K" -> 1024.0; "M" -> 1048576.0; "G" -> 1073741824.0; else -> 1.0 }
                        (n * mul).toLong()
                    } ?: 0L
                    val shown = when {
                        opt.isAudio -> frac
                        phase == 0 -> frac * 0.85f
                        else -> 0.85f + frac * 0.14f
                    }
                    onProgress(Progress(shown.coerceIn(0f, 0.99f), speed, false))
                }
            })
        }
        try {
            run()
        } catch (e: Throwable) {
            if (cancelled.remove(processId)) throw e
            if (!updatedThisSession && !isPermanent(e) && updateEngine()) {
                dir.listFiles()?.forEach { it.deleteRecursively() }
                phase = 0; last = 0f
                run()
            } else throw e
        }

        cancelled.remove(processId)
        return dir.listFiles()
            ?.filter { it.isFile && FINAL.matches(it.name) }
            ?.maxByOrNull { it.length() }
            ?: dir.listFiles()?.filter { it.isFile && it.length() > 0 && !it.name.endsWith(".part") }?.maxByOrNull { it.length() }
            ?: throw IllegalStateException("The download finished but no file was produced. Please retry.")
    }

    private val cancelled = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()

    fun cancel(processId: String) {
        cancelled.add(processId)
        try {
            YoutubeDL.getInstance().destroyProcessById(processId)
        } catch (_: Throwable) {
        }
    }

    fun mimeFor(file: File, audio: Boolean): String = when (file.extension.lowercase(Locale.ROOT)) {
        "mp4", "m4v" -> "video/mp4"
        "m4a" -> "audio/mp4"
        "webm" -> if (audio) "audio/webm" else "video/webm"
        "mkv" -> "video/x-matroska"
        "mp3" -> "audio/mpeg"
        "opus", "ogg" -> "audio/ogg"
        "3gp" -> "video/3gpp"
        "flv" -> "video/x-flv"
        else -> if (audio) "audio/mp4" else "video/mp4"
    }

    // ------------------------------------------------------------------ errors

    /** Errors where updating yt-dlp won't help. */
    private fun isPermanent(e: Throwable): Boolean {
        val m = (e.message ?: "").lowercase(Locale.ROOT)
        return listOf(
            "unable to download webpage", "network is unreachable", "name or service not known",
            "timed out", "private video", "has been removed", "has been disabled", "not available",
            "premium", "login", "sign in", "403: forbidden", "404", "geo"
        ).any { it in m }
    }

    /** Turns yt-dlp's stderr into one short readable sentence, or null if it isn't a yt-dlp error. */
    fun friendly(msg: String?): String? {
        if (msg.isNullOrBlank()) return null
        val line = msg.lineSequence().lastOrNull { it.trimStart().startsWith("ERROR:") } ?: return null
        val clean = line.substringAfter("ERROR:").trim()
            .replace(Regex("^\\[[^]]+]\\s*[^:]{0,40}:\\s*"), "")
            .trim()
        val low = clean.lowercase(Locale.ROOT)
        return when {
            "unsupported url" in low -> "This link isn't a supported video page. Open the video itself and copy its link."
            "unable to download webpage" in low || "name or service not known" in low || "network is unreachable" in low ->
                "Couldn't reach the site. Check your internet (some sites need a VPN in your country)."
            "geo" in low || "not available in your country" in low -> "This video is blocked in your country. A VPN may help."
            "private" in low -> "This video is private."
            "premium" in low || "login" in low || "sign in" in low || "members" in low ->
                "This video needs a paid account or login, so it can't be downloaded."
            "removed" in low || "disabled" in low || "deleted" in low || "404" in low -> "This video has been removed from the site."
            "403" in low -> "The site refused the download (403). Tap retry."
            "requested format is not available" in low -> "That quality isn't available any more. Pick another one."
            else -> clean.take(200)
        }
    }
}
