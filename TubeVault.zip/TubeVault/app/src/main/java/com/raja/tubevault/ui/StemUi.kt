package com.raja.tubevault.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raja.tubevault.core.AiStems
import com.raja.tubevault.core.DownloadItem
import com.raja.tubevault.core.Place

/** "AI voice remover" block in the Karaoke panel. */
@Composable
fun AiVoiceSection(item: DownloadItem) {
    val ctx = LocalContext.current
    val hasStem = AiStems.hasStem(ctx, item.id)
    val running = AiStems.jobItemId == item.id
    val otherRunning = AiStems.jobItemId != null && !running
    var best by remember { mutableStateOf(true) }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("AI voice remover (best quality)", color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
        Text(
            "An AI model on your phone splits the song and keeps only the music, with no singer. Free, offline, and your songs never leave the phone.",
            color = TextLo, fontSize = 12.sp
        )
        when {
            item.place == Place.VAULT || item.uri == null ->
                Text("Not available for this item.", color = TextLo, fontSize = 12.sp)

            running -> {
                GradientProgress(AiStems.jobProgress, Modifier.fillMaxWidth())
                Text(AiStems.jobStage, color = TextHi, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                val eta = AiStems.jobEtaSec
                if (eta >= 0) {
                    Text(
                        "About " + (if (eta >= 90) (eta / 60 + 1).toString() + " min" else eta.toString() + " s") + " left. You can leave this screen, a notification shows the progress.",
                        color = TextLo, fontSize = 12.sp
                    )
                } else {
                    Text("This takes a few minutes. You can leave this screen, a notification shows the progress.", color = TextLo, fontSize = 12.sp)
                }
                PillButton(Icons.Rounded.Close, "Cancel", false) { AiStems.cancelJob() }
            }

            hasStem -> {
                Text("Karaoke track ready", color = Green, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Play the karaoke track (no singer)", color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text("Use this while you sing", color = TextLo, fontSize = 12.sp)
                    }
                    PremiumSwitch(AiStems.backingOn) { AiStems.setBacking(ctx, it) }
                }
                PillButton(Icons.Rounded.Close, "Delete karaoke track", false) { AiStems.deleteStem(ctx, item.id) }
            }

            !AiStems.modelReady -> {
                if (AiStems.modelBusy) {
                    GradientProgress(AiStems.modelProgress, Modifier.fillMaxWidth())
                    Text("Downloading the AI model… " + (AiStems.modelProgress * 100).toInt() + "%", color = TextLo, fontSize = 12.sp)
                    PillButton(Icons.Rounded.Close, "Cancel", false) { AiStems.cancelModelDownload() }
                } else {
                    GradientButton("Download the AI (67 MB, one time)", false) { AiStems.downloadModel(ctx) }
                    val err = AiStems.modelError
                    if (err != null) Text(err, color = Pink, fontSize = 12.sp)
                }
            }

            else -> {
                Segmented(listOf("Best quality", "Faster"), if (best) 0 else 1) { best = it == 0 }
                GradientButton(if (otherRunning) "Another song is being processed" else "Remove the voice (AI)", otherRunning) {
                    if (!otherRunning) AiStems.start(ctx, item, best)
                }
                val err = AiStems.jobError
                if (err != null) Text(err, color = Pink, fontSize = 12.sp)
                Text(
                    "Takes a few minutes per song (longer on older phones). Needs about 1.5 GB of free memory, so close other apps first. Songs up to 12 minutes.",
                    color = TextLo, fontSize = 12.sp
                )
            }
        }
    }
}
