package com.raja.tubevault.core

import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.AudioTrackType
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.VideoStream
import java.util.Locale

object YouTubeRepo {

    /** Blocking – call from a background dispatcher. */
    fun fetch(url: String): MediaInfo {
        val info = StreamInfo.getInfo(url)

        val typeName = info.streamType.name
        if (typeName.contains("LIVE") && !typeName.contains("POST")) {
            throw IllegalStateException("Live streams can't be downloaded. Try again after the stream has ended.")
        }

        val audioList = pickAudio(info.audioStreams)
        val bestAudio = audioList.firstOrNull()

        // ----- video options -----
        data class Cand(val s: VideoStream, val merged: Boolean)

        val progressive = info.videoStreams.filter { okVideo(it) }.map { Cand(it, false) }
        val adaptive = if (bestAudio != null) {
            info.videoOnlyStreams.filter { okVideo(it) }.map { Cand(it, true) }
        } else emptyList()

        val best = (progressive + adaptive)
            .groupBy { it.s.height to (it.s.fps > 30) }
            .values
            .map { g -> g.sortedWith(compareBy<Cand> { it.merged }.thenByDescending { it.s.bitrate }).first() }
            .sortedWith(compareByDescending<Cand> { it.s.height }.thenByDescending { it.s.fps })
            .take(8)

        val videoFormats = best.map { c ->
            val v = c.s
            val vSize = sizeOf(v.itagItem?.contentLength)
            val aSize = if (c.merged) sizeOf(bestAudio?.itagItem?.contentLength) else 0L
            val total = if (vSize > 0 && (!c.merged || aSize > 0)) vSize + aSize else 0L
            val fps = if (v.fps > 30) " ${v.fps}fps" else ""
            val tag = when {
                v.height >= 2160 -> "4K"
                v.height >= 1440 -> "2K"
                v.height >= 1080 -> "Full HD"
                v.height >= 720 -> "HD"
                else -> "SD"
            }
            FormatOption(
                key = (if (c.merged) "m-" else "p-") + v.itag + "-" + v.height + v.fps,
                label = "${v.height}p$fps",
                detail = "MP4 • $tag" + (if (total > 0) " • ~${formatBytes(total)}" else ""),
                isAudio = false,
                video = v,
                audio = if (c.merged) bestAudio else null,
                needsMerge = c.merged,
                sizeBytes = total
            )
        }.toMutableList()

        // ----- audio options -----
        val audioFormats = audioList
            .distinctBy { it.averageBitrate }
            .take(3)
            .map { a ->
                val size = sizeOf(a.itagItem?.contentLength)
                val kbps = if (a.averageBitrate > 0) "${a.averageBitrate} kbps" else "Best quality"
                FormatOption(
                    key = "a-" + a.itag + "-" + a.averageBitrate,
                    label = "M4A",
                    detail = "AAC • $kbps" + (if (size > 0) " • ~${formatBytes(size)}" else ""),
                    isAudio = true,
                    video = null,
                    audio = a,
                    needsMerge = false,
                    sizeBytes = size
                )
            }.toMutableList()

        // ----- HLS (ended live streams / live classes) -----
        val hls = info.hlsUrl
        if (!hls.isNullOrBlank()) {
            try {
                val vars = Hls.variants(hls, Hls.fetchText(hls))
                val haveHeights = videoFormats.map { it.label.substringBefore("p").toIntOrNull() ?: 0 }.toSet()
                val dur = info.duration
                val picked = vars.groupBy { it.height }
                    .map { (_, g) -> g.maxByOrNull { it.bandwidth }!! }
                    .sortedByDescending { it.height }
                    .filter { it.height <= 0 || it.height !in haveHeights }
                    .take(8)
                for (v in picked) {
                    val est = if (v.bandwidth > 0 && dur > 0) v.bandwidth / 8 * dur else 0L
                    videoFormats.add(
                        FormatOption(
                            key = "h-" + v.height + "-" + v.bandwidth,
                            label = if (v.height > 0) "${v.height}p" else "Video",
                            detail = "MP4 • Live replay" + (if (est > 0) " • ~${formatBytes(est)}" else ""),
                            isAudio = false, video = null, audio = null, needsMerge = false,
                            sizeBytes = est, hlsUrl = v.url, hlsAudioUrl = v.audioUrl
                        )
                    )
                }
                if (audioFormats.isEmpty() && vars.isNotEmpty()) {
                    val low = vars.minByOrNull { if (it.bandwidth > 0) it.bandwidth else Long.MAX_VALUE }!!
                    audioFormats.add(
                        FormatOption(
                            key = "ha", label = "M4A", detail = "AAC • Live replay",
                            isAudio = true, video = null, audio = null, needsMerge = false,
                            sizeBytes = 0L, hlsUrl = low.audioUrl ?: low.url, hlsAudioOnly = true
                        )
                    )
                }
            } catch (e: Exception) {
                // HLS is only a bonus – ignore and use whatever normal formats exist
            }
        }

        if (videoFormats.isEmpty() && audioFormats.isEmpty()) {
            throw IllegalStateException("No downloadable formats were found. If this was a live class that just ended, wait a few minutes for YouTube to finish processing it and try again.")
        }

        val thumb = info.thumbnails.maxByOrNull { it.width }?.url
            ?: info.thumbnails.firstOrNull()?.url

        return MediaInfo(
            id = info.id,
            url = url,
            title = info.name ?: "YouTube video",
            uploader = info.uploaderName ?: "",
            durationSec = info.duration,
            thumbnail = thumb,
            videoFormats = videoFormats,
            audioFormats = audioFormats
        )
    }

    private fun okVideo(v: VideoStream): Boolean {
        if (!v.isUrl || v.deliveryMethod != DeliveryMethod.PROGRESSIVE_HTTP) return false
        if (v.format != MediaFormat.MPEG_4) return false
        if (v.height <= 0) return false
        val codec = v.codec?.lowercase(Locale.ROOT) ?: ""
        return !codec.startsWith("av01") && !codec.startsWith("vp")
    }

    private fun pickAudio(all: List<AudioStream>): List<AudioStream> {
        val m4a = all.filter {
            it.isUrl && it.deliveryMethod == DeliveryMethod.PROGRESSIVE_HTTP && it.format == MediaFormat.M4A
        }
        val original = m4a.filter { it.audioTrackType == null || it.audioTrackType == AudioTrackType.ORIGINAL }
        return (if (original.isNotEmpty()) original else m4a).sortedByDescending { it.averageBitrate }
    }

    private fun sizeOf(v: Long?): Long = if (v != null && v > 0) v else 0L
}

fun formatBytes(b: Long): String {
    if (b <= 0) return "0 MB"
    val kb = b / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0
    return when {
        gb >= 1 -> String.format(Locale.US, "%.2f GB", gb)
        mb >= 10 -> String.format(Locale.US, "%.0f MB", mb)
        mb >= 1 -> String.format(Locale.US, "%.1f MB", mb)
        else -> String.format(Locale.US, "%.0f KB", kb)
    }
}

fun formatDuration(sec: Long): String {
    if (sec <= 0) return ""
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.US, "%d:%02d", m, s)
}
