package com.raja.tubevault.core

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Wraps the shared player in a media session.
 *
 * What that buys us:
 *  - playback keeps running with the screen off or the app in the background
 *    (media3 starts the foreground service itself once audio is playing),
 *  - a media-style notification with play/pause, next, previous and the seek bar,
 *  - the same controls on the lock screen, on Bluetooth headsets and in Android Auto.
 */
class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        if (session != null) return
        val player = PlaybackHub.player(this)
        session = MediaSession.Builder(this, player)
            .setSessionActivity(openApp())
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    /** Swiping the app out of recents keeps the music going; it only stops when paused. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        session?.run {
            player.pause()
            release()
        }
        session = null
        super.onDestroy()
    }

    private fun openApp(): PendingIntent {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
            ?: Intent().setClassName(packageName, "com.raja.tubevault.MainActivity")
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
