package com.raja.tubevault.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import coil.compose.AsyncImage
import com.raja.tubevault.core.DownloadItem
import com.raja.tubevault.core.Downloads
import com.raja.tubevault.core.LocalStore
import com.raja.tubevault.core.MediaSaver
import com.raja.tubevault.core.Place
import com.raja.tubevault.core.Status
import com.raja.tubevault.core.Thumbs
import com.raja.tubevault.core.Vault
import com.raja.tubevault.core.formatBytes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

// =================================================================== "Save to" selector

private data class PlaceInfo(val place: Place, val title: String, val icon: ImageVector, val caption: String, val brush: Brush)

private val PLACES = listOf(
    PlaceInfo(
        Place.PRIVATE, "Private", Icons.Rounded.VisibilityOff,
        "Only inside TubeVault — hidden from Gallery & other apps",
        Brush.horizontalGradient(listOf(Violet, Pink))
    ),
    PlaceInfo(
        Place.GALLERY, "Gallery", Icons.Rounded.PhotoLibrary,
        "Saved to Movies / Music — visible in Gallery & every app",
        Brush.horizontalGradient(listOf(Cyan, Violet))
    ),
    PlaceInfo(
        Place.VAULT, "Vault", Icons.Rounded.Lock,
        "Encrypted & locked with your password / fingerprint",
        Brush.horizontalGradient(listOf(Orange, Pink))
    )
)

/** Animated 3-way switch: where the download is saved. */
@Composable
fun SaveToSelector(selected: Place, modifier: Modifier = Modifier, showCaption: Boolean = true, onSelect: (Place) -> Unit) {
    val haptic = rememberHaptics()
    val idx = PLACES.indexOfFirst { it.place == selected }.coerceAtLeast(0)
    Column(modifier) {
        BoxWithConstraints(
            Modifier
                .fillMaxWidth()
                .height(48.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0x14FFFFFF))
                .border(BorderStroke(1.dp, GlassBorder), RoundedCornerShape(16.dp))
                .padding(4.dp)
        ) {
            val w = maxWidth / 3
            val x by animateDpAsState(w * idx, spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMediumLow), label = "placeX")
            Box(
                Modifier
                    .offset(x = x)
                    .width(w)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(12.dp))
                    .background(PLACES[idx].brush)
            )
            Row(Modifier.fillMaxSize()) {
                PLACES.forEachIndexed { i, p ->
                    val on = i == idx
                    val wobble = remember { Animatable(0f) }
                    LaunchedEffect(on) {
                        if (on) {
                            wobble.snapTo(0f)
                            wobble.animateTo(1f, tween(450))
                        }
                    }
                    Row(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                                if (!on) {
                                    haptic(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                                    onSelect(p.place)
                                }
                            },
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            p.icon, null,
                            tint = if (on) Color.White else TextLo,
                            modifier = Modifier
                                .size(18.dp)
                                .graphicsLayer {
                                    val t = wobble.value
                                    rotationZ = if (on) kotlin.math.sin(t * 3f * Math.PI.toFloat()) * 18f * (1f - t) else 0f
                                    val s = if (on) 1f + 0.25f * kotlin.math.sin(t * Math.PI.toFloat()) else 1f
                                    scaleX = s; scaleY = s
                                }
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            p.title, color = if (on) Color.White else TextLo,
                            fontWeight = if (on) FontWeight.Bold else FontWeight.Medium, fontSize = 14.sp
                        )
                    }
                }
            }
        }
        if (showCaption) {
            Spacer(Modifier.height(6.dp))
            AnimatedContent(
                targetState = idx,
                transitionSpec = { (fadeIn(tween(250)) + slideInVertically(tween(250)) { it / 2 }) togetherWith fadeOut(tween(150)) },
                label = "placeCaption"
            ) { i ->
                Text(PLACES[i].caption, color = TextLo, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp))
            }
        }
    }
}

/** Small badge on Library thumbnails: where the file lives. */
@Composable
fun PlaceBadge(place: Place, modifier: Modifier = Modifier) {
    val icon = when (place) {
        Place.PRIVATE -> Icons.Rounded.VisibilityOff
        Place.GALLERY -> Icons.Rounded.PhotoLibrary
        Place.VAULT -> Icons.Rounded.Lock
    }
    Box(
        modifier
            .size(22.dp)
            .clip(CircleShape)
            .background(Color(0xAA000000)),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(12.dp)) }
}

// =================================================================== Library: ⋮ menu

/** ⋮ on a Library card: Save to Gallery / Hide from Gallery / Move to Vault. */
@Composable
fun MoveMenuButton(item: DownloadItem) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    Box {
        if (busy) {
            Box(Modifier.size(38.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(Modifier.size(22.dp), color = Pink, strokeWidth = 2.5.dp)
            }
        } else {
            PlayerIconButton(Icons.Rounded.MoreVert, { open = true }, size = 38.dp)
        }
        DropdownMenu(open, onDismissRequest = { open = false }, modifier = Modifier.background(SurfaceDark)) {
            val go: (Place) -> Unit = { target ->
                open = false
                busy = true
                Downloads.move(item.id, target) { msg ->
                    busy = false
                    Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
                }
            }
            if (item.place != Place.GALLERY) {
                DropdownMenuItem(
                    text = { Text("Save to Gallery", color = TextHi) },
                    leadingIcon = { Icon(Icons.Rounded.PhotoLibrary, null, tint = Cyan) },
                    onClick = { go(Place.GALLERY) }
                )
            }
            if (item.place != Place.PRIVATE) {
                DropdownMenuItem(
                    text = { Text("Hide from Gallery (private)", color = TextHi) },
                    leadingIcon = { Icon(Icons.Rounded.VisibilityOff, null, tint = Violet) },
                    onClick = { go(Place.PRIVATE) }
                )
            }
            if (item.isAudio && item.uri != null && item.status == Status.DONE) {
                DropdownMenuItem(
                    text = { Text("Trim / Ringtone ✂️", color = TextHi) },
                    leadingIcon = { Icon(Icons.Rounded.ContentCut, null, tint = Pink) },
                    onClick = {
                        open = false
                        ClipStudio.open(ctx, item)
                    }
                )
            }
            DropdownMenuItem(
                text = { Text("Move to Vault 🔒", color = TextHi) },
                leadingIcon = { Icon(Icons.Rounded.Lock, null, tint = Orange) },
                onClick = { go(Place.VAULT) }
            )
        }
    }
}

/** Glowing lock button in the Library header. */
@Composable
fun VaultEntryButton(onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "vaultGlow")
    val g by t.animateFloat(0.25f, 0.7f, infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "g")
    Row(
        Modifier
            .pressable(onClick)
            .drawBehind {
                drawCircle(Orange.copy(alpha = g * 0.35f), radius = size.height * 0.9f, center = Offset(size.height / 2, size.height / 2))
            }
            .clip(CircleShape)
            .background(Brush.horizontalGradient(listOf(Color(0x33FF8A3D), Color(0x33FF2E63))))
            .border(BorderStroke(1.dp, Orange.copy(alpha = 0.5f)), CircleShape)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Lock, null, tint = Color.White, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text("Vault", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        if (Vault.count > 0) {
            Spacer(Modifier.width(6.dp))
            Box(
                Modifier.clip(CircleShape).background(Color.White).padding(horizontal = 7.dp, vertical = 1.dp)
            ) { Text("${Vault.count}", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 11.sp) }
        }
    }
}

// =================================================================== Vault screen

private tailrec fun Context.fragmentActivity(): FragmentActivity? = when (this) {
    is FragmentActivity -> this
    is ContextWrapper -> baseContext.fragmentActivity()
    else -> null
}

private tailrec fun Context.activity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.activity()
    else -> null
}

private const val AUTH = BIOMETRIC_STRONG or BIOMETRIC_WEAK

fun biometricAvailable(ctx: Context): Boolean = try {
    BiometricManager.from(ctx).canAuthenticate(AUTH) == BiometricManager.BIOMETRIC_SUCCESS
} catch (_: Throwable) {
    false
}

private fun askBiometric(ctx: Context, onOk: () -> Unit) {
    val act = ctx.fragmentActivity() ?: return
    try {
        val prompt = BiometricPrompt(act, ContextCompat.getMainExecutor(act), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = onOk()
        })
        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle("Unlock your Vault")
                .setSubtitle("Use your fingerprint or face")
                .setNegativeButtonText("Use password")
                .setAllowedAuthenticators(AUTH)
                .build()
        )
    } catch (_: Throwable) {
    }
}

/** Full-screen Private Vault. Screenshots and the recent-apps preview are blocked while it is open. */
@Composable
fun VaultScreen() {
    AnimatedVisibility(
        visible = Vault.open,
        enter = slideInVertically(spring(dampingRatio = 0.85f, stiffness = 300f)) { it / 3 } + fadeIn(tween(250)),
        exit = slideOutVertically(tween(260)) { it / 3 } + fadeOut(tween(220))
    ) {
        val ctx = LocalContext.current
        DisposableEffect(Unit) {
            val w = ctx.activity()?.window
            w?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
            onDispose { w?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
        }
        BackHandler { Vault.open = false }
        var hasPw by remember { mutableStateOf(Vault.hasPassword()) }
        Box(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF1A0F1F), Color(0xFF0B0B12), Color(0xFF0B0B12))))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
        ) {
            val stage = when {
                !hasPw -> 0
                !Vault.unlocked -> 1
                else -> 2
            }
            AnimatedContent(
                targetState = stage,
                transitionSpec = {
                    (fadeIn(tween(350)) + scaleIn(tween(350), 0.92f)) togetherWith (fadeOut(tween(200)) + scaleOut(tween(200), 1.05f))
                },
                label = "vaultStage"
            ) { s ->
                when (s) {
                    0 -> SetupView(onDone = { hasPw = true })
                    1 -> LockedView(onReset = { hasPw = false })
                    else -> VaultList(onReset = { hasPw = false })
                }
            }
        }
    }
}

@Composable
private fun VaultTopBar(title: String, right: @Composable () -> Unit = {}) {
    Row(
        Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PlayerIconButton(Icons.AutoMirrored.Rounded.ArrowBack, { Vault.open = false }, size = 42.dp)
        Spacer(Modifier.width(10.dp))
        Text(title, color = TextHi, fontWeight = FontWeight.Black, fontSize = 20.sp, modifier = Modifier.weight(1f))
        right()
    }
}

@Composable
private fun ShieldHero(locked: Boolean) {
    val t = rememberInfiniteTransition(label = "shield")
    val pulse by t.animateFloat(0.9f, 1.1f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p")
    val ring by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2200)), label = "r")
    Box(Modifier.size(150.dp), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .fillMaxSize()
                .drawBehind {
                    drawCircle(Pink.copy(alpha = 0.25f * (1f - ring)), radius = size.minDimension / 2 * (0.55f + ring * 0.45f))
                    drawCircle(Orange.copy(alpha = 0.18f), radius = size.minDimension / 2 * 0.55f * pulse)
                }
        )
        Box(
            Modifier
                .size(84.dp)
                .graphicsLayer { scaleX = pulse; scaleY = pulse }
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Violet, Pink, Orange))),
            contentAlignment = Alignment.Center
        ) {
            AnimatedContent(locked, transitionSpec = { scaleIn(spring(0.5f)) togetherWith scaleOut() }, label = "lk") { l ->
                Icon(if (l) Icons.Rounded.Lock else Icons.Rounded.LockOpen, null, tint = Color.White, modifier = Modifier.size(40.dp))
            }
        }
    }
}

@Composable
private fun PasswordField(value: String, label: String, onChange: (String) -> Unit, onDone: (() -> Unit)? = null) {
    var show by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.take(64)) },
        label = { Text(label) },
        singleLine = true,
        visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = if (onDone != null) ImeAction.Done else ImeAction.Next),
        keyboardActions = KeyboardActions(onDone = { onDone?.invoke() }),
        trailingIcon = {
            Icon(
                if (show) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, null, tint = TextLo,
                modifier = Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { show = !show }
            )
        },
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = TextHi, unfocusedTextColor = TextHi,
            focusedBorderColor = Pink, unfocusedBorderColor = GlassBorder,
            focusedLabelColor = Pink, unfocusedLabelColor = TextLo, cursorColor = Pink
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun SetupView(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var p1 by remember { mutableStateOf("") }
    var p2 by remember { mutableStateOf("") }
    val canBio = remember { biometricAvailable(ctx) }
    var bio by remember { mutableStateOf(canBio) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val create: () -> Unit = create@{
        error = when {
            p1.length < 4 -> "Use at least 4 characters"
            p1 != p2 -> "The two passwords don't match"
            else -> null
        }
        if (error != null || busy) return@create
        busy = true
        scope.launch {
            withContext(Dispatchers.Default) { Vault.setPassword(p1) }
            Vault.biometric = bio && canBio
            Vault.unlock()
            busy = false
            onDone()
        }
    }
    Column(Modifier.fillMaxSize().imePadding()) {
        VaultTopBar("Private Vault")
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp)
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            ShieldHero(locked = true)
            Text("Create your Vault", color = TextHi, fontWeight = FontWeight.Black, fontSize = 24.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "Videos and songs in the Vault are encrypted (AES-256) and hidden from Gallery, file managers and every other app.",
                color = TextLo, fontSize = 14.sp, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(22.dp))
            PasswordField(p1, "Password or PIN", { p1 = it; error = null })
            Spacer(Modifier.height(10.dp))
            PasswordField(p2, "Type it again", { p2 = it; error = null }, onDone = create)
            AnimatedVisibility(error != null) {
                Text(error ?: "", color = Pink, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            }
            if (canBio) {
                Spacer(Modifier.height(14.dp))
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Glass).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Fingerprint, null, tint = if (bio) Pink else TextLo)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Fingerprint / face unlock", color = TextHi, fontWeight = FontWeight.Bold)
                        Text("Open the Vault with your phone's biometrics", color = TextLo, fontSize = 12.sp)
                    }
                    PremiumSwitch(bio) { bio = it }
                }
            }
            Spacer(Modifier.height(20.dp))
            GradientButton("Create Vault", busy, Modifier.fillMaxWidth()) { create() }
            Spacer(Modifier.height(12.dp))
            Text(
                "Remember this password. If you forget it, the only way back in is to reset the Vault, which deletes what's inside.",
                color = TextLo.copy(alpha = 0.8f), fontSize = 12.sp, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(30.dp))
        }
    }
}

@Composable
private fun LockedView(onReset: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pw by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var wait by remember { mutableIntStateOf(Vault.waitSeconds()) }
    var confirmReset by remember { mutableStateOf(false) }
    val shake = remember { Animatable(0f) }
    val bioOn = remember { Vault.biometric && biometricAvailable(ctx) }

    LaunchedEffect(Unit) {
        if (bioOn) {
            delay(350)
            askBiometric(ctx) { Vault.unlock() }
        }
    }
    LaunchedEffect(wait) {
        if (wait > 0) {
            delay(1000)
            wait = Vault.waitSeconds()
        }
    }
    val unlock: () -> Unit = unlock@{
        if (busy || pw.isEmpty() || wait > 0) return@unlock
        busy = true
        scope.launch {
            val ok = withContext(Dispatchers.Default) { Vault.checkPassword(pw) }
            busy = false
            if (ok) {
                Vault.unlock()
            } else {
                pw = ""
                wait = Vault.waitSeconds()
                error = if (wait > 0) "Too many tries" else "Wrong password"
                for (x in listOf(24f, -20f, 14f, -8f, 0f)) shake.animateTo(x, tween(55))
            }
        }
    }
    Column(Modifier.fillMaxSize().imePadding()) {
        VaultTopBar("Private Vault")
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp)
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(20.dp))
            ShieldHero(locked = true)
            Text("Vault locked", color = TextHi, fontWeight = FontWeight.Black, fontSize = 24.sp)
            Spacer(Modifier.height(4.dp))
            Text("${Vault.count} private item${if (Vault.count == 1) "" else "s"}", color = TextLo, fontSize = 14.sp)
            Spacer(Modifier.height(24.dp))
            Box(Modifier.graphicsLayer { translationX = shake.value * density }) {
                PasswordField(pw, "Password", { pw = it; error = null }, onDone = unlock)
            }
            AnimatedVisibility(error != null || wait > 0) {
                Text(
                    if (wait > 0) "${error ?: "Too many tries"} — try again in ${wait}s" else error ?: "",
                    color = Pink, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp)
                )
            }
            Spacer(Modifier.height(16.dp))
            GradientButton(if (wait > 0) "Wait ${wait}s" else "Unlock", busy, Modifier.fillMaxWidth()) { unlock() }
            if (bioOn) {
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier
                        .clip(CircleShape)
                        .clickable { askBiometric(ctx) { Vault.unlock() } }
                        .padding(horizontal = 18.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Fingerprint, null, tint = Pink, modifier = Modifier.size(26.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Use fingerprint / face", color = TextHi, fontWeight = FontWeight.SemiBold)
                }
            }
            Spacer(Modifier.height(30.dp))
            Text(
                "Forgot password? Reset Vault",
                color = TextLo, fontSize = 12.sp,
                modifier = Modifier.clickable { confirmReset = true }.padding(8.dp)
            )
        }
    }
    if (confirmReset) ResetDialog(onDismiss = { confirmReset = false }, onReset = onReset)
}

@Composable
private fun ResetDialog(onDismiss: () -> Unit, onReset: () -> Unit) {
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceDark, titleContentColor = TextHi, textContentColor = TextLo,
        title = { Text("Reset the Vault?") },
        text = { Text("This permanently deletes every video and song in the Vault and removes the password. It can't be undone.") },
        confirmButton = {
            TextButton(onClick = {
                onDismiss()
                scope.launch {
                    withContext(Dispatchers.IO) { Vault.reset() }
                    onReset()
                }
            }) { Text("Delete everything", color = Pink) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = TextHi) } }
    )
}

@Composable
private fun VaultList(onReset: () -> Unit) {
    val ctx = LocalContext.current
    val items by Vault.items.collectAsState()
    var menu by remember { mutableStateOf(false) }
    var changePw by remember { mutableStateOf(false) }
    var confirmReset by remember { mutableStateOf(false) }
    var bio by remember { mutableStateOf(Vault.biometric) }
    val canBio = remember { biometricAvailable(ctx) }
    var busyText by remember { mutableStateOf<String?>(null) }
    var deleting by remember { mutableStateOf<DownloadItem?>(null) }
    val scope = rememberCoroutineScope()

    val moveOut: (DownloadItem, Place) -> Unit = { item, target ->
        busyText = "Decrypting…"
        scope.launch {
            val msg = try {
                withContext(Dispatchers.IO) { moveOutOfVault(ctx, item, target) }
            } catch (e: Throwable) {
                "Couldn't move it: ${e.message ?: "error"}"
            }
            busyText = null
            Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
        }
    }

    Column(Modifier.fillMaxSize()) {
        VaultTopBar("Private Vault") {
            Box {
                PlayerIconButton(Icons.Rounded.Settings, { menu = true }, size = 42.dp)
                DropdownMenu(menu, onDismissRequest = { menu = false }, modifier = Modifier.background(SurfaceDark)) {
                    if (canBio) {
                        DropdownMenuItem(
                            text = { Text(if (bio) "Fingerprint unlock: ON" else "Fingerprint unlock: OFF", color = TextHi) },
                            leadingIcon = { Icon(Icons.Rounded.Fingerprint, null, tint = if (bio) Pink else TextLo) },
                            onClick = { bio = !bio; Vault.biometric = bio }
                        )
                    }
                    DropdownMenuItem(
                        text = { Text("Change password", color = TextHi) },
                        leadingIcon = { Icon(Icons.Rounded.Key, null, tint = Cyan) },
                        onClick = { menu = false; changePw = true }
                    )
                    DropdownMenuItem(
                        text = { Text("Reset Vault", color = Pink) },
                        leadingIcon = { Icon(Icons.Rounded.DeleteForever, null, tint = Pink) },
                        onClick = { menu = false; confirmReset = true }
                    )
                }
            }
            Spacer(Modifier.width(8.dp))
            PlayerIconButton(Icons.Rounded.Lock, { Vault.lock(); Vault.open = false }, size = 42.dp)
        }
        Row(Modifier.padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Shield, null, tint = Green, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text(
                "${items.size} item${if (items.size == 1) "" else "s"} • ${formatBytes(items.sumOf { it.totalBytes })} • AES-256 encrypted",
                color = TextLo, fontSize = 13.sp
            )
        }
        Spacer(Modifier.height(12.dp))
        if (items.isEmpty()) {
            Column(
                Modifier.fillMaxSize().padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                ShieldHero(locked = false)
                Text("Your Vault is empty", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Choose \"Vault\" under Save to when downloading, or tap ⋮ on any Library item → Move to Vault.",
                    color = TextLo, fontSize = 14.sp, textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                Modifier.padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 40.dp)
            ) {
                items(items, key = { it.id }) { item ->
                    VaultCard(
                        item,
                        onPlay = { PlayerHost.open(items, item.id) },
                        onMove = { moveOut(item, it) },
                        onDelete = { deleting = item }
                    )
                }
                item { Spacer(Modifier.navigationBarsPadding()) }
            }
        }
    }

    busyText?.let { t ->
        Box(
            Modifier.fillMaxSize().background(Color(0xAA000000))
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = Pink)
                Spacer(Modifier.height(12.dp))
                Text(t, color = TextHi)
            }
        }
    }
    deleting?.let { d ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            containerColor = SurfaceDark, titleContentColor = TextHi, textContentColor = TextLo,
            title = { Text("Delete forever?") },
            text = { Text("\"${d.title}\" will be permanently erased from the Vault.") },
            confirmButton = {
                TextButton(onClick = {
                    deleting = null
                    scope.launch { withContext(Dispatchers.IO) { Vault.delete(d.id) } }
                }) { Text("Delete", color = Pink) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel", color = TextHi) } }
        )
    }
    if (changePw) ChangePasswordDialog { changePw = false }
    if (confirmReset) ResetDialog(onDismiss = { confirmReset = false }, onReset = onReset)
}

@Composable
private fun VaultCard(item: DownloadItem, onPlay: () -> Unit, onMove: (Place) -> Unit, onDelete: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    GlassCard(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .width(112.dp)
                    .aspectRatio(16 / 9f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF2A1A35), Color(0xFF1A1A26))))
                    .pressable(onPlay),
                contentAlignment = Alignment.Center
            ) {
                Icon(if (item.isAudio) Icons.Rounded.MusicNote else Icons.Rounded.Videocam, null, tint = TextLo)
                AsyncImage(
                    model = item.thumbnail, contentDescription = null,
                    contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
                )
                Box(
                    Modifier.size(34.dp).clip(CircleShape).background(Color(0x88000000))
                        .border(1.dp, Color(0x66FFFFFF), CircleShape),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(22.dp)) }
                PlaceBadge(Place.VAULT, Modifier.align(Alignment.TopStart).padding(6.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.title, color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(2.dp))
                Text(
                    listOf(item.label, formatBytes(item.totalBytes)).filter { it.isNotEmpty() }.joinToString(" • "),
                    color = TextLo, fontSize = 12.sp, maxLines = 1
                )
            }
            Box {
                PlayerIconButton(Icons.Rounded.MoreVert, { menu = true }, size = 38.dp)
                DropdownMenu(menu, onDismissRequest = { menu = false }, modifier = Modifier.background(SurfaceDark)) {
                    DropdownMenuItem(
                        text = { Text("Move to Library (private)", color = TextHi) },
                        leadingIcon = { Icon(Icons.Rounded.VisibilityOff, null, tint = Violet) },
                        onClick = { menu = false; onMove(Place.PRIVATE) }
                    )
                    DropdownMenuItem(
                        text = { Text("Save to Gallery", color = TextHi) },
                        leadingIcon = { Icon(Icons.Rounded.PhotoLibrary, null, tint = Cyan) },
                        onClick = { menu = false; onMove(Place.GALLERY) }
                    )
                    DropdownMenuItem(
                        text = { Text("Delete forever", color = Pink) },
                        leadingIcon = { Icon(Icons.Rounded.DeleteForever, null, tint = Pink) },
                        onClick = { menu = false; onDelete() }
                    )
                }
            }
        }
    }
}

@Composable
private fun ChangePasswordDialog(onClose: () -> Unit) {
    val scope = rememberCoroutineScope()
    var old by remember { mutableStateOf("") }
    var n1 by remember { mutableStateOf("") }
    var n2 by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = SurfaceDark, titleContentColor = TextHi, textContentColor = TextLo,
        title = { Text("Change password") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PasswordField(old, "Current password", { old = it; error = null })
                PasswordField(n1, "New password", { n1 = it; error = null })
                PasswordField(n2, "New password again", { n2 = it; error = null })
                error?.let { Text(it, color = Pink, fontSize = 13.sp) }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = {
                when {
                    n1.length < 4 -> error = "Use at least 4 characters"
                    n1 != n2 -> error = "The new passwords don't match"
                    else -> {
                        busy = true
                        scope.launch {
                            val ok = withContext(Dispatchers.Default) { Vault.checkPassword(old) }
                            if (ok) {
                                withContext(Dispatchers.Default) { Vault.setPassword(n1) }
                                Toast.makeText(ctx, "Password changed", Toast.LENGTH_SHORT).show()
                                onClose()
                            } else {
                                error = "Current password is wrong"
                            }
                            busy = false
                        }
                    }
                }
            }) { Text("Save", color = Pink) }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel", color = TextHi) } }
    )
}

/** Decrypts a vault item back into the Library (private) or the Gallery. Blocking. */
private fun moveOutOfVault(ctx: Context, item: DownloadItem, target: Place): String {
    val entry = Vault.entry(item.id) ?: return "This vault item is missing"
    val dir = File(ctx.cacheDir, "vaultout").apply { mkdirs() }
    val tmp = File(dir, "f.${entry.ext}")
    try {
        Vault.exportTo(item.id, tmp)
        val name = MediaSaver.sanitize(entry.title) +
            (if (entry.isAudio) "" else " (${entry.label.replace(" ", "")})") + "." + entry.ext
        val mime = LocalStore.mimeOf(name, entry.isAudio)
        val uri = if (target == Place.GALLERY) MediaSaver.save(ctx, tmp, name, mime, entry.isAudio).toString()
        else LocalStore.save(ctx, tmp, name)
        val newId = java.util.UUID.randomUUID().toString()
        val thumb = entry.thumb?.let { Vault.thumbBytes(it) }?.let { Thumbs.saveLocal(ctx, newId, it) }
        Downloads.addFinished(
            DownloadItem(
                id = newId, title = entry.title, uploader = entry.uploader, thumbnail = thumb,
                label = entry.label, isAudio = entry.isAudio, status = Status.DONE, progress = 1f, speed = 0L,
                doneBytes = entry.size, totalBytes = entry.size, uri = uri, error = null,
                createdAt = System.currentTimeMillis(), place = target
            )
        )
        Vault.delete(item.id)
        return if (target == Place.GALLERY) "Saved to your Gallery" else "Moved to your Library (hidden from Gallery)"
    } finally {
        dir.deleteRecursively()
    }
}
