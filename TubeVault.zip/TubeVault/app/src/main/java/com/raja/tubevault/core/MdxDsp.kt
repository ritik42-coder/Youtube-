package com.raja.tubevault.core

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * FFT of any size N = P * 2^m (P small and odd, e.g. 6144 = 3 * 2048).
 * Complex in/out. Not thread-safe (uses scratch buffers).
 */
class MixedFft(val n: Int) {
    private val l: Int
    private val p: Int
    private val wRe = FloatArray(n)
    private val wIm = FloatArray(n)
    private val subRe: FloatArray
    private val subIm: FloatArray
    private val yRe = FloatArray(n)
    private val yIm = FloatArray(n)
    private val twRe: FloatArray
    private val twIm: FloatArray
    private val rev: IntArray

    init {
        var pow = 1
        while (n % (pow * 2) == 0) pow *= 2
        l = pow
        p = n / l
        for (i in 0 until n) {
            val a = -2.0 * PI * i / n
            wRe[i] = cos(a).toFloat()
            wIm[i] = sin(a).toFloat()
        }
        subRe = FloatArray(l)
        subIm = FloatArray(l)
        twRe = FloatArray(l / 2 + 1)
        twIm = FloatArray(l / 2 + 1)
        for (i in 0 until l / 2) {
            val a = -2.0 * PI * i / l
            twRe[i] = cos(a).toFloat()
            twIm[i] = sin(a).toFloat()
        }
        rev = IntArray(l)
        var bits = 0
        while ((1 shl bits) < l) bits++
        for (i in 0 until l) {
            var r = 0
            var x = i
            for (b in 0 until bits) {
                r = (r shl 1) or (x and 1)
                x = x shr 1
            }
            rev[i] = r
        }
    }

    /** radix-2 FFT of size l on subRe/subIm, in place */
    private fun fftL() {
        val re = subRe
        val im = subIm
        for (i in 0 until l) {
            val j = rev[i]
            if (j > i) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var size = 2
        while (size <= l) {
            val half = size / 2
            val step = l / size
            var start = 0
            while (start < l) {
                var k = 0
                for (j in start until start + half) {
                    val wr = twRe[k]
                    val wi = twIm[k]
                    val a = j + half
                    val xr = re[a] * wr - im[a] * wi
                    val xi = re[a] * wi + im[a] * wr
                    re[a] = re[j] - xr
                    im[a] = im[j] - xi
                    re[j] += xr
                    im[j] += xi
                    k += step
                }
                start += size
            }
            size *= 2
        }
    }

    /** Forward DFT: X[k] = sum x[n] e^{-2 pi i k n / N}. In place on re/im (size n). */
    fun forward(re: FloatArray, im: FloatArray) {
        if (p == 1) {
            System.arraycopy(re, 0, subRe, 0, n)
            System.arraycopy(im, 0, subIm, 0, n)
            fftL()
            System.arraycopy(subRe, 0, re, 0, n)
            System.arraycopy(subIm, 0, im, 0, n)
            return
        }
        for (r in 0 until p) {
            var idx = r
            for (m in 0 until l) {
                subRe[m] = re[idx]
                subIm[m] = im[idx]
                idx += p
            }
            fftL()
            System.arraycopy(subRe, 0, yRe, r * l, l)
            System.arraycopy(subIm, 0, yIm, r * l, l)
        }
        for (k in 0 until n) {
            val km = k and (l - 1)
            var sr = yRe[km]
            var si = yIm[km]
            var w = 0
            for (r in 1 until p) {
                w += k
                if (w >= n) w %= n
                val wr = wRe[w]
                val wi = wIm[w]
                val yr = yRe[r * l + km]
                val yi = yIm[r * l + km]
                sr += yr * wr - yi * wi
                si += yr * wi + yi * wr
            }
            re[k] = sr
            im[k] = si
        }
    }

    /** Inverse DFT with 1/N scaling. In place. */
    fun inverse(re: FloatArray, im: FloatArray) {
        for (i in 0 until n) im[i] = -im[i]
        forward(re, im)
        val s = 1f / n
        for (i in 0 until n) {
            re[i] *= s
            im[i] = -im[i] * s
        }
    }
}

/**
 * STFT / iSTFT exactly like torch.stft / torch.istft (center=True, periodic Hann window)
 * as used by Ultimate Vocal Remover's MDX-Net models. Works on a stereo pair at once.
 *
 * Model tensor layout: [1, 4, dimF, dimT]; plane 0 = left real, 1 = left imag, 2 = right real, 3 = right imag.
 */
class MdxDsp(val nFft: Int = 6144, val hop: Int = 1024, val dimF: Int = 3072, val dimT: Int = 256) {
    val bins = nFft / 2 + 1
    val chunk = hop * (dimT - 1)
    val trim = nFft / 2
    private val fft = MixedFft(nFft)
    private val window = FloatArray(nFft) { (0.5 - 0.5 * cos(2.0 * PI * it / nFft)).toFloat() }
    private val re = FloatArray(nFft)
    private val im = FloatArray(nFft)
    private val padL = FloatArray(chunk + nFft)
    private val padR = FloatArray(chunk + nFft)
    private val envelope = FloatArray(chunk + nFft)
    private val olaL = FloatArray(chunk + nFft)
    private val olaR = FloatArray(chunk + nFft)

    init {
        for (t in 0 until dimT) {
            val s = t * hop
            for (i in 0 until nFft) envelope[s + i] += window[i] * window[i]
        }
    }

    private fun reflect(src: FloatArray, dst: FloatArray) {
        val h = nFft / 2
        System.arraycopy(src, 0, dst, h, chunk)
        for (i in 1..h) dst[h - i] = src[i]
        for (i in 1..h) dst[h + chunk - 1 + i] = src[chunk - 1 - i]
    }

    /** left/right: chunk samples. Writes planes 0..3 of [4, dimF, dimT] into [spec] at [off]. */
    fun stft(left: FloatArray, right: FloatArray, spec: FloatArray, off: Int) {
        reflect(left, padL)
        reflect(right, padR)
        val plane = dimF * dimT
        for (t in 0 until dimT) {
            val s = t * hop
            for (i in 0 until nFft) {
                val w = window[i]
                re[i] = padL[s + i] * w
                im[i] = padR[s + i] * w
            }
            fft.forward(re, im)
            for (f in 0 until dimF) {
                val k2 = (nFft - f) % nFft
                val zr = re[f]
                val zi = im[f]
                val cr = re[k2]
                val ci = -im[k2]
                // left = (Z[k] + conj(Z[N-k])) / 2 ; right = (Z[k] - conj(Z[N-k])) / (2i)
                val lr = (zr + cr) * 0.5f
                val li = (zi + ci) * 0.5f
                val dr = (zr - cr) * 0.5f
                val di = (zi - ci) * 0.5f
                val rr = di
                val ri = -dr
                val o = off + f * dimT + t
                spec[o] = lr
                spec[o + plane] = li
                spec[o + 2 * plane] = rr
                spec[o + 3 * plane] = ri
            }
        }
    }

    /** UVR zeroes the three lowest bins before the network. */
    fun zeroLowBins(spec: FloatArray, off: Int) {
        val plane = dimF * dimT
        for (c in 0 until 4) {
            for (f in 0 until 3) {
                java.util.Arrays.fill(spec, off + c * plane + f * dimT, off + c * plane + (f + 1) * dimT, 0f)
            }
        }
    }

    /** Network output [4, dimF, dimT] -> chunk samples left/right. */
    fun istft(spec: FloatArray, off: Int, outL: FloatArray, outR: FloatArray) {
        java.util.Arrays.fill(olaL, 0f)
        java.util.Arrays.fill(olaR, 0f)
        val plane = dimF * dimT
        for (t in 0 until dimT) {
            java.util.Arrays.fill(re, 0f)
            java.util.Arrays.fill(im, 0f)
            // Z = XL + i*XR with Hermitian XL, XR (bins above dimF are zero)
            for (f in 0 until dimF) {
                val o = off + f * dimT + t
                val lr = spec[o]
                var li = spec[o + plane]
                val rr = spec[o + 2 * plane]
                var ri = spec[o + 3 * plane]
                if (f == 0 || f == nFft / 2) {
                    li = 0f
                    ri = 0f
                }
                // Z[f] = XL[f] + i XR[f]
                re[f] += lr - ri
                im[f] += li + rr
                if (f != 0 && f != nFft / 2) {
                    val k2 = nFft - f
                    // Z[N-f] = conj(XL[f]) + i conj(XR[f])
                    re[k2] += lr + ri
                    im[k2] += -li + rr
                }
            }
            fft.inverse(re, im)
            val s = t * hop
            for (i in 0 until nFft) {
                val w = window[i]
                olaL[s + i] += re[i] * w
                olaR[s + i] += im[i] * w
            }
        }
        for (i in 0 until chunk) {
            val e = envelope[trim + i]
            val inv = if (e > 1e-11f) 1f / e else 0f
            outL[i] = olaL[trim + i] * inv
            outR[i] = olaR[trim + i] * inv
        }
    }
}
