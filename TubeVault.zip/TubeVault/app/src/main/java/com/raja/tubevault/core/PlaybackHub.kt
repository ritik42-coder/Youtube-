package com.raja.tubevault.core

import android.content.Context
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

/** What the little "island" pill shows while something is playing. */
data class NowPlaying(
    val title: String,
    val uploader: String,
    val thumb: String?,
    val isAudio: Boolean
)

/**
 * One player for the whole app.
 *
 * The screen does not own it any more, so closing the player (or turning the
 * screen off, or leaving the app) does not stop the music. [PlaybackService]
 * wraps the same instance in a media session, which is what gives us the
 * notification, the lock-screen controls and the keep-alive in the background.
 */
object PlaybackHub {

    @Volatile
    private var exo: ExoPlayer? = null

    @Volatile
    private var appCtx: Context? = null

    /** Current track, for the now-playing pill. Null = nothing loaded. */
    var now by mutableStateOf<NowPlaying?>(null)

    var playing by mutableStateOf(false)

    /** The user dismissed the pill; it stays hidden until the next play. */
    var islandHidden by mutableStateOf(false)

    fun player(ctx: Context): ExoPlayer {
        exo?.let { return it }
        synchronized(this) {
            exo?.let { return it }
            appCtx = ctx.applicationContext
            val p = ExoPlayer.Builder(ctx.applicationContext).build()
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                /* handleAudioFocus = */ true
            )
            // pause when headphones are pulled out
            p.setHandleAudioBecomingNoisy(true)
            // keep the CPU awake so audio keeps flowing with the screen off
            p.setWakeMode(C.WAKE_MODE_NETWORK)
            // keep [playing] honest even when no player screen is open (island, notification)
            p.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    playing = isPlaying
                }
            })
            exo = p
            return p
        }
    }

    fun current(): ExoPlayer? = exo

    /** Starts (or reuses) the foreground service that owns the media session. */
    fun startService(ctx: Context) {
        try {
            ctx.startService(Intent(ctx, PlaybackService::class.java))
        } catch (_: Throwable) {
        }
    }

    fun toggle() {
        val p = exo ?: return
        if (p.isPlaying) p.pause() else p.play()
    }

    fun next() {
        val p = exo ?: return
        if (p.hasNextMediaItem()) p.seekToNextMediaItem()
    }

    fun prev() {
        val p = exo ?: return
        if (p.currentPosition > 3000L) p.seekTo(0L)
        else if (p.hasPreviousMediaItem()) p.seekToPreviousMediaItem()
        else p.seekTo(0L)
    }

    /** Fully stops playback and frees the player (used when the player screen is closed). */
    fun release() {
        val p = exo ?: return
        exo = null
        now = null
        playing = false
        islandHidden = false
        // let the media session go before the player it points at disappears
        val c = appCtx
        if (c != null) {
            try {
                c.stopService(Intent(c, PlaybackService::class.java))
            } catch (_: Throwable) {
            }
        }
        try {
            p.pause()
            p.stop()
            p.release()
        } catch (_: Throwable) {
        }
        AudioFx.detach()
    }
}
