package com.raja.tubevault.ui

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Tiny persisted settings store. Values are Compose state so the UI reacts instantly. */
object AppSettings {
    private var prefs: SharedPreferences? = null

    var wifiOnly by mutableStateOf(false)
        private set
    var haptics by mutableStateOf(true)
        private set
    var liveBg by mutableStateOf(true)
        private set
    /** floating island over other apps - OFF by default */
    var islandOverlay by mutableStateOf(false)
        private set
    /** island pill inside TubeVault while music plays */
    var islandInApp by mutableStateOf(true)
        private set

    /** Where downloads go by default: PRIVATE (hidden from Gallery), GALLERY or VAULT */
    var defaultPlace by mutableStateOf(com.raja.tubevault.core.Place.PRIVATE)
        private set
    /** Hide the Vault button – open the Vault by long-pressing the "Library" title instead */
    var hideVaultButton by mutableStateOf(false)
        private set

    /** Check GitHub for a new TubeVault version when the app opens */
    var autoUpdate by mutableStateOf(true)
        private set
    /** Download a found update in the background (only on Wi-Fi / unmetered networks) */
    var autoDownloadUpdate by mutableStateOf(true)
        private set

    fun changeAutoUpdate(v: Boolean) {
        autoUpdate = v
        prefs?.edit()?.putBoolean("auto_update", v)?.apply()
    }

    fun changeAutoDownloadUpdate(v: Boolean) {
        autoDownloadUpdate = v
        prefs?.edit()?.putBoolean("auto_dl_update", v)?.apply()
    }

    fun changeDefaultPlace(v: com.raja.tubevault.core.Place) {
        defaultPlace = v
        prefs?.edit()?.putString("default_place", v.name)?.apply()
    }

    fun changeHideVaultButton(v: Boolean) {
        hideVaultButton = v
        prefs?.edit()?.putBoolean("hide_vault", v)?.apply()
    }

    fun init(ctx: Context) {
        val p = ctx.getSharedPreferences("tubevault_settings", Context.MODE_PRIVATE)
        prefs = p
        wifiOnly = p.getBoolean("wifi", false)
        haptics = p.getBoolean("haptics", true)
        liveBg = p.getBoolean("livebg", true)
        islandOverlay = p.getBoolean("island_overlay", false)
        islandInApp = p.getBoolean("island_inapp", true)
        defaultPlace = try {
            com.raja.tubevault.core.Place.valueOf(p.getString("default_place", "PRIVATE") ?: "PRIVATE")
        } catch (_: Exception) {
            com.raja.tubevault.core.Place.PRIVATE
        }
        hideVaultButton = p.getBoolean("hide_vault", false)
        autoUpdate = p.getBoolean("auto_update", true)
        autoDownloadUpdate = p.getBoolean("auto_dl_update", true)
    }

    fun changeIslandOverlay(v: Boolean) {
        islandOverlay = v
        prefs?.edit()?.putBoolean("island_overlay", v)?.apply()
    }

    fun changeIslandInApp(v: Boolean) {
        islandInApp = v
        prefs?.edit()?.putBoolean("island_inapp", v)?.apply()
    }

    fun changeWifiOnly(v: Boolean) {
        wifiOnly = v
        prefs?.edit()?.putBoolean("wifi", v)?.apply()
    }

    fun changeHaptics(v: Boolean) {
        haptics = v
        prefs?.edit()?.putBoolean("haptics", v)?.apply()
    }

    fun changeLiveBg(v: Boolean) {
        liveBg = v
        prefs?.edit()?.putBoolean("livebg", v)?.apply()
    }
}
