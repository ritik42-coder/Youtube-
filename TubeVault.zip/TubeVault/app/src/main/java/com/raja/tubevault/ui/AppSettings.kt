package com.raja.tubevault.ui

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Tiny persisted settings store. Values are Compose state so the UI reacts instantly. */
object AppSettings {
    private var prefs: SharedPreferences? = null

    var wifiOnly by mutableStateOf(false)
        private set
    var haptics by mutableStateOf(true)
        private set
    var liveBg by mutableStateOf(true)
        private set

    fun init(ctx: Context) {
        val p = ctx.getSharedPreferences("tubevault_settings", Context.MODE_PRIVATE)
        prefs = p
        wifiOnly = p.getBoolean("wifi", false)
        haptics = p.getBoolean("haptics", true)
        liveBg = p.getBoolean("livebg", true)
    }

    fun setWifiOnly(v: Boolean) {
        wifiOnly = v
        prefs?.edit()?.putBoolean("wifi", v)?.apply()
    }

    fun setHaptics(v: Boolean) {
        haptics = v
        prefs?.edit()?.putBoolean("haptics", v)?.apply()
    }

    fun setLiveBg(v: Boolean) {
        liveBg = v
        prefs?.edit()?.putBoolean("livebg", v)?.apply()
    }
}
