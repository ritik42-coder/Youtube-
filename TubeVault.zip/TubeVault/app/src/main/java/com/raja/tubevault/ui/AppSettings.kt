package com.raja.tubevault.ui

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Tiny persisted settings store. Values are Compose state so the UI reacts instantly. */
object AppSettings {
    private var prefs: SharedPreferences? = null

    var wifiOnly by mutableStateOf(false)
        private set
    var haptics by mutableStateOf(true)
        private set
    var liveBg by mutableStateOf(true)
        private set
    /** floating island over other apps - OFF by default */
    var islandOverlay by mutableStateOf(false)
        private set
    /** island pill inside TubeVault while music plays */
    var islandInApp by mutableStateOf(true)
        private set

    fun init(ctx: Context) {
        val p = ctx.getSharedPreferences("tubevault_settings", Context.MODE_PRIVATE)
        prefs = p
        wifiOnly = p.getBoolean("wifi", false)
        haptics = p.getBoolean("haptics", true)
        liveBg = p.getBoolean("livebg", true)
        islandOverlay = p.getBoolean("island_overlay", false)
        islandInApp = p.getBoolean("island_inapp", true)
    }

    fun changeIslandOverlay(v: Boolean) {
        islandOverlay = v
        prefs?.edit()?.putBoolean("island_overlay", v)?.apply()
    }

    fun changeIslandInApp(v: Boolean) {
        islandInApp = v
        prefs?.edit()?.putBoolean("island_inapp", v)?.apply()
    }

    fun changeWifiOnly(v: Boolean) {
        wifiOnly = v
        prefs?.edit()?.putBoolean("wifi", v)?.apply()
    }

    fun changeHaptics(v: Boolean) {
        haptics = v
        prefs?.edit()?.putBoolean("haptics", v)?.apply()
    }

    fun changeLiveBg(v: Boolean) {
        liveBg = v
        prefs?.edit()?.putBoolean("livebg", v)?.apply()
    }
}
