@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.raja.tubevault.core

import android.content.Context
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSourceException
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.TransferListener
import java.io.IOException
import java.io.RandomAccessFile
import javax.crypto.Cipher

/** Plays encrypted vault files directly: decrypts on the fly, supports seeking. Nothing is written to disk. */
class VaultDataSource(private val ctx: Context) : BaseDataSource(false) {
    private var raf: RandomAccessFile? = null
    private var cipher: Cipher? = null
    private var uri: Uri? = null
    private var remaining = 0L
    private var opened = false
    private var buf = ByteArray(0)

    override fun open(dataSpec: DataSpec): Long {
        uri = dataSpec.uri
        transferInitializing(dataSpec)
        val id = dataSpec.uri.schemeSpecificPart.removePrefix("//")
        val f = Vault.fileFor(id) ?: throw IOException("Vault item not found")
        val r = RandomAccessFile(f, "r")
        raf = r
        val iv = ByteArray(16)
        r.readFully(iv)
        val plainLen = r.length() - 16
        val pos = dataSpec.position
        if (pos > plainLen) throw DataSourceException(PlaybackException.ERROR_CODE_IO_READ_POSITION_OUT_OF_RANGE)
        r.seek(16 + pos)
        cipher = VaultCrypto.ctr(VaultCrypto.key(ctx), iv, pos, Cipher.DECRYPT_MODE)
        remaining = if (dataSpec.length != C.LENGTH_UNSET.toLong()) minOf(dataSpec.length, plainLen - pos) else plainLen - pos
        opened = true
        transferStarted(dataSpec)
        return remaining
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (remaining <= 0L) return C.RESULT_END_OF_INPUT
        val want = minOf(length.toLong(), remaining).toInt()
        if (buf.size < want) buf = ByteArray(maxOf(want, 64 * 1024))
        val n = raf!!.read(buf, 0, want)
        if (n < 0) return C.RESULT_END_OF_INPUT
        val produced = cipher!!.update(buf, 0, n, buffer, offset)
        remaining -= n
        bytesTransferred(n)
        return if (produced > 0) produced else n
    }

    override fun getUri(): Uri? = uri

    override fun close() {
        uri = null
        cipher = null
        try {
            raf?.close()
        } finally {
            raf = null
            if (opened) {
                opened = false
                transferEnded()
            }
        }
    }
}

/** Normal files / content:// go to ExoPlayer's default source, tvvault:// to the decrypting one. */
class RoutingDataSource(ctx: Context) : DataSource {
    private val normal = DefaultDataSource(ctx, true)
    private val vault = VaultDataSource(ctx.applicationContext)
    private var current: DataSource? = null

    override fun addTransferListener(transferListener: TransferListener) {
        normal.addTransferListener(transferListener)
        vault.addTransferListener(transferListener)
    }

    override fun open(dataSpec: DataSpec): Long {
        val ds = if (dataSpec.uri.scheme == "tvvault") vault else normal
        current = ds
        return ds.open(dataSpec)
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int =
        current?.read(buffer, offset, length) ?: C.RESULT_END_OF_INPUT

    override fun getUri(): Uri? = current?.uri

    override fun getResponseHeaders(): Map<String, List<String>> = current?.responseHeaders ?: emptyMap()

    override fun close() {
        try {
            current?.close()
        } finally {
            current = null
        }
    }

    companion object {
        fun factory(ctx: Context) = DataSource.Factory { RoutingDataSource(ctx) }
    }
}
