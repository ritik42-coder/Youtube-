package com.raja.tubevault.core

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import java.io.File
import java.io.IOException
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Interleaved 16-bit stereo audio. */
class PcmData(val pcm: ShortArray, val frames: Int, val rate: Int)

class SongTooLongException(val maxMinutes: Int) : IOException("Songs up to $maxMinutes minutes are supported")

object PcmDecoder {
    const val TARGET_RATE = 44100

    /** Decodes any audio file to interleaved stereo 16-bit at its own sample rate. */
    fun decodeStereo(
        ctx: Context, uri: Uri, maxMinutes: Int,
        isCancelled: () -> Boolean, onProgress: (Float) -> Unit
    ): PcmData {
        val ex = MediaExtractor()
        var dec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) {
                    track = i
                    fmt = f
                    break
                }
            }
            if (track < 0 || fmt == null) throw IOException("No audio found in this file")
            ex.selectTrack(track)
            var rate = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            var ch = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
            if (durUs > maxMinutes * 60_000_000L + 5_000_000L) throw SongTooLongException(maxMinutes)

            val d = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            dec = d
            d.configure(fmt, null, null, 0)
            d.start()

            val guess = ((durUs / 1_000_000.0) * rate).toLong() + rate
            var out = ShortArray(min(guess * 2, 2_000_000_000L).toInt().coerceAtLeast(rate * 4))
            var frames = 0
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            while (!outDone) {
                if (isCancelled()) throw InterruptedException("cancelled")
                if (!inDone) {
                    val ii = d.dequeueInputBuffer(5_000)
                    if (ii >= 0) {
                        val b = d.getInputBuffer(ii)!!
                        val n = ex.readSampleData(b, 0)
                        if (n < 0) {
                            d.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            d.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = d.dequeueOutputBuffer(info, 5_000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = d.outputFormat
                    if (nf.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (nf.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                } else if (oi >= 0) {
                    if (info.size > 0) {
                        val ob = d.getOutputBuffer(oi)!!
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        ob.order(ByteOrder.nativeOrder())
                        val sb = ob.asShortBuffer()
                        val c = max(1, ch)
                        val fr = sb.remaining() / c
                        if (frames + fr > maxMinutes * 60L * rate + rate * 10L) throw SongTooLongException(maxMinutes)
                        if ((frames + fr) * 2 > out.size) out = out.copyOf(max(out.size * 3 / 2, (frames + fr) * 2))
                        if (c == 2) {
                            sb.get(out, frames * 2, fr * 2)
                        } else {
                            val tmp = ShortArray(fr * c)
                            sb.get(tmp)
                            for (i in 0 until fr) {
                                val l = tmp[i * c]
                                val r = if (c > 1) tmp[i * c + 1] else l
                                out[(frames + i) * 2] = l
                                out[(frames + i) * 2 + 1] = r
                            }
                        }
                        frames += fr
                        if (durUs > 0) onProgress(min(1f, frames.toFloat() / (durUs / 1_000_000f * rate)))
                    }
                    d.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                }
            }
            if (frames < rate / 2) throw IOException("This audio is too short")
            return PcmData(out, frames, rate)
        } finally {
            try {
                dec?.stop()
            } catch (_: Throwable) {
            }
            try {
                dec?.release()
            } catch (_: Throwable) {
            }
            ex.release()
        }
    }

    /** Decodes and converts to 44.1 kHz stereo. */
    fun decode44k(
        ctx: Context, uri: Uri, maxMinutes: Int,
        isCancelled: () -> Boolean, onProgress: (Float) -> Unit
    ): PcmData {
        val raw = decodeStereo(ctx, uri, maxMinutes, isCancelled, onProgress)
        return if (raw.rate == TARGET_RATE) raw else Resampler.to44100(raw, isCancelled)
    }
}

/** Windowed-sinc resampler (high quality, used when a song is not 44.1 kHz). */
object Resampler {
    private const val HALF = 16
    private const val PHASES = 256

    fun to44100(src: PcmData, isCancelled: () -> Boolean): PcmData {
        val dstRate = PcmDecoder.TARGET_RATE
        val ratio = src.rate.toDouble() / dstRate
        val cut = min(1.0, 1.0 / ratio) * 0.97
        val taps = 2 * HALF
        val table = Array(PHASES) { FloatArray(taps) }
        for (p in 0 until PHASES) {
            val frac = p.toDouble() / PHASES
            var sum = 0.0
            for (k in 0 until taps) {
                val x = (k - (HALF - 1)) - frac
                val sinc = if (abs(x) < 1e-9) 1.0 else sin(PI * x * cut) / (PI * x * cut)
                val w = 0.5 + 0.5 * kotlin.math.cos(PI * x / HALF)
                val v = sinc * w * cut
                table[p][k] = v.toFloat()
                sum += v
            }
            for (k in 0 until taps) table[p][k] = (table[p][k] / sum).toFloat()
        }
        val outFrames = (src.frames / ratio).toInt()
        val out = ShortArray(outFrames * 2)
        val s = src.pcm
        for (o in 0 until outFrames) {
            if (o and 0xFFFF == 0 && isCancelled()) throw InterruptedException("cancelled")
            val t = o * ratio
            val i0 = floor(t).toInt()
            val ph = ((t - i0) * PHASES).toInt().coerceIn(0, PHASES - 1)
            val tb = table[ph]
            var l = 0f
            var r = 0f
            val start = i0 - (HALF - 1)
            for (k in 0 until taps) {
                var idx = start + k
                if (idx < 0) idx = 0
                if (idx >= src.frames) idx = src.frames - 1
                val w = tb[k]
                l += s[idx * 2] * w
                r += s[idx * 2 + 1] * w
            }
            out[o * 2] = clip16(l)
            out[o * 2 + 1] = clip16(r)
        }
        return PcmData(out, outFrames, dstRate)
    }

    private fun clip16(v: Float): Short {
        val x = Math.round(v)
        return (if (x > 32767) 32767 else if (x < -32768) -32768 else x).toShort()
    }
}

/** Streams interleaved 16-bit PCM into an AAC (.m4a) file. */
class AacWriter(private val out: File, private val rate: Int, private val ch: Int, bitrate: Int = 192_000) {
    private val enc: MediaCodec
    private val muxer: MediaMuxer
    private val info = MediaCodec.BufferInfo()
    private var track = -1
    private var started = false
    private var framesWritten = 0L
    private var closed = false

    init {
        if (out.exists()) out.delete()
        val f = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, ch)
        f.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
        f.setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
        f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 32 * 1024)
        enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        enc.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        enc.start()
        muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    }

    private fun drain(wait: Boolean): Boolean {
        var eos = false
        while (true) {
            val oi = enc.dequeueOutputBuffer(info, if (wait) 10_000L else 0L)
            if (oi == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (wait && !eos) continue
                break
            } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                track = muxer.addTrack(enc.outputFormat)
                muxer.start()
                started = true
            } else if (oi >= 0) {
                val ob = enc.getOutputBuffer(oi)!!
                if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                if (info.size > 0 && started) {
                    ob.position(info.offset)
                    ob.limit(info.offset + info.size)
                    muxer.writeSampleData(track, ob, info)
                }
                enc.releaseOutputBuffer(oi, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) {
                    eos = true
                    break
                }
            }
        }
        return eos
    }

    /** [pcm] interleaved, [frames] frames. */
    fun write(pcm: ShortArray, frames: Int) {
        val total = frames * ch
        var pos = 0
        while (pos < total) {
            drain(false)
            val ii = enc.dequeueInputBuffer(10_000)
            if (ii < 0) continue
            val b = enc.getInputBuffer(ii)!!
            b.clear()
            b.order(ByteOrder.nativeOrder())
            val cap = b.capacity() / 2
            val take = min(cap - cap % ch, total - pos)
            b.asShortBuffer().put(pcm, pos, take)
            val pts = framesWritten * 1_000_000L / rate
            enc.queueInputBuffer(ii, 0, take * 2, pts, 0)
            pos += take
            framesWritten += take / ch
        }
    }

    fun finish() {
        if (closed) return
        try {
            var queued = false
            while (!queued) {
                val ii = enc.dequeueInputBuffer(10_000)
                if (ii >= 0) {
                    enc.queueInputBuffer(ii, 0, 0, framesWritten * 1_000_000L / rate, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    queued = true
                } else {
                    drain(false)
                }
            }
            drain(true)
            if (started) muxer.stop()
        } finally {
            release()
        }
    }

    fun release() {
        if (closed) return
        closed = true
        try {
            enc.stop()
        } catch (_: Throwable) {
        }
        try {
            enc.release()
        } catch (_: Throwable) {
        }
        try {
            muxer.release()
        } catch (_: Throwable) {
        }
    }
}
