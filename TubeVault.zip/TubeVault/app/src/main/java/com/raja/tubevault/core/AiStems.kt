package com.raja.tubevault.core

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.raja.tubevault.App
import com.raja.tubevault.BuildConfig
import com.raja.tubevault.MainActivity
import com.raja.tubevault.R
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.security.MessageDigest

/**
 * On-device AI voice remover (MDX-Net "UVR-MDX-NET-Inst_HQ_3" model, MIT licence, from the
 * Ultimate Vocal Remover project). The model is downloaded once (about 67 MB); everything runs
 * on the phone, so it is free and works offline.
 */
object AiStems {
    const val MODEL_FILE = "vocal-model.onnx"
    const val MODEL_SIZE = 66_759_214L
    const val MODEL_SHA256 = "317554b07fe1ea5279a77f2b1520a41ea4b93432560c4ffd08792c30fddf9adc"
    private const val MODEL_URL_UVR =
        "https://github.com/TRvlvr/model_repo/releases/download/all_public_uvr_models/UVR-MDX-NET-Inst_HQ_3.onnx"
    private const val N_FFT = 6144
    private const val DIM_F = 3072
    private const val DIM_T = 256
    private const val COMPENSATE = 1.022f
    private const val MAX_MINUTES = 12

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var modelJob: Job? = null
    private var stemJob: Job? = null
    @Volatile
    private var cancelFlag = false

    // ---- model state
    var modelReady by mutableStateOf(false)
        private set
    var modelBusy by mutableStateOf(false)
        private set
    var modelProgress by mutableFloatStateOf(0f)
        private set
    var modelError by mutableStateOf<String?>(null)
        private set

    // ---- job state
    var jobItemId by mutableStateOf<String?>(null)
        private set
    var jobStage by mutableStateOf("")
        private set
    var jobProgress by mutableFloatStateOf(0f)
        private set
    var jobEtaSec by mutableIntStateOf(-1)
        private set
    var jobError by mutableStateOf<String?>(null)
        private set
    val jobRunning: Boolean get() = jobItemId != null

    /** Bumped when a karaoke track is created or deleted (so screens refresh). */
    var stemVersion by mutableIntStateOf(0)
        private set

    /** Play the AI karaoke track (no singer) instead of the original song. */
    var backingOn by mutableStateOf(false)
        private set

    private fun modelFile(ctx: Context) = File(File(ctx.filesDir, "models").apply { mkdirs() }, MODEL_FILE)
    private fun stemDir(ctx: Context) = File(ctx.filesDir, "stems").apply { mkdirs() }
    fun stemFile(ctx: Context, id: String) = File(stemDir(ctx), "$id.m4a")

    fun hasStem(ctx: Context, id: String): Boolean {
        @Suppress("UNUSED_VARIABLE") val v = stemVersion
        return stemFile(ctx, id).let { it.exists() && it.length() > 10_000L }
    }

    /** Uri the player should use for this song (the AI karaoke track when switched on). */
    fun playUri(ctx: Context, item: DownloadItem): String? {
        if (backingOn && item.isAudio && item.place != Place.VAULT && hasStem(ctx, item.id)) {
            return Uri.fromFile(stemFile(ctx, item.id)).toString()
        }
        return item.uri
    }

    fun init(ctx: Context) {
        val f = modelFile(ctx)
        modelReady = f.exists() && f.length() == MODEL_SIZE
        File(ctx.filesDir, "models").listFiles()?.forEach { if (it.name.endsWith(".part") && !modelBusy) it.delete() }
    }

    fun setBacking(ctx: Context, on: Boolean) {
        if (backingOn == on) return
        backingOn = on
        PlayerHub.applyBacking(ctx)
    }

    fun deleteStem(ctx: Context, id: String) {
        try {
            stemFile(ctx, id).delete()
        } catch (_: Throwable) {
        }
        stemVersion++
        if (backingOn) PlayerHub.applyBacking(ctx)
    }

    // ------------------------------------------------------------------ model download

    private fun modelUrls(): List<String> {
        val own = if (Updater.configured) "https://github.com/" + BuildConfig.UPDATE_REPO + "/releases/download/models/" + MODEL_FILE else null
        return listOfNotNull(own, MODEL_URL_UVR)
    }

    fun downloadModel(ctx: Context) {
        if (modelBusy || modelReady) return
        val app = ctx.applicationContext
        modelBusy = true
        modelError = null
        modelProgress = 0f
        modelJob = scope.launch {
            val dest = modelFile(app)
            val part = File(dest.parentFile, dest.name + ".part")
            var lastErr: Throwable? = null
            try {
                for (u in modelUrls()) {
                    try {
                        fetch(u, part)
                        if (part.length() != MODEL_SIZE) throw IOException("The model file is incomplete")
                        modelProgress = 0.99f
                        if (sha256(part) != MODEL_SHA256) {
                            part.delete()
                            throw IOException("The model file is damaged")
                        }
                        if (dest.exists()) dest.delete()
                        if (!part.renameTo(dest)) throw IOException("Couldn't save the model")
                        modelReady = true
                        lastErr = null
                        break
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Throwable) {
                        lastErr = e
                    }
                }
                if (lastErr != null) modelError = friendly(lastErr)
            } finally {
                modelBusy = false
            }
        }
    }

    fun cancelModelDownload() {
        modelJob?.cancel()
        modelBusy = false
    }

    private suspend fun fetch(url: String, part: File) {
        var have = if (part.exists()) part.length() else 0L
        if (have > MODEL_SIZE) {
            part.delete()
            have = 0L
        }
        val rb = Request.Builder().url(url).header("User-Agent", "TubeVault")
        if (have > 0) rb.header("Range", "bytes=$have-")
        Net.client.newCall(rb.build()).execute().use { resp ->
            if (resp.code == 416) {
                part.delete()
                throw IOException("Download interrupted, try again")
            }
            if (!resp.isSuccessful) throw HttpStatusException(resp.code)
            val append = resp.code == 206
            var done = if (append) have else 0L
            val body = resp.body ?: throw IOException("Empty response")
            val buf = ByteArray(128 * 1024)
            FileOutputStream(part, append).use { out ->
                body.byteStream().use { ins ->
                    var lastUi = 0L
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        val now = System.nanoTime()
                        if (now - lastUi > 250_000_000L) {
                            lastUi = now
                            modelProgress = (done.toFloat() / MODEL_SIZE).coerceIn(0f, 0.98f)
                        }
                    }
                }
            }
        }
    }

    private fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { ins ->
            val buf = ByteArray(256 * 1024)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { b -> "%02x".format(b) }
    }

    private fun friendly(e: Throwable): String = when (e) {
        is java.net.UnknownHostException -> "No internet connection."
        is java.net.SocketTimeoutException -> "Connection timed out. Please try again."
        is HttpStatusException -> "Download failed (server error " + e.code + ")."
        else -> e.message ?: "Something went wrong."
    }

    // ------------------------------------------------------------------ separation job

    fun cancelJob() {
        cancelFlag = true
    }

    /** [best] = more overlap between chunks (smoother, about 25% slower). */
    fun start(ctx: Context, item: DownloadItem, best: Boolean) {
        if (jobRunning || !modelReady) return
        if (item.uri == null || item.place == Place.VAULT || !item.isAudio) return
        val app = ctx.applicationContext
        cancelFlag = false
        jobItemId = item.id
        jobStage = "Reading the song"
        jobProgress = 0f
        jobEtaSec = -1
        jobError = null
        StemService.start(app)
        stemJob = scope.launch {
            var ort: OrtMdx? = null
            try {
                // 1) decode (44.1 kHz stereo)
                val song = PcmDecoder.decode44k(app, Uri.parse(item.uri), MAX_MINUTES, { cancelFlag }) { p ->
                    jobProgress = p * 0.05f
                }

                // 2) load the AI model
                jobStage = "Starting the AI"
                val mdx = OrtMdx(modelFile(app).absolutePath, DIM_F, DIM_T)
                ort = mdx

                // 3) separate and stream into an .m4a
                val out = File(stemDir(app), item.id + ".m4a.part")
                val writer = AacWriter(out, PcmDecoder.TARGET_RATE, 2, 192_000)
                var finished = false
                try {
                    val dsp = MdxDsp(N_FFT, 1024, DIM_F, DIM_T)
                    val engine = StemEngine(dsp, COMPENSATE, if (best) 0.25f else 0.02f)
                    jobStage = "Removing the voice"
                    val t0 = System.nanoTime()
                    val ok = engine.run(
                        pcm = song.pcm,
                        frames = song.frames,
                        model = { spec -> mdx.run(spec) },
                        sink = { buf, count -> writer.write(buf, count) },
                        onProgress = { done, total ->
                            jobProgress = 0.05f + 0.93f * done / total
                            val el = (System.nanoTime() - t0) / 1e9
                            jobEtaSec = if (done >= 1) (el / done * (total - done)).toInt() else -1
                            jobStage = "Removing the voice  ($done of $total)"
                        },
                        isCancelled = { cancelFlag || !stemJobActive() }
                    )
                    if (!ok) throw InterruptedException("cancelled")
                    jobStage = "Saving"
                    writer.finish()
                    finished = true
                } finally {
                    if (!finished) writer.release()
                }
                val dest = stemFile(app, item.id)
                if (dest.exists()) dest.delete()
                if (!out.renameTo(dest)) throw IOException("Couldn't save the karaoke track")
                stemVersion++
                backingOn = true
                jobProgress = 1f
                PlayerHub.applyBacking(app)
                StemService.notifyDone(app, item.title)
            } catch (e: CancellationException) {
                // cancelled
            } catch (e: InterruptedException) {
                // cancelled by the user
            } catch (e: SongTooLongException) {
                jobError = "This song is too long. Songs up to $MAX_MINUTES minutes work."
            } catch (e: OutOfMemoryError) {
                jobError = "This phone ran out of memory. Close other apps and try again."
            } catch (e: Throwable) {
                jobError = e.message ?: "The AI could not finish this song."
            } finally {
                try {
                    ort?.close()
                } catch (_: Throwable) {
                }
                try {
                    File(stemDir(app), item.id + ".m4a.part").delete()
                } catch (_: Throwable) {
                }
                jobItemId = null
                jobEtaSec = -1
                StemService.stop(app)
            }
        }
    }

    private fun stemJobActive(): Boolean = stemJob?.isActive != false
}

/** ONNX Runtime wrapper for the MDX-Net network. */
class OrtMdx(modelPath: String, dimF: Int, dimT: Int) {
    private val env = OrtEnvironment.getEnvironment()
    private val session: OrtSession
    private val inputName: String
    private val shape = longArrayOf(1, 4, dimF.toLong(), dimT.toLong())
    private val size = 4 * dimF * dimT
    private val inBuf: FloatBuffer =
        ByteBuffer.allocateDirect(size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
    private val outArr = FloatArray(size)

    init {
        val cores = Runtime.getRuntime().availableProcessors()
        val threads = Math.min(4, Math.max(2, cores / 2))
        val opts = OrtSession.SessionOptions()
        opts.setIntraOpNumThreads(threads)
        opts.setInterOpNumThreads(1)
        opts.setMemoryPatternOptimization(false)
        opts.setCpuArenaAllocator(false)
        opts.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.BASIC_OPT)
        session = env.createSession(modelPath, opts)
        inputName = session.inputNames.iterator().next()
    }

    fun run(spec: FloatArray): FloatArray {
        inBuf.clear()
        inBuf.put(spec, 0, size)
        inBuf.rewind()
        OnnxTensor.createTensor(env, inBuf, shape).use { t ->
            session.run(mapOf(inputName to t)).use { res ->
                val o = res.get(0) as OnnxTensor
                val fb = o.floatBuffer
                fb.rewind()
                fb.get(outArr, 0, size)
            }
        }
        return outArr
    }

    fun close() {
        try {
            session.close()
        } catch (_: Throwable) {
        }
    }
}

/** Keeps the process alive (with a progress notification) while the AI works on a song. */
class StemService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        ServiceCompat.startForeground(this, NOTIF_ID, build("Starting…", 0, true), type)
        if (job == null) {
            job = scope.launch {
                while (true) {
                    delay(1000)
                    if (!AiStems.jobRunning) {
                        ServiceCompat.stopForeground(this@StemService, ServiceCompat.STOP_FOREGROUND_REMOVE)
                        stopSelf()
                        break
                    }
                    val pct = (AiStems.jobProgress * 100).toInt()
                    val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    nm.notify(NOTIF_ID, build(AiStems.jobStage, pct, false))
                }
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun build(text: String, pct: Int, indeterminate: Boolean): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, App.CH_PROGRESS)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle("AI is removing the voice")
            .setContentText(if (indeterminate) text else "$text • $pct%")
            .setProgress(100, pct, indeterminate)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .build()
    }

    companion object {
        private const val NOTIF_ID = 1007

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, StemService::class.java))
            } catch (_: Throwable) {
            }
        }

        fun stop(ctx: Context) {
            try {
                ctx.stopService(Intent(ctx, StemService::class.java))
            } catch (_: Throwable) {
            }
        }

        fun notifyDone(ctx: Context, title: String) {
            try {
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                val open = PendingIntent.getActivity(
                    ctx, 8, Intent(ctx, MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                val n = NotificationCompat.Builder(ctx, Updater.CH_UPDATE)
                    .setSmallIcon(R.drawable.ic_stat_download)
                    .setContentTitle("Karaoke track ready")
                    .setContentText(title)
                    .setContentIntent(open)
                    .setAutoCancel(true)
                    .build()
                nm.notify(1008, n)
            } catch (_: Throwable) {
            }
        }
    }
}
