package com.raja.tubevault.core

import android.content.Context
import android.net.Uri
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.tanh

/** Mixes a recorded voice with the AI karaoke track into one finished song (.m4a). */
object VoiceMixer {
    private const val RATE = 44100

    private fun soft(x: Float): Float {
        val a = abs(x)
        if (a <= 0.92f) return x
        val y = 0.92f + 0.08f * tanh((a - 0.92f) / 0.08f)
        return if (x < 0f) -y else y
    }

    /**
     * @param offsetMs where the voice starts on the song timeline (negative = voice was recorded a little early)
     */
    fun mix(
        ctx: Context, backing: File, voice: File,
        voiceGain: Float, musicGain: Float, offsetMs: Long,
        out: File, isCancelled: () -> Boolean, onProgress: (Float) -> Unit
    ) {
        val music = PcmDecoder.decode44k(ctx, Uri.fromFile(backing), 20, isCancelled) { }
        val vo = PcmDecoder.decode44k(ctx, Uri.fromFile(voice), 20, isCancelled) { }
        val offFrames = (offsetMs * RATE / 1000L).toInt()

        // end the song shortly after you stop singing
        var endFrame = music.frames
        val voiceEnd = offFrames + vo.frames
        if (voiceEnd > 0) endFrame = min(music.frames, voiceEnd + 3 * RATE)

        // gentle high-pass on the voice (removes handling rumble)
        val hpA = 0.989f
        var prevIn = 0f
        var prevOut = 0f

        val writer = AacWriter(out, RATE, 2, 192_000)
        var ok = false
        try {
            val chunk = RATE
            val buf = ShortArray(chunk * 2)
            var pos = 0
            while (pos < endFrame) {
                if (isCancelled()) throw InterruptedException("cancelled")
                val cnt = min(chunk, endFrame - pos)
                for (j in 0 until cnt) {
                    val t = pos + j
                    var l = music.pcm[t * 2] / 32768f * musicGain
                    var r = music.pcm[t * 2 + 1] / 32768f * musicGain
                    val vi = t - offFrames
                    var v = 0f
                    if (vi >= 0 && vi < vo.frames) v = vo.pcm[vi * 2] / 32768f
                    // high-pass is run for every sample so the filter state stays continuous
                    val hp = hpA * (prevOut + v - prevIn)
                    prevIn = v
                    prevOut = hp
                    l += hp * voiceGain
                    r += hp * voiceGain
                    buf[j * 2] = Math.round(soft(l) * 32767f).coerceIn(-32768, 32767).toShort()
                    buf[j * 2 + 1] = Math.round(soft(r) * 32767f).coerceIn(-32768, 32767).toShort()
                }
                writer.write(buf, cnt)
                pos += cnt
                onProgress(max(0f, min(1f, pos.toFloat() / endFrame)))
            }
            writer.finish()
            ok = true
        } finally {
            if (!ok) writer.release()
        }
    }
}
