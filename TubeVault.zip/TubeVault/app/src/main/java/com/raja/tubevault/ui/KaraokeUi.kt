@file:OptIn(ExperimentalLayoutApi::class)

package com.raja.tubevault.ui

import android.os.Build
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.LongState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.raja.tubevault.core.DownloadItem
import com.raja.tubevault.core.Fx
import com.raja.tubevault.core.KStatus
import com.raja.tubevault.core.Karaoke
import com.raja.tubevault.core.LyricLine
import com.raja.tubevault.core.LyricWord
import com.raja.tubevault.core.PlayerHub
import com.raja.tubevault.core.WhisperModels
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

// ============================================================================ the "how things move" curves

private fun kLerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t.coerceIn(0f, 1f)

/** d = line index - focus. 0 = the line being sung, negative = already sung (they drift up and vanish). */
private fun kAlpha(d: Float): Float {
    if (d >= 0f) {
        return when {
            d <= 1f -> kLerp(1f, 0.50f, d)
            d <= 2f -> kLerp(0.50f, 0.30f, d - 1f)
            d <= 4f -> kLerp(0.30f, 0.13f, (d - 2f) / 2f)
            d <= 7f -> kLerp(0.13f, 0f, (d - 4f) / 3f)
            else -> 0f
        }
    }
    val a = -d
    return when {
        a <= 1f -> kLerp(1f, 0.14f, a)
        a <= 2f -> kLerp(0.14f, 0f, a - 1f)
        else -> 0f
    }
}

private fun kScale(d: Float): Float {
    val a = abs(d)
    return if (d >= 0f) kLerp(1f, 0.80f, min(a, 1f)) - 0.02f * min(max(a - 1f, 0f), 3f)
    else kLerp(1f, 0.84f, min(a, 1f)) - 0.07f * min(max(a - 1f, 0f), 2f)
}

/** extra upward push (dp) for lines that were already sung */
private fun kLift(d: Float): Float = if (d >= 0f) 0f else d.coerceAtLeast(-3f) * 22f

private fun kBlur(d: Float): Float {
    val b = if (d >= 0f) max(0f, d - 0.6f) * 1.7f else -d * 5f
    return (min(b, 10f) * 2f).roundToInt() / 2f
}

private fun kActive(lines: List<LyricLine>, t: Long): Int {
    var lo = 0
    var hi = lines.lastIndex
    var ans = -1
    while (lo <= hi) {
        val mid = (lo + hi) ushr 1
        if (lines[mid].startMs <= t) {
            ans = mid
            lo = mid + 1
        } else hi = mid - 1
    }
    if (ans < 0) return 0
    if (ans == lines.lastIndex && t > lines[ans].endMs + 2500L) return lines.size // song's lyrics are over
    return ans
}

private fun kProgress(w: LyricWord, t: Long): Float {
    val d = (w.endMs - w.startMs).coerceAtLeast(120L)
    return ((t - w.startMs).toFloat() / d).coerceIn(0f, 1f)
}

// ============================================================================ stage

@Composable
fun KaraokeStage(
    item: DownloadItem,
    playing: Boolean,
    viz: VizState,
    player: Player,
    onTapEmpty: () -> Unit,
    onOpenSetup: () -> Unit,
    modifier: Modifier = Modifier
) {
    val ac1 by animateColorAsState(Color(PlayerHub.accentA), tween(900), label = "kc1")
    val ac2 by animateColorAsState(Color(PlayerHub.accentB), tween(900), label = "kc2")
    viz.c1 = ac1
    viz.c2 = ac2

    val mine = Karaoke.forId == item.id
    val status = if (mine) Karaoke.status else KStatus.IDLE
    val lines = if (mine) Karaoke.timeline else emptyList()

    Box(
        modifier
            .fillMaxSize()
            .pointerInput(Unit) { detectTapGestures { onTapEmpty() } }
    ) {
        KBackdrop(item, viz, ac1, ac2, playing)
        when {
            status == KStatus.READY && lines.isNotEmpty() -> KLyrics(lines, playing, player, ac1, ac2, onTapEmpty)
            status == KStatus.IDLE || status == KStatus.FAILED -> KStart(status, ac1, ac2, onOpenSetup)
            else -> KWorking(status, Karaoke.progress, ac1, ac2)
        }
    }
}

// ============================================================================ backdrop: blurred art, glows, rising particles

@Composable
private fun KBackdrop(item: DownloadItem, viz: VizState, a1: Color, a2: Color, playing: Boolean) {
    val ctx = LocalContext.current
    val t = remember { androidx.compose.runtime.mutableFloatStateOf(0f) }
    LaunchedEffect(playing) {
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            val dt = (now - last) / 1_000_000_000f
            last = now
            if (playing) t.floatValue = t.floatValue + dt * (0.35f + viz.level * 1.6f)
        }
    }
    val seeds = remember {
        val r = java.util.Random(7)
        Array(34) { floatArrayOf(r.nextFloat(), r.nextFloat(), 0.4f + r.nextFloat() * 0.9f, r.nextFloat()) }
    }
    Box(Modifier.fillMaxSize().background(Color(0xFF07070D))) {
        Crossfade(item.thumbnail, animationSpec = tween(700), label = "kbg") { u ->
            AsyncImage(
                model = ImageRequest.Builder(ctx).data(u).build(),
                contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().blur(60.dp).graphicsLayer { alpha = 0.42f }
            )
        }
        Canvas(Modifier.fillMaxSize()) {
            val k = viz.tick.longValue
            val b = viz.bass
            val c1 = Offset(size.width * 0.12f, size.height * 0.2f)
            val c2 = Offset(size.width * 0.92f, size.height * 0.8f)
            drawCircle(
                Brush.radialGradient(listOf(a1.copy(alpha = 0.14f + 0.36f * b), Color.Transparent), center = c1, radius = size.minDimension * (0.6f + 0.35f * b)),
                size.minDimension, c1
            )
            drawCircle(
                Brush.radialGradient(listOf(a2.copy(alpha = 0.12f + 0.30f * viz.level), Color.Transparent), center = c2, radius = size.minDimension * (0.65f + 0.3f * viz.level)),
                size.minDimension, c2
            )
            val tm = t.floatValue
            for (s in seeds) {
                val fr = (s[3] + tm * 0.05f * s[2]) % 1f
                val y = size.height * (1f - fr)
                val x = size.width * s[0] + sin((tm * 0.6f * s[2] + s[1] * 6.28f).toDouble()).toFloat() * 18.dp.toPx()
                val a = sin(PI * fr).toFloat() * (0.10f + 0.45f * viz.level) * s[2]
                drawCircle((if (s[1] > 0.5f) a1 else a2).copy(alpha = a.coerceIn(0f, 0.7f)), (1.2f + 2.6f * s[2]).dp.toPx(), Offset(x, y))
            }
            if (k < 0) drawCircle(Color.Transparent, 1f)
        }
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x55000000), Color(0xCC07070D)))))
    }
}

// ============================================================================ lyrics

@Composable
private fun KLyrics(
    lines: List<LyricLine>,
    playing: Boolean,
    player: Player,
    a1: Color,
    a2: Color,
    onTapEmpty: () -> Unit
) {
    val clock = remember { mutableLongStateOf(0L) }
    val playingNow by rememberUpdatedState(playing)
    LaunchedEffect(player) {
        while (true) {
            if (playingNow) withFrameNanos { } else delay(100)
            clock.longValue = player.currentPosition + Karaoke.offsetMs
        }
    }

    val n = lines.size
    val active by remember(lines) { derivedStateOf { kActive(lines, clock.longValue + 140L) } }
    val focus = remember(lines) { Animatable(active.toFloat()) }
    LaunchedEffect(lines, active) {
        val target = active.toFloat()
        if (abs(focus.value - target) > 3.5f) focus.snapTo(target)
        else focus.animateTo(target, spring(dampingRatio = 0.8f, stiffness = 120f))
    }

    val lo = (active - 3).coerceAtLeast(0)
    val hi = (active + 8).coerceAtMost(n - 1)

    Layout(
        content = {
            for (i in lo..hi) {
                key(i) {
                    KLineView(i, lines[i], active, focus, clock, a1, a2) {
                        if (i == active) onTapEmpty()
                        else player.seekTo(max(0L, lines[i].startMs - Karaoke.offsetMs - 120L))
                    }
                }
            }
        },
        modifier = Modifier.fillMaxSize().clipToBounds()
    ) { measurables, constraints ->
        val side = 26.dp.roundToPx()
        val maxW = (constraints.maxWidth - side * 2).coerceAtLeast(0)
        val c = Constraints(minWidth = maxW, maxWidth = maxW, minHeight = 0, maxHeight = Constraints.Infinity)
        val ps = measurables.map { it.measure(c) }
        val gap = 20.dp.roundToPx()
        val tops = IntArray(ps.size)
        var y = 0
        for (k in ps.indices) {
            tops[k] = y
            y += ps[k].height + gap
        }
        layout(constraints.maxWidth, constraints.maxHeight) {
            if (ps.isNotEmpty()) {
                val f = focus.value
                val fl = floor(f).toInt()
                val fr = f - fl
                fun center(idx: Int): Float {
                    val k = (idx - lo).coerceIn(0, ps.lastIndex)
                    return tops[k] + ps[k].height / 2f
                }
                val c0 = center(fl) * (1f - fr) + center(fl + 1) * fr
                val anchor = constraints.maxHeight * 0.36f
                for (k in ps.indices) {
                    ps[k].place(side, (tops[k] - c0 + anchor).roundToInt())
                }
            }
        }
    }
}

@Composable
private fun KLineView(
    index: Int,
    line: LyricLine,
    active: Int,
    focus: Animatable<Float, AnimationVector1D>,
    clock: LongState,
    a1: Color,
    a2: Color,
    onTap: () -> Unit
) {
    val live = index == active
    val done = index < active
    Box(
        Modifier
            .fillMaxWidth()
            .graphicsLayer {
                val d = index - focus.value
                alpha = kAlpha(d)
                val s = kScale(d)
                scaleX = s
                scaleY = s
                translationY = kLift(d) * density
                val b = kBlur(d)
                renderEffect = if (Build.VERSION.SDK_INT >= 31 && b >= 1f) BlurEffect(b, b, TileMode.Decal) else null
            }
            .pointerInput(index) { detectTapGestures { onTap() } },
        contentAlignment = Alignment.Center
    ) {
        if (line.isBreak) KBreakDots(line, live, done, clock, a1)
        else KWords(line, live, done, clock, a1, a2)
    }
}

@Composable
private fun KWords(line: LyricLine, live: Boolean, done: Boolean, clock: LongState, a1: Color, a2: Color) {
    FlowRow(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        for (w in line.words) KWord(w, live, done, clock, a1)
    }
}

@Composable
private fun KWord(w: LyricWord, live: Boolean, done: Boolean, clock: LongState, glow: Color) {
    val dim = remember {
        TextStyle(color = Color.White.copy(alpha = 0.42f), fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 38.sp, textAlign = TextAlign.Center)
    }
    val lit = remember(glow) {
        dim.copy(color = Color.White, shadow = Shadow(glow.copy(alpha = 0.95f), Offset.Zero, 28f))
    }
    val plain = remember { dim.copy(color = Color.White) }
    Box(
        Modifier.graphicsLayer {
            if (live) {
                val p = kProgress(w, clock.longValue)
                val bump = sin(PI * p).toFloat()
                val s = 1f + 0.09f * bump
                scaleX = s
                scaleY = s
                translationY = -4.dp.toPx() * bump
            }
        }
    ) {
        BasicText(w.text, style = dim)
        if (done) {
            BasicText(w.text, style = plain)
        } else if (live) {
            BasicText(
                w.text, style = lit,
                modifier = Modifier
                    .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                    .drawWithContent {
                        drawContent()
                        // soft-edged sweep: everything left of the front stays, the rest is erased
                        val p = kProgress(w, clock.longValue)
                        val wd = size.width.coerceAtLeast(1f)
                        val edge = max(wd * 0.4f, 10f)
                        val x = p * (wd + edge)
                        val s1 = ((x - edge) / wd).coerceIn(0f, 1f)
                        val s2 = (x / wd).coerceIn(s1, 1f)
                        drawRect(
                            Brush.horizontalGradient(
                                0f to Color.Black, s1 to Color.Black, s2 to Color.Transparent, 1f to Color.Transparent,
                                startX = 0f, endX = wd
                            ),
                            blendMode = BlendMode.DstIn
                        )
                    }
            )
        }
    }
}

/** the "• • •" shown during intros and long instrumental parts: fills up like a count-in */
@Composable
private fun KBreakDots(line: LyricLine, live: Boolean, done: Boolean, clock: LongState, a1: Color) {
    Canvas(Modifier.size(width = 150.dp, height = 44.dp)) {
        val t = if (live) clock.longValue else if (done) line.endMs else line.startMs
        val span = (line.endMs - line.startMs).coerceAtLeast(1L)
        val p = ((t - line.startMs).toFloat() / span).coerceIn(0f, 1f)
        val breath = if (live) 1f + 0.12f * sin(t / 260.0).toFloat() else 1f
        for (i in 0 until 3) {
            val fill = ((p - i / 3f) * 3f).coerceIn(0f, 1f)
            val c = Offset(size.width / 2f + (i - 1) * 38.dp.toPx(), size.height / 2f)
            val r = (7.dp.toPx() + 3.dp.toPx() * fill) * breath
            drawCircle(Color.White.copy(alpha = 0.28f), r, c)
            if (fill > 0f) {
                drawCircle(Brush.radialGradient(listOf(a1.copy(alpha = 0.6f * fill), Color.Transparent), center = c, radius = r * 3f), r * 3f, c)
                drawCircle(Color.White.copy(alpha = fill), r, c)
            }
        }
    }
}

// ============================================================================ "no lyrics yet" and "working" states

@Composable
private fun KStart(status: KStatus, a1: Color, a2: Color, onOpenSetup: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "kstart")
    val ph by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "ph")
    Column(
        Modifier.fillMaxSize().padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(150.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                for (i in 0 until 3) {
                    val q = (ph + i / 3f) % 1f
                    drawCircle(a1.copy(alpha = (1f - q) * 0.5f), 34.dp.toPx() + q * 40.dp.toPx(), center, style = Stroke(2.dp.toPx()))
                }
            }
            Box(
                Modifier.size(72.dp).clip(CircleShape).background(Brush.linearGradient(listOf(a1, a2))),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.Mic, null, tint = Color.White, modifier = Modifier.size(34.dp)) }
        }
        Spacer(Modifier.height(14.dp))
        Text("Karaoke mode", color = Color.White, fontWeight = FontWeight.Black, fontSize = 26.sp)
        Spacer(Modifier.height(8.dp))
        Text(
            "Create synced lyrics for this song, then watch every word light up as it is sung.",
            color = TextLo, fontSize = 14.sp, textAlign = TextAlign.Center
        )
        val err = Karaoke.error
        if (status == KStatus.FAILED && err != null) {
            Spacer(Modifier.height(12.dp))
            Text(err, color = Color(0xFFFF9AA2), fontSize = 13.sp, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(22.dp))
        GradientButton(if (status == KStatus.FAILED) "Try again" else "Create lyrics", false, Modifier.widthIn(max = 320.dp)) { onOpenSetup() }
    }
}

@Composable
private fun KWorking(status: KStatus, progress: Float, a1: Color, a2: Color) {
    val title = when (status) {
        KStatus.DECODING -> "Reading the song"
        KStatus.MODEL -> "Downloading the speech model"
        KStatus.TRANSCRIBING -> "Listening to the vocals"
        KStatus.FETCHING -> "Searching synced lyrics"
        else -> "Working"
    }
    val sub = when (status) {
        KStatus.MODEL -> "First time only. Keep TubeVault open."
        KStatus.TRANSCRIBING -> "This runs on your phone and can take a few minutes. Keep TubeVault open."
        else -> "Just a moment"
    }
    Column(
        Modifier.fillMaxSize().padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        KOrb(progress, a1, a2)
        Spacer(Modifier.height(18.dp))
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(sub, color = TextLo, fontSize = 13.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(18.dp))
        Row(
            Modifier
                .pressable { Karaoke.cancel() }
                .clip(RoundedCornerShape(50))
                .background(Glass)
                .border(BorderStroke(1.dp, GlassBorder), RoundedCornerShape(50))
                .padding(horizontal = 18.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(Icons.Rounded.Close, null, tint = Color.White, modifier = Modifier.size(16.dp))
            Text("Cancel", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

/** progress ring with orbiting sparks. progress < 0 = unknown (the arc just spins) */
@Composable
private fun KOrb(progress: Float, a1: Color, a2: Color) {
    val inf = rememberInfiniteTransition(label = "orb")
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(4200, easing = LinearEasing)), label = "spin")
    val pulse by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1500), RepeatMode.Reverse), label = "pulse")
    val p by animateFloatAsState(progress.coerceIn(0f, 1f), tween(400), label = "op")
    Box(Modifier.size(210.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val r = size.minDimension / 2f - 18.dp.toPx()
            drawCircle(
                Brush.radialGradient(listOf(a1.copy(alpha = 0.22f + 0.22f * pulse), Color.Transparent), center = c, radius = r * 1.55f),
                r * 1.55f, c
            )
            drawCircle(Color.White.copy(alpha = 0.08f), r, c, style = Stroke(10.dp.toPx()))
            val unknown = progress < 0f
            drawArc(
                Brush.linearGradient(listOf(a2, a1)),
                startAngle = if (unknown) spin else -90f,
                sweepAngle = if (unknown) 100f else (360f * p).coerceAtLeast(3f),
                useCenter = false,
                topLeft = Offset(c.x - r, c.y - r),
                size = Size(r * 2f, r * 2f),
                style = Stroke(10.dp.toPx(), cap = StrokeCap.Round)
            )
            for (i in 0 until 6) {
                val a = Math.toRadians((spin * (1f + i * 0.15f) + i * 60f).toDouble())
                val rr = r - 22.dp.toPx() - (i % 3) * 8.dp.toPx()
                drawCircle(
                    (if (i % 2 == 0) a1 else a2).copy(alpha = 0.35f + 0.4f * pulse),
                    (2f + (i % 3)).dp.toPx(),
                    Offset(c.x + rr * kotlin.math.cos(a).toFloat(), c.y + rr * sin(a).toFloat())
                )
            }
        }
        if (progress >= 0f) {
            Text("${(p * 100).roundToInt()}%", color = Color.White, fontWeight = FontWeight.Black, fontSize = 34.sp)
        } else {
            Icon(Icons.Rounded.Search, null, tint = Color.White, modifier = Modifier.size(38.dp))
        }
    }
}

// ============================================================================ setup panel (bottom sheet content)

private val KARAOKE_LANGS = listOf(
    "auto" to "Auto", "en" to "English", "hi" to "Hindi", "ur" to "Urdu", "pa" to "Punjabi", "bn" to "Bengali",
    "ta" to "Tamil", "te" to "Telugu", "es" to "Spanish", "ko" to "Korean", "ja" to "Japanese", "ar" to "Arabic"
)

@Composable
private fun KChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .pressable(onClick)
            .clip(shape)
            .then(if (selected) Modifier.background(AccentBrush) else Modifier.background(Glass))
            .border(BorderStroke(1.dp, if (selected) Color.Transparent else GlassBorder), shape)
            .padding(horizontal = 15.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
}

@Composable
private fun KStep(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .pressable(onClick)
            .clip(CircleShape)
            .background(Glass)
            .border(BorderStroke(1.dp, GlassBorder), CircleShape),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
}

private fun kSec(ms: Long): String = "%.1f s".format(ms / 1000f)

@Composable
fun KaraokePanelContent(item: DownloadItem, durationMs: Long, onClose: () -> Unit = {}) {
    val ctx = LocalContext.current
    val mine = Karaoke.forId == item.id
    val status = if (mine) Karaoke.status else KStatus.IDLE
    val busyOther = Karaoke.busyId != null && Karaoke.busyId != item.id

    Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Column {
            Text("Karaoke lyrics", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("Words light up in time with the singing", color = TextLo, fontSize = 12.sp)
        }

        // ---- vocal remover: sing over the music
        DisposableEffect(Unit) { onDispose { Fx.save(ctx) } }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Remove singer's voice", color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Text("Keeps the music so you can sing", color = TextLo, fontSize = 12.sp)
            }
            PremiumSwitch(Fx.vocalCut > 0.01f) {
                Fx.vocalCut = if (it) 0.9f else 0f
                Fx.touch()
            }
        }
        if (Fx.vocalCut > 0.01f) {
            GlowSlider(Fx.vocalCut, { Fx.vocalCut = it.coerceAtLeast(0.05f); Fx.touch() }, Modifier.fillMaxWidth(), colors = listOf(Violet, Pink))
            Text(
                "Works by cancelling what is in the middle of the stereo mix, so it works best on studio songs. Some voice or bass may remain. If the music sounds thin, lower the strength.",
                color = TextLo, fontSize = 12.sp
            )
        }

        AiVoiceSection(item)

        when {
            status == KStatus.READY -> {
                Text(
                    "Lyrics ready: ${Karaoke.lineCount} lines" + if (Karaoke.source.isNotEmpty()) " (${Karaoke.source})" else "",
                    color = TextHi, fontSize = 14.sp, fontWeight = FontWeight.SemiBold
                )
                GradientButton(if (Karaoke.stageOn) "Back to the music disc" else "Start karaoke", false) {
                    Karaoke.stageOn = !Karaoke.stageOn
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Lyrics timing", color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        val o = Karaoke.offsetMs
                        Text(
                            when {
                                o == 0L -> "In sync"
                                o > 0L -> "Words come ${kSec(o)} earlier"
                                else -> "Words come ${kSec(-o)} later"
                            },
                            color = TextLo, fontSize = 12.sp
                        )
                    }
                    KStep("-") { Karaoke.setOffset(ctx, item.id, Karaoke.offsetMs - 100L) }
                    Spacer(Modifier.width(10.dp))
                    KStep("+") { Karaoke.setOffset(ctx, item.id, Karaoke.offsetMs + 100L) }
                }
                Text(
                    "Words appear too late? Tap +. Too early? Tap -.",
                    color = TextLo, fontSize = 12.sp
                )
                SingSection(item, onClose)
                Row {
                    PillButton(Icons.Rounded.Close, "Replace these lyrics", false) { Karaoke.reset(ctx, item) }
                }
            }

            status == KStatus.DECODING || status == KStatus.MODEL || status == KStatus.TRANSCRIBING || status == KStatus.FETCHING -> {
                Text(
                    when (status) {
                        KStatus.DECODING -> "Reading the song..."
                        KStatus.MODEL -> "Downloading the speech model..."
                        KStatus.TRANSCRIBING -> "Listening to the vocals..."
                        else -> "Searching synced lyrics..."
                    },
                    color = TextHi, fontSize = 15.sp, fontWeight = FontWeight.SemiBold
                )
                GradientProgress(Karaoke.progress)
                Text("Keep TubeVault open until this finishes.", color = TextLo, fontSize = 12.sp)
                Row { PillButton(Icons.Rounded.Close, "Cancel", false) { Karaoke.cancel() } }
            }

            else -> {
                if (busyOther) {
                    Text("Another song is still being processed.", color = TextLo, fontSize = 13.sp)
                    Row { PillButton(Icons.Rounded.Close, "Cancel that one", false) { Karaoke.cancel() } }
                }
                val err = Karaoke.error
                if (status == KStatus.FAILED && err != null) {
                    Text(err, color = Color(0xFFFF9AA2), fontSize = 13.sp)
                }

                Text("Song language", color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(KARAOKE_LANGS) { (code, name) ->
                        KChip(name, Karaoke.language == code) { Karaoke.chooseLanguage(ctx, code) }
                    }
                }
                Text("Picking the language yourself is more accurate than Auto.", color = TextLo, fontSize = 12.sp)

                Text("Accuracy", color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Segmented(WhisperModels.all.map { it.label }, Karaoke.modelIndex) { Karaoke.chooseModel(ctx, it) }
                val m = WhisperModels.all[Karaoke.modelIndex]
                val installed = remember(Karaoke.modelIndex, status) { WhisperModels.isReady(ctx, m) }
                Text(
                    if (installed) "Speech model installed. Works offline."
                    else "One-time download of about ${m.approxMb} MB. After that it works offline.",
                    color = TextLo, fontSize = 12.sp
                )

                GradientButton("Create lyrics with Whisper", false) {
                    if (!busyOther) Karaoke.startWhisper(ctx, item)
                }
                Text(
                    "Whisper runs on your phone: nothing about your music is uploaded. Louder, busier songs are harder to transcribe, so check the result and nudge the timing if needed.",
                    color = TextLo, fontSize = 12.sp
                )
                Row {
                    PillButton(Icons.Rounded.Search, "Find synced lyrics online", false) {
                        if (!busyOther) Karaoke.startOnline(ctx, item, durationMs)
                    }
                }
                Text("This sends the song title to lrclib.net, a free lyrics database.", color = TextLo, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(14.dp))
    }
}
