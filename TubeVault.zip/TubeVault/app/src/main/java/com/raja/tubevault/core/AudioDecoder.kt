package com.raja.tubevault.core

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.coroutines.coroutineContext

/** Decodes any song TubeVault can play (m4a / mp4 / webm-opus / mp3 ...) to 16 kHz mono float PCM, which is what Whisper wants. */
object AudioDecoder {
    const val TARGET_RATE = 16000
    private const val MAX_SECONDS = 15 * 60

    class TooLongException : IOException("This song is longer than 15 minutes")

    suspend fun decode16kMono(ctx: Context, uri: Uri, onProgress: (Float) -> Unit): FloatArray =
        withContext(Dispatchers.IO) {
            val extractor = MediaExtractor()
            var codec: MediaCodec? = null
            try {
                extractor.setDataSource(ctx, uri, null)
                var track = -1
                var fmt: MediaFormat? = null
                for (i in 0 until extractor.trackCount) {
                    val f = extractor.getTrackFormat(i)
                    if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) {
                        track = i
                        fmt = f
                        break
                    }
                }
                if (track < 0 || fmt == null) throw IOException("No audio track found in this file")
                extractor.selectTrack(track)
                val mime = fmt.getString(MediaFormat.KEY_MIME)!!
                val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
                if (durUs > MAX_SECONDS * 1_000_000L) throw TooLongException()

                codec = MediaCodec.createDecoderByType(mime)
                codec.configure(fmt, null, null, 0)
                codec.start()

                var srcRate = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
                var channels = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
                var pcmFloat = false

                var out = FloatArray(TARGET_RATE * 30)
                var outN = 0
                fun put(v: Float) {
                    if (outN == out.size) out = out.copyOf(out.size * 2)
                    out[outN++] = v
                }

                // streaming area-average resampler: input index n belongs to output bucket floor(n / ratio)
                var inIndex = 0L
                var bucket = 0L
                var sum = 0f
                var cnt = 0
                fun feed(s: Float) {
                    val ratio = srcRate.toDouble() / TARGET_RATE
                    val b = (inIndex / ratio).toLong()
                    if (b != bucket) {
                        val mean = if (cnt > 0) sum / cnt else 0f
                        var k = bucket
                        while (k < b) {
                            put(mean)
                            k++
                        }
                        bucket = b
                        sum = 0f
                        cnt = 0
                    }
                    sum += s
                    cnt++
                    inIndex++
                }

                val info = MediaCodec.BufferInfo()
                var inputDone = false
                var outputDone = false
                var lastReport = 0L
                while (!outputDone) {
                    coroutineContext.ensureActive()
                    if (!inputDone) {
                        val ii = codec.dequeueInputBuffer(5_000)
                        if (ii >= 0) {
                            val buf = codec.getInputBuffer(ii)!!
                            val n = extractor.readSampleData(buf, 0)
                            if (n < 0) {
                                codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                codec.queueInputBuffer(ii, 0, n, extractor.sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }
                    val oi = codec.dequeueOutputBuffer(info, 5_000)
                    when {
                        oi >= 0 -> {
                            if (info.size > 0) {
                                val ob = codec.getOutputBuffer(oi)!!
                                ob.position(info.offset)
                                ob.limit(info.offset + info.size)
                                ob.order(ByteOrder.nativeOrder())
                                if (pcmFloat) feedFloat(ob, channels, ::feed) else feedShort(ob, channels, ::feed)
                            }
                            codec.releaseOutputBuffer(oi, false)
                            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                            if (outN > TARGET_RATE * MAX_SECONDS) throw TooLongException()
                            val now = System.currentTimeMillis()
                            if (durUs > 0 && now - lastReport > 200) {
                                lastReport = now
                                onProgress((extractor.sampleTime.coerceAtLeast(0L).toFloat() / durUs).coerceIn(0f, 1f))
                            }
                        }
                        oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            val nf = codec.outputFormat
                            if (nf.containsKey(MediaFormat.KEY_SAMPLE_RATE)) srcRate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                            if (nf.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                            pcmFloat = nf.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                                nf.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                        }
                    }
                }
                if (cnt > 0) put(sum / cnt)
                onProgress(1f)
                if (outN < TARGET_RATE) throw IOException("The audio is too short")
                out.copyOf(outN)
            } finally {
                try {
                    codec?.stop()
                } catch (_: Throwable) {
                }
                try {
                    codec?.release()
                } catch (_: Throwable) {
                }
                extractor.release()
            }
        }

    private inline fun feedShort(bb: ByteBuffer, channels: Int, feed: (Float) -> Unit) {
        val sb = bb.asShortBuffer()
        val ch = channels.coerceAtLeast(1)
        val frames = sb.remaining() / ch
        for (f in 0 until frames) {
            var acc = 0
            for (c in 0 until ch) acc += sb.get()
            feed(acc / (32768f * ch))
        }
    }

    private inline fun feedFloat(bb: ByteBuffer, channels: Int, feed: (Float) -> Unit) {
        val fb = bb.asFloatBuffer()
        val ch = channels.coerceAtLeast(1)
        val frames = fb.remaining() / ch
        for (f in 0 until frames) {
            var acc = 0f
            for (c in 0 until ch) acc += fb.get()
            feed(acc / ch)
        }
    }
}
