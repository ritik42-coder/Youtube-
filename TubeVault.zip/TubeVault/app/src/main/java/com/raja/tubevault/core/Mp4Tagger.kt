package com.raja.tubevault.core

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.io.RandomAccessFile

/**
 * Writes title, artist and cover art (iTunes-style "ilst" tags) into an MP4 / M4A file.
 * The cover lives INSIDE the file, so Gallery / music apps show it, and TubeVault can
 * read it back after a reinstall (no more black thumbnails).
 *
 * Works on normal (non-fragmented) MP4s. If moov sits before mdat, every chunk offset is
 * shifted by the size change so the file stays valid. Returns false (and writes nothing
 * useful) when the file layout isn't one it can safely handle.
 */
object Mp4Tagger {
    private val CONTAINERS = setOf("moov", "trak", "mdia", "minf", "stbl", "edts", "dinf")
    private const val MAX_MOOV = 64L * 1024 * 1024

    fun tag(src: File, dst: File, title: String, artist: String, cover: ByteArray?): Boolean = try {
        tagInternal(src, dst, title, artist, cover)
    } catch (_: Throwable) {
        dst.delete()
        false
    }

    private fun tagInternal(src: File, dst: File, title: String, artist: String, cover: ByteArray?): Boolean {
        RandomAccessFile(src, "r").use { raf ->
            val len = raf.length()
            var pos = 0L
            var moovPos = -1L
            var moovSize = 0L
            var firstMdat = -1L
            val typeBuf = ByteArray(4)
            while (pos + 8 <= len) {
                raf.seek(pos)
                var size = raf.readInt().toLong() and 0xffffffffL
                raf.readFully(typeBuf)
                val type = String(typeBuf, Charsets.ISO_8859_1)
                var hdr = 8
                if (size == 1L) {
                    size = raf.readLong(); hdr = 16
                } else if (size == 0L) size = len - pos
                if (size < hdr || pos + size > len) return false
                when (type) {
                    "moov" -> if (hdr == 8) { moovPos = pos; moovSize = size } else return false
                    "mdat" -> if (firstMdat < 0) firstMdat = pos
                    "moof", "sidx", "mfra" -> return false // fragmented: offsets are relative, don't touch
                }
                pos += size
            }
            if (moovPos < 0 || moovSize > MAX_MOOV) return false

            val moov = ByteArray(moovSize.toInt())
            raf.seek(moovPos)
            raf.readFully(moov)

            // children of moov, minus any old udta, plus our new udta
            val body = ByteArrayOutputStream()
            var p = 8
            while (p + 8 <= moov.size) {
                val s = u32(moov, p)
                if (s < 8 || p + s > moov.size) return false
                val t = String(moov, p + 4, 4, Charsets.ISO_8859_1)
                if (t != "udta") body.write(moov, p, s.toInt())
                p += s.toInt()
            }
            body.write(udta(title, artist, cover))
            val inner = body.toByteArray()
            val newMoov = ByteArray(8 + inner.size)
            putU32(newMoov, 0, newMoov.size.toLong())
            "moov".toByteArray(Charsets.ISO_8859_1).copyInto(newMoov, 4)
            inner.copyInto(newMoov, 8)

            val delta = newMoov.size.toLong() - moovSize
            if (firstMdat >= 0 && moovPos < firstMdat && delta != 0L) {
                if (!patch(newMoov, 8, newMoov.size, delta)) return false
            }

            FileOutputStream(dst).use { out ->
                copy(raf, 0, moovPos, out)
                out.write(newMoov)
                val after = moovPos + moovSize
                copy(raf, after, len - after, out)
            }
        }
        return true
    }

    /** Shift every stco / co64 chunk offset by [delta]. */
    private fun patch(b: ByteArray, start: Int, end: Int, delta: Long): Boolean {
        var p = start
        while (p + 8 <= end) {
            val s = u32(b, p).toInt()
            if (s < 8 || p + s > end) return false
            when (val t = String(b, p + 4, 4, Charsets.ISO_8859_1)) {
                "stco" -> {
                    val n = u32(b, p + 12).toInt()
                    for (i in 0 until n) {
                        val at = p + 16 + i * 4
                        if (at + 4 > p + s) return false
                        val v = u32(b, at) + delta
                        if (v < 0 || v > 0xffffffffL) return false
                        putU32(b, at, v)
                    }
                }
                "co64" -> {
                    val n = u32(b, p + 12).toInt()
                    for (i in 0 until n) {
                        val at = p + 16 + i * 8
                        if (at + 8 > p + s) return false
                        putU64(b, at, u64(b, at) + delta)
                    }
                }
                else -> if (t in CONTAINERS && !patch(b, p + 8, p + s, delta)) return false
            }
            p += s
        }
        return true
    }

    // ------------------------------------------------------------ box builders

    private fun udta(title: String, artist: String, cover: ByteArray?): ByteArray {
        val hdlr = box(
            "hdlr",
            int(0) + int(0) + "mdir".toByteArray(Charsets.ISO_8859_1) + "appl".toByteArray(Charsets.ISO_8859_1) +
                ByteArray(8) + ByteArray(2)
        )
        val items = ByteArrayOutputStream()
        if (title.isNotBlank()) items.write(box("©nam", data(1, title.take(250).toByteArray(Charsets.UTF_8))))
        if (artist.isNotBlank()) items.write(box("©ART", data(1, artist.take(250).toByteArray(Charsets.UTF_8))))
        items.write(box("©too", data(1, "TubeVault".toByteArray(Charsets.UTF_8))))
        if (cover != null && cover.isNotEmpty()) items.write(box("covr", data(13, cover)))
        val meta = box("meta", int(0) + hdlr + box("ilst", items.toByteArray()))
        return box("udta", meta)
    }

    private fun data(type: Int, payload: ByteArray) = box("data", int(type) + int(0) + payload)

    private fun box(type: String, payload: ByteArray): ByteArray {
        val out = ByteArray(8 + payload.size)
        putU32(out, 0, out.size.toLong())
        type.toByteArray(Charsets.ISO_8859_1).copyInto(out, 4)
        payload.copyInto(out, 8)
        return out
    }

    private fun int(v: Int) = byteArrayOf((v ushr 24).toByte(), (v ushr 16).toByte(), (v ushr 8).toByte(), v.toByte())

    private fun u32(b: ByteArray, p: Int): Long =
        ((b[p].toLong() and 0xff) shl 24) or ((b[p + 1].toLong() and 0xff) shl 16) or
            ((b[p + 2].toLong() and 0xff) shl 8) or (b[p + 3].toLong() and 0xff)

    private fun u64(b: ByteArray, p: Int): Long = (u32(b, p) shl 32) or u32(b, p + 4)

    private fun putU32(b: ByteArray, p: Int, v: Long) {
        b[p] = (v ushr 24).toByte(); b[p + 1] = (v ushr 16).toByte(); b[p + 2] = (v ushr 8).toByte(); b[p + 3] = v.toByte()
    }

    private fun putU64(b: ByteArray, p: Int, v: Long) {
        putU32(b, p, v ushr 32); putU32(b, p + 4, v and 0xffffffffL)
    }

    private fun copy(raf: RandomAccessFile, from: Long, count: Long, out: OutputStream) {
        if (count <= 0) return
        raf.seek(from)
        val buf = ByteArray(256 * 1024)
        var left = count
        while (left > 0) {
            val n = raf.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
            if (n < 0) break
            out.write(buf, 0, n)
            left -= n
        }
    }
}
