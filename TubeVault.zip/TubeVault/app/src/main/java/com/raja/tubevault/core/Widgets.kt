package com.raja.tubevault.core

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.view.View
import android.widget.RemoteViews
import com.raja.tubevault.MainActivity
import com.raja.tubevault.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

/** Home-screen widgets: Music player, Paste & download, Downloads status. */
object WidgetUi {
    const val ACTION_PASTE = "com.raja.tubevault.PASTE"
    const val ACT_PLAY = "com.raja.tubevault.W_PLAY"
    const val ACT_NEXT = "com.raja.tubevault.W_NEXT"
    const val ACT_PREV = "com.raja.tubevault.W_PREV"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var started = false
    private var artKey: String? = null
    private var artBmp: Bitmap? = null

    /** Called once from Application.onCreate: keeps the Downloads widget fresh. */
    fun start(ctx: Context) {
        if (started) return
        started = true
        val app = ctx.applicationContext
        scope.launch {
            Downloads.items.collect {
                try {
                    refreshDownloads(app, sync = true)
                } catch (_: Throwable) {
                }
                delay(1500)
            }
        }
    }

    private fun ids(ctx: Context, cls: Class<*>): IntArray =
        try {
            AppWidgetManager.getInstance(ctx).getAppWidgetIds(ComponentName(ctx, cls))
        } catch (_: Throwable) {
            IntArray(0)
        }

    private fun openApp(ctx: Context, action: String?, code: Int): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        if (action != null) i.action = action
        return PendingIntent.getActivity(ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun broadcast(ctx: Context, action: String, code: Int): PendingIntent {
        val i = Intent(ctx, MusicWidget::class.java).setAction(action)
        return PendingIntent.getBroadcast(ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    // ------------------------------------------------------------ paste widget

    fun buildPaste(ctx: Context): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_paste)
        rv.setOnClickPendingIntent(R.id.w_paste_root, openApp(ctx, ACTION_PASTE, 11))
        return rv
    }

    fun refreshPaste(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val all = ids(ctx, PasteWidget::class.java)
        if (all.isNotEmpty()) mgr.updateAppWidget(all, buildPaste(ctx))
    }

    // ------------------------------------------------------------ music widget

    private fun loadArt(ctx: Context, thumb: String?, network: Boolean): Bitmap? {
        if (thumb == null) return null
        if (thumb == artKey && artBmp != null) return artBmp
        var bmp: Bitmap? = null
        try {
            if (thumb.startsWith("file://")) {
                val path = Uri.parse(thumb).path
                if (path != null && File(path).exists()) {
                    val o = BitmapFactory.Options().apply { inSampleSize = 4 }
                    bmp = BitmapFactory.decodeFile(path, o)
                }
            } else if (thumb.startsWith("http") && network) {
                val bytes = Thumbs.download(thumb)
                if (bytes != null) {
                    val o = BitmapFactory.Options().apply { inSampleSize = 2 }
                    bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                }
            }
        } catch (_: Throwable) {
        }
        if (bmp != null) {
            val scaled = Bitmap.createScaledBitmap(bmp, 200, 200, true)
            artKey = thumb
            artBmp = scaled
            return scaled
        }
        return null
    }

    fun buildMusic(ctx: Context, network: Boolean): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_music)
        val cur = PlayerHub.current
        val playing = PlayerHub.isPlaying
        if (cur == null) {
            rv.setTextViewText(R.id.w_title, "Nothing playing")
            rv.setTextViewText(R.id.w_artist, "Tap to open TubeVault")
            rv.setImageViewResource(R.id.w_art, R.drawable.ic_widget_music)
            rv.setViewPadding(R.id.w_art, 56, 56, 56, 56)
        } else {
            val secret = cur.place == Place.VAULT
            rv.setTextViewText(R.id.w_title, if (secret) "Private media" else cur.title)
            rv.setTextViewText(R.id.w_artist, if (secret) "TubeVault" else cur.uploader.ifEmpty { "TubeVault" })
            val bmp = if (secret) null else loadArt(ctx, cur.thumbnail, network)
            if (bmp != null) {
                rv.setImageViewBitmap(R.id.w_art, bmp)
                rv.setViewPadding(R.id.w_art, 0, 0, 0, 0)
            } else {
                rv.setImageViewResource(R.id.w_art, R.drawable.ic_widget_music)
                rv.setViewPadding(R.id.w_art, 56, 56, 56, 56)
            }
        }
        rv.setImageViewResource(R.id.w_play, if (playing) R.drawable.ic_isl_pause else R.drawable.ic_isl_play)
        rv.setOnClickPendingIntent(R.id.w_play, broadcast(ctx, ACT_PLAY, 21))
        rv.setOnClickPendingIntent(R.id.w_next, broadcast(ctx, ACT_NEXT, 22))
        rv.setOnClickPendingIntent(R.id.w_prev, broadcast(ctx, ACT_PREV, 23))
        rv.setOnClickPendingIntent(R.id.w_music_root, openApp(ctx, null, 24))
        return rv
    }

    /** Called when the song / play state changes. */
    fun refreshMusic(ctx: Context) {
        val app = ctx.applicationContext
        if (ids(app, MusicWidget::class.java).isEmpty()) return
        scope.launch {
            try {
                val mgr = AppWidgetManager.getInstance(app)
                val all = ids(app, MusicWidget::class.java)
                if (all.isNotEmpty()) mgr.updateAppWidget(all, buildMusic(app, true))
            } catch (_: Throwable) {
            }
        }
    }

    // ------------------------------------------------------------ downloads widget

    fun buildDownloads(ctx: Context): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_downloads)
        val list = Downloads.items.value
        val active = list.filter { it.status in Downloads.ACTIVE }
        val done = list.count { it.status == Status.DONE }
        if (active.isEmpty()) {
            rv.setTextViewText(R.id.w_dl_title, "TubeVault")
            rv.setTextViewText(R.id.w_dl_sub, if (done == 0) "Nothing downloading" else "$done saved in your Library")
            rv.setViewVisibility(R.id.w_dl_bar, View.GONE)
        } else {
            val known = active.filter { it.progress >= 0f }
            val avg = if (known.isEmpty()) 0f else known.map { it.progress }.average().toFloat()
            rv.setTextViewText(R.id.w_dl_title, if (active.size == 1) "Downloading" else "Downloading ${active.size} files")
            rv.setTextViewText(R.id.w_dl_sub, active.first().title)
            rv.setViewVisibility(R.id.w_dl_bar, View.VISIBLE)
            rv.setProgressBar(R.id.w_dl_bar, 100, (avg * 100).toInt().coerceIn(0, 100), known.isEmpty())
        }
        rv.setOnClickPendingIntent(R.id.w_dl_root, openApp(ctx, null, 31))
        return rv
    }

    fun refreshDownloads(ctx: Context, sync: Boolean) {
        val all = ids(ctx, DownloadsWidget::class.java)
        if (all.isEmpty()) return
        AppWidgetManager.getInstance(ctx).updateAppWidget(all, buildDownloads(ctx))
    }
}

class PasteWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetManager.updateAppWidget(appWidgetIds, WidgetUi.buildPaste(context))
    }
}

class DownloadsWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetManager.updateAppWidget(appWidgetIds, WidgetUi.buildDownloads(context))
    }
}

class MusicWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetManager.updateAppWidget(appWidgetIds, WidgetUi.buildMusic(context, false))
        WidgetUi.refreshMusic(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            WidgetUi.ACT_PLAY -> if (PlayerHub.queue.isNotEmpty()) PlayerHub.playPause(context)
            WidgetUi.ACT_NEXT -> if (PlayerHub.queue.isNotEmpty()) PlayerHub.next(context)
            WidgetUi.ACT_PREV -> if (PlayerHub.queue.isNotEmpty()) PlayerHub.previous(context)
            else -> return
        }
        WidgetUi.refreshMusic(context)
    }
}
