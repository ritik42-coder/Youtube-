package com.raja.tubevault.core

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Cutting songs: waveform, lossless trim, trim with fades, saving and ringtones. */
object ClipTools {
    const val BARS = 220
    private const val MAX_FADE_CLIP_MS = 8 * 60_000L

    /** Peaks 0..1 for the waveform view + the real duration in ms. */
    suspend fun waveform(ctx: Context, uri: Uri, onProgress: (Float) -> Unit): Pair<FloatArray, Long> {
        val pcm = AudioDecoder.decode16kMono(ctx, uri, onProgress)
        val durMs = pcm.size * 1000L / AudioDecoder.TARGET_RATE
        val peaks = FloatArray(BARS)
        val per = max(1, pcm.size / BARS)
        var top = 0.0001f
        for (b in 0 until BARS) {
            val from = b * per
            val to = min(pcm.size, from + per)
            var m = 0f
            var i = from
            while (i < to) {
                val a = abs(pcm[i])
                if (a > m) m = a
                i++
            }
            peaks[b] = m
            if (m > top) top = m
        }
        for (b in 0 until BARS) peaks[b] = (peaks[b] / top).coerceIn(0f, 1f)
        return Pair(peaks, durMs)
    }

    private fun findAudio(ex: MediaExtractor): Pair<Int, MediaFormat> {
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) return Pair(i, f)
        }
        throw IOException("No audio found in this file")
    }

    /**
     * Cuts [startMs]..[endMs] into an .m4a file. Without fades and for AAC songs the audio is copied
     * untouched (instant, no quality loss). With fades, or for other formats, it is re-encoded to AAC.
     */
    suspend fun trim(
        ctx: Context, uri: Uri, startMs: Long, endMs: Long,
        fadeInMs: Long, fadeOutMs: Long, out: File
    ) = withContext(Dispatchers.IO) {
        if (endMs - startMs < 500L) throw IOException("Pick at least half a second")
        val probe = MediaExtractor()
        var isAac = false
        try {
            probe.setDataSource(ctx, uri, null)
            val (_, f) = findAudio(probe)
            isAac = (f.getString(MediaFormat.KEY_MIME) ?: "") == MediaFormat.MIMETYPE_AUDIO_AAC
        } finally {
            probe.release()
        }
        if (out.exists()) out.delete()
        if (isAac && fadeInMs <= 0L && fadeOutMs <= 0L) copyTrim(ctx, uri, startMs, endMs, out)
        else {
            if (endMs - startMs > MAX_FADE_CLIP_MS) {
                throw IOException("For fades or this file type, pick a part up to 8 minutes long")
            }
            reencode(ctx, uri, startMs, endMs, fadeInMs, fadeOutMs, out)
        }
    }

    private suspend fun copyTrim(ctx: Context, uri: Uri, startMs: Long, endMs: Long, out: File) {
        val job = currentCoroutineContext()
        val ex = MediaExtractor()
        var muxer: MediaMuxer? = null
        var started = false
        try {
            ex.setDataSource(ctx, uri, null)
            val (track, fmt) = findAudio(ex)
            ex.selectTrack(track)
            val m = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = m
            val idx = m.addTrack(fmt)
            m.start()
            started = true
            val startUs = startMs * 1000L
            val endUs = endMs * 1000L
            ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val buf = ByteBuffer.allocateDirect(1024 * 1024)
            val info = MediaCodec.BufferInfo()
            var base = -1L
            while (true) {
                job.ensureActive()
                val t = ex.sampleTime
                if (t < 0L || t > endUs) break
                buf.clear()
                val size = ex.readSampleData(buf, 0)
                if (size < 0) break
                if (base < 0L) base = t
                info.set(0, size, t - base, MediaCodec.BUFFER_FLAG_KEY_FRAME)
                m.writeSampleData(idx, buf, info)
                ex.advance()
            }
            m.stop()
            started = false
        } finally {
            try {
                if (started) muxer?.stop()
            } catch (_: Throwable) {
            }
            try {
                muxer?.release()
            } catch (_: Throwable) {
            }
            ex.release()
        }
    }

    private suspend fun reencode(
        ctx: Context, uri: Uri, startMs: Long, endMs: Long,
        fadeInMs: Long, fadeOutMs: Long, out: File
    ) {
        val job = currentCoroutineContext()
        val startUs = startMs * 1000L
        val endUs = endMs * 1000L

        // ---------------- 1) decode the wanted part to 16-bit PCM
        var rate = 44100
        var ch = 2
        var pcm = ShortArray(44100 * 2 * 20)
        var total = 0

        val ex = MediaExtractor()
        var dec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, uri, null)
            val (track, fmt) = findAudio(ex)
            ex.selectTrack(track)
            if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val d = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            dec = d
            d.configure(fmt, null, null, 0)
            d.start()
            ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            while (!outDone) {
                job.ensureActive()
                if (!inDone) {
                    val ii = d.dequeueInputBuffer(5_000)
                    if (ii >= 0) {
                        val b = d.getInputBuffer(ii)!!
                        val t = ex.sampleTime
                        val n = if (t < 0L || t > endUs + 200_000L) -1 else ex.readSampleData(b, 0)
                        if (n < 0) {
                            d.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            d.queueInputBuffer(ii, 0, n, t, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = d.dequeueOutputBuffer(info, 5_000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = d.outputFormat
                    if (nf.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (nf.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                } else if (oi >= 0) {
                    if (info.size > 0) {
                        val ob = d.getOutputBuffer(oi)!!
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        ob.order(ByteOrder.nativeOrder())
                        val sb = ob.asShortBuffer()
                        val frames = sb.remaining() / max(1, ch)
                        val pts = info.presentationTimeUs
                        val skip = max(0L, (startUs - pts) * rate / 1_000_000L).toInt()
                        val limit = min(frames.toLong(), (endUs - pts) * rate / 1_000_000L).toInt()
                        if (limit > skip) {
                            val keep = (limit - skip) * ch
                            if (total + keep > pcm.size) pcm = pcm.copyOf(max(pcm.size * 2, total + keep))
                            sb.position(skip * ch)
                            sb.get(pcm, total, keep)
                            total += keep
                        }
                    }
                    d.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                }
            }
        } finally {
            try {
                dec?.stop()
            } catch (_: Throwable) {
            }
            try {
                dec?.release()
            } catch (_: Throwable) {
            }
            ex.release()
        }
        val frames = total / max(1, ch)
        if (frames < rate / 4) throw IOException("The selected part is too short")

        // ---------------- 2) fades
        val fi = (fadeInMs * rate / 1000L).toInt().coerceIn(0, frames)
        val fo = (fadeOutMs * rate / 1000L).toInt().coerceIn(0, frames)
        if (fi > 0) {
            for (f in 0 until fi) {
                val g = f.toFloat() / fi
                for (c in 0 until ch) {
                    val k = f * ch + c
                    pcm[k] = (pcm[k] * g).toInt().toShort()
                }
            }
        }
        if (fo > 0) {
            for (f in 0 until fo) {
                val g = f.toFloat() / fo
                val frame = frames - 1 - f
                for (c in 0 until ch) {
                    val k = frame * ch + c
                    pcm[k] = (pcm[k] * g).toInt().toShort()
                }
            }
        }

        // ---------------- 3) encode to AAC (.m4a)
        val encFmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, ch)
        encFmt.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
        encFmt.setInteger(MediaFormat.KEY_BIT_RATE, 192_000)
        encFmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16 * 1024)
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        var muxer: MediaMuxer? = null
        var started = false
        try {
            enc.configure(encFmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            enc.start()
            val m = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = m
            var track = -1
            val info = MediaCodec.BufferInfo()
            var pos = 0
            val totalShorts = frames * ch
            var inDone = false
            var outDone = false
            while (!outDone) {
                job.ensureActive()
                if (!inDone) {
                    val ii = enc.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val b = enc.getInputBuffer(ii)!!
                        b.clear()
                        b.order(ByteOrder.nativeOrder())
                        val capShorts = b.capacity() / 2
                        val take = min(capShorts - capShorts % ch, totalShorts - pos)
                        val pts = (pos / ch).toLong() * 1_000_000L / rate
                        if (take <= 0) {
                            enc.queueInputBuffer(ii, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            b.asShortBuffer().put(pcm, pos, take)
                            enc.queueInputBuffer(ii, 0, take * 2, pts, 0)
                            pos += take
                        }
                    }
                }
                val oi = enc.dequeueOutputBuffer(info, 10_000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = m.addTrack(enc.outputFormat)
                    m.start()
                    started = true
                } else if (oi >= 0) {
                    val ob = enc.getOutputBuffer(oi)!!
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (info.size > 0 && started) {
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        m.writeSampleData(track, ob, info)
                    }
                    enc.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                }
            }
            if (started) {
                m.stop()
                started = false
            }
        } finally {
            try {
                if (started) muxer?.stop()
            } catch (_: Throwable) {
            }
            try {
                muxer?.release()
            } catch (_: Throwable) {
            }
            try {
                enc.stop()
            } catch (_: Throwable) {
            }
            try {
                enc.release()
            } catch (_: Throwable) {
            }
        }
    }

    // ------------------------------------------------------------------ ringtones

    /** Ringtone kinds: 0 = phone ringtone, 1 = notification, 2 = alarm */
    @Suppress("DEPRECATION")
    fun saveToSystemSounds(ctx: Context, file: File, title: String, kind: Int): Uri {
        val dirName = when (kind) {
            1 -> Environment.DIRECTORY_NOTIFICATIONS
            2 -> Environment.DIRECTORY_ALARMS
            else -> Environment.DIRECTORY_RINGTONES
        }
        val fileName = MediaSaver.sanitize(title) + ".m4a"
        val cr = ctx.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.TITLE, title)
            put(MediaStore.MediaColumns.MIME_TYPE, "audio/mp4")
            put(MediaStore.Audio.Media.IS_RINGTONE, kind == 0)
            put(MediaStore.Audio.Media.IS_NOTIFICATION, kind == 1)
            put(MediaStore.Audio.Media.IS_ALARM, kind == 2)
            put(MediaStore.Audio.Media.IS_MUSIC, false)
        }
        if (Build.VERSION.SDK_INT >= 29) {
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, dirName)
            values.put(MediaStore.MediaColumns.IS_PENDING, 1)
            val coll = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val uri = cr.insert(coll, values) ?: throw IOException("Couldn't create the ringtone file")
            try {
                val os = cr.openOutputStream(uri) ?: throw IOException("Couldn't open the ringtone file")
                os.use { o -> file.inputStream().use { it.copyTo(o, 256 * 1024) } }
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                cr.update(uri, done, null, null)
                return uri
            } catch (e: Exception) {
                try {
                    cr.delete(uri, null, null)
                } catch (_: Exception) {
                }
                throw e
            }
        } else {
            val dir = Environment.getExternalStoragePublicDirectory(dirName)
            if (!dir.exists() && !dir.mkdirs()) throw IOException("Couldn't create the ringtones folder")
            var target = File(dir, fileName)
            var i = 1
            while (target.exists()) {
                target = File(dir, MediaSaver.sanitize(title) + " ($i).m4a")
                i++
            }
            file.copyTo(target)
            values.put(MediaStore.MediaColumns.DATA, target.absolutePath)
            return cr.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values) ?: Uri.fromFile(target)
        }
    }

    fun canWriteSettings(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 23 || android.provider.Settings.System.canWrite(ctx)

    fun setDefault(ctx: Context, uri: Uri, kind: Int) {
        val type = when (kind) {
            1 -> RingtoneManager.TYPE_NOTIFICATION
            2 -> RingtoneManager.TYPE_ALARM
            else -> RingtoneManager.TYPE_RINGTONE
        }
        RingtoneManager.setActualDefaultRingtoneUri(ctx, type, uri)
    }
}
