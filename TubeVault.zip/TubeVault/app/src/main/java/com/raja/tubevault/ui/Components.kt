package com.raja.tubevault.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** Slowly drifting aurora blobs behind everything. */
@Composable
fun AuroraBackground() {
    val t = rememberInfiniteTransition(label = "aurora")
    val a = t.animateFloat(
        0f, 1f, infiniteRepeatable(tween(15000, easing = LinearEasing), RepeatMode.Reverse), label = "a"
    )
    val b = t.animateFloat(
        1f, 0f, infiniteRepeatable(tween(21000, easing = LinearEasing), RepeatMode.Reverse), label = "b"
    )
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Bg)
        val w = size.width
        val h = size.height
        blob(Violet.copy(alpha = 0.32f), w * (0.10f + 0.70f * a.value), h * (0.08f + 0.22f * b.value), w * 0.95f)
        blob(Pink.copy(alpha = 0.22f), w * (0.95f - 0.75f * b.value), h * (0.55f + 0.20f * a.value), w * 0.85f)
        blob(Orange.copy(alpha = 0.14f), w * (0.15f + 0.5f * b.value), h * (0.95f - 0.25f * a.value), w * 0.8f)
    }
}

private fun DrawScope.blob(color: Color, cx: Float, cy: Float, r: Float) {
    val c = Offset(cx, cy)
    drawCircle(
        brush = Brush.radialGradient(listOf(color, Color.Transparent), center = c, radius = r),
        radius = r,
        center = c
    )
}

/** Fade + slide-up entrance, staggered by [index]. */
@Composable
fun Staggered(index: Int, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(index * 80L)
        shown = true
    }
    val alpha by animateFloatAsState(if (shown) 1f else 0f, tween(520), label = "alpha")
    val y by animateFloatAsState(if (shown) 0f else 48f, tween(650, easing = FastOutSlowInEasing), label = "y")
    Box(modifier.graphicsLayer {
        this.alpha = alpha
        translationY = y
    }) { content() }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    corner: Dp = 24.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(corner)
    Column(
        modifier
            .clip(shape)
            .background(Glass)
            .border(BorderStroke(1.dp, GlassBorder), shape),
        content = content
    )
}

/** Springy press-scale + click without ripple. */
fun Modifier.pressable(onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) 0.93f else 1f,
        spring(dampingRatio = 0.45f, stiffness = Spring.StiffnessMedium),
        label = "press"
    )
    this
        .scale(s)
        .clickable(interactionSource = src, indication = null, onClick = onClick)
}

@Composable
fun GradientButton(text: String, loading: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .fillMaxWidth()
            .height(56.dp)
            .pressable { if (!loading) onClick() }
            .clip(RoundedCornerShape(20.dp))
            .background(AccentBrush2),
        contentAlignment = Alignment.Center
    ) {
        if (loading) {
            CircularProgressIndicator(
                modifier = Modifier.size(24.dp),
                color = Color.White,
                strokeWidth = 2.5.dp
            )
        } else {
            Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

@Composable
fun PillButton(icon: ImageVector, text: String, filled: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Row(
        Modifier
            .pressable(onClick)
            .clip(shape)
            .then(if (filled) Modifier.background(AccentBrush) else Modifier.background(Glass))
            .border(BorderStroke(1.dp, if (filled) Color.Transparent else GlassBorder), shape)
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(16.dp))
        Text(text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Sliding two/three-way tab switch. */
@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    BoxWithConstraints(
        Modifier
            .fillMaxWidth()
            .height(48.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Glass)
    ) {
        val w = maxWidth / options.size
        val x by animateDpAsState(
            w * selected,
            spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMedium),
            label = "seg"
        )
        Box(
            Modifier
                .offset(x = x)
                .width(w)
                .fillMaxHeight()
                .padding(4.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(AccentBrush)
        )
        Row(Modifier.fillMaxSize()) {
            options.forEachIndexed { i, label ->
                val src = remember { MutableInteractionSource() }
                val c by animateColorAsState(if (selected == i) Color.White else TextLo, label = "segc")
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(interactionSource = src, indication = null) { onSelect(i) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(label, color = c, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                }
            }
        }
    }
}

/** progress < 0 -> indeterminate sweep. */
@Composable
fun GradientProgress(progress: Float, modifier: Modifier = Modifier) {
    val p by animateFloatAsState(progress.coerceIn(0f, 1f), tween(350), label = "prog")
    val t = rememberInfiniteTransition(label = "ind")
    val shift = t.animateFloat(0f, 1f, infiniteRepeatable(tween(1200, easing = LinearEasing)), label = "shift")
    BoxWithConstraints(
        modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0x22FFFFFF))
    ) {
        if (progress < 0f) {
            val wpx = with(LocalDensity.current) { maxWidth.toPx() }
            Box(
                Modifier
                    .fillMaxHeight()
                    .width(maxWidth * 0.35f)
                    .graphicsLayer { translationX = shift.value * wpx * 1.35f - wpx * 0.35f }
                    .clip(RoundedCornerShape(4.dp))
                    .background(AccentBrush)
            )
        } else {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(p)
                    .clip(RoundedCornerShape(4.dp))
                    .background(AccentBrush)
            )
        }
    }
}

@Composable
fun shimmerBrush(): Brush {
    val t = rememberInfiniteTransition(label = "shimmer")
    val x by t.animateFloat(0f, 1400f, infiniteRepeatable(tween(1300, easing = LinearEasing)), label = "x")
    return Brush.linearGradient(
        listOf(Color(0x10FFFFFF), Color(0x33FFFFFF), Color(0x10FFFFFF)),
        start = Offset(x - 400f, 0f),
        end = Offset(x, 200f)
    )
}

@Composable
fun AppLogo(size: Dp = 46.dp) {
    val t = rememberInfiniteTransition(label = "logo")
    val s = t.animateFloat(
        1f, 1.12f, infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "s"
    )
    Box(contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .size(size)
                .graphicsLayer {
                    scaleX = s.value
                    scaleY = s.value
                    alpha = 0.35f
                }
                .clip(RoundedCornerShape(16.dp))
                .background(AccentBrush2)
        )
        Box(
            Modifier
                .size(size)
                .clip(RoundedCornerShape(16.dp))
                .background(AccentBrush2),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.Download, null, tint = Color.White, modifier = Modifier.size(size * 0.58f))
        }
    }
}

/** Floating glass navigation pill with an expanding selected item. */
@Composable
fun BottomBar(page: Int, activeCount: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(34.dp)
    Row(
        modifier
            .clip(shape)
            .background(Color(0xE60F0F18))
            .border(BorderStroke(1.dp, GlassBorder), shape)
            .padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        NavItem(
            icon = Icons.Rounded.Home,
            label = "Home", selected = page == 0, badge = 0
        ) { onSelect(0) }
        NavItem(
            icon = Icons.Rounded.Download,
            label = "Library", selected = page == 1, badge = activeCount
        ) { onSelect(1) }
    }
}

@Composable
private fun NavItem(icon: ImageVector, label: String, selected: Boolean, badge: Int, onClick: () -> Unit) {
    val w by animateDpAsState(
        if (selected) 136.dp else 58.dp,
        spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMediumLow),
        label = "navw"
    )
    val bgAlpha by animateFloatAsState(if (selected) 1f else 0f, tween(300), label = "navbg")
    val tint by animateColorAsState(if (selected) Color.White else TextLo, label = "navtint")
    Row(
        Modifier
            .width(w)
            .height(52.dp)
            .pressable(onClick)
            .clip(CircleShape)
            .background(AccentBrush2, CircleShape, bgAlpha),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (badge > 0) {
            BadgedBox(badge = { Badge { Text("$badge") } }) {
                Icon(icon, null, tint = tint)
            }
        } else {
            Icon(icon, null, tint = tint)
        }
        AnimatedVisibility(
            visible = selected,
            enter = fadeIn(tween(250)) + expandHorizontally(tween(300)),
            exit = fadeOut(tween(120)) + shrinkHorizontally(tween(200))
        ) {
            Text(
                label,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                modifier = Modifier.padding(start = 8.dp)
            )
        }
    }
}
