package com.raja.tubevault.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Animated gradient heading whose colours flow across the letters. */
@Composable
fun ShimmerTitle(text: String, size: TextUnit = 30.sp) {
    val t = rememberInfiniteTransition(label = "title")
    val x by t.animateFloat(0f, 1f, infiniteRepeatable(tween(4200, easing = LinearEasing)), label = "tx")
    val brush = Brush.linearGradient(
        colors = listOf(Pink, Orange, Violet, Pink),
        start = Offset(x * 500f, 0f),
        end = Offset(x * 500f + 500f, 0f),
        tileMode = TileMode.Mirror
    )
    Text(text, style = TextStyle(brush = brush, fontSize = size, fontWeight = FontWeight.Black))
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    corner: Dp = 24.dp,
    borderColor: Color = GlassBorder,
    borderWidth: Dp = 1.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(corner)
    Column(
        modifier
            .clip(shape)
            .background(Glass)
            .border(BorderStroke(borderWidth, borderColor), shape),
        content = content
    )
}

/** Fade + slide-up entrance, staggered by [index]. */
@Composable
fun Staggered(index: Int, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(index * 80L)
        shown = true
    }
    val alpha by animateFloatAsState(if (shown) 1f else 0f, tween(520), label = "alpha")
    val y by animateFloatAsState(if (shown) 0f else 48f, tween(650, easing = FastOutSlowInEasing), label = "y")
    Box(modifier.graphicsLayer {
        this.alpha = alpha
        translationY = y
    }) { content() }
}

/** Springy press-scale + click without ripple. */
fun Modifier.pressable(onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) 0.93f else 1f,
        spring(dampingRatio = 0.45f, stiffness = Spring.StiffnessMedium),
        label = "press"
    )
    this
        .scale(s)
        .clickable(interactionSource = src, indication = null, onClick = onClick)
}

@Composable
fun GradientButton(text: String, loading: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "shine")
    val v by t.animateFloat(0f, 1f, infiniteRepeatable(tween(3200, easing = LinearEasing)), label = "v")
    Box(
        modifier
            .fillMaxWidth()
            .height(56.dp)
            .pressable { if (!loading) onClick() }
            .clip(RoundedCornerShape(20.dp))
            .background(AccentBrush2)
            .drawWithContent {
                drawContent()
                if (!loading && v < 0.45f) {
                    val k = v / 0.45f
                    val x = (k * 1.6f - 0.3f) * size.width
                    drawRect(
                        Brush.linearGradient(
                            listOf(Color.Transparent, Color.White.copy(alpha = 0.35f), Color.Transparent),
                            start = Offset(x, 0f),
                            end = Offset(x + size.height * 1.2f, size.height)
                        )
                    )
                }
            },
        contentAlignment = Alignment.Center
    ) {
        if (loading) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CircularProgressIndicator(
                    modifier = Modifier.size(22.dp),
                    color = Color.White,
                    strokeWidth = 2.5.dp
                )
                Text("Analyzing link…", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        } else {
            Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

@Composable
fun PillButton(icon: ImageVector, text: String, filled: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Row(
        Modifier
            .pressable(onClick)
            .clip(shape)
            .then(if (filled) Modifier.background(AccentBrush) else Modifier.background(Glass))
            .border(BorderStroke(1.dp, if (filled) Color.Transparent else GlassBorder), shape)
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(16.dp))
        Text(text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Sliding two/three-way tab switch. */
@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    BoxWithConstraints(
        Modifier
            .fillMaxWidth()
            .height(48.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Glass)
    ) {
        val w = maxWidth / options.size
        val x by animateDpAsState(
            w * selected,
            spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMedium),
            label = "seg"
        )
        Box(
            Modifier
                .offset(x = x)
                .width(w)
                .fillMaxHeight()
                .padding(4.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(AccentBrush)
        )
        Row(Modifier.fillMaxSize()) {
            options.forEachIndexed { i, label ->
                val src = remember { MutableInteractionSource() }
                val c by animateColorAsState(if (selected == i) Color.White else TextLo, label = "segc")
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(interactionSource = src, indication = null) { onSelect(i) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(label, color = c, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                }
            }
        }
    }
}

/** Liquid progress bar with a moving shine and a glowing head. progress < 0 -> comet sweep. */
@Composable
fun GradientProgress(progress: Float, modifier: Modifier = Modifier) {
    val p by animateFloatAsState(progress.coerceIn(0f, 1f), tween(350), label = "prog")
    val t = rememberInfiniteTransition(label = "ind")
    val shift by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1300, easing = LinearEasing)), label = "shift")
    Canvas(
        modifier
            .fillMaxWidth()
            .height(16.dp)
    ) {
        val w = size.width
        val bar = 8.dp.toPx()
        val top = (size.height - bar) / 2f
        val cr = CornerRadius(bar / 2f, bar / 2f)
        drawRoundRect(Color(0x22FFFFFF), Offset(0f, top), Size(w, bar), cr)
        if (progress < 0f) {
            val cw = w * 0.35f
            val x = shift * (w + cw) - cw
            clipRect(0f, top, w, top + bar) {
                drawRoundRect(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, Pink, Orange, Color.Transparent),
                        startX = x, endX = x + cw
                    ),
                    Offset(x, top), Size(cw, bar), cr
                )
            }
        } else {
            val fw = (w * p).coerceAtLeast(bar)
            drawRoundRect(
                Brush.horizontalGradient(listOf(Violet, Pink, Orange), startX = 0f, endX = w),
                Offset(0f, top), Size(fw, bar), cr
            )
            clipRect(0f, top, fw, top + bar) {
                val sx = shift * (fw + 120.dp.toPx()) - 120.dp.toPx()
                drawRect(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, Color.White.copy(alpha = 0.55f), Color.Transparent),
                        startX = sx, endX = sx + 120.dp.toPx()
                    ),
                    Offset(0f, top), Size(fw, bar)
                )
            }
            if (p > 0.005f && p < 0.999f) {
                val hc = Offset(fw - bar / 2f, top + bar / 2f)
                val gr = 14.dp.toPx()
                drawCircle(
                    Brush.radialGradient(listOf(Orange.copy(alpha = 0.85f), Color.Transparent), center = hc, radius = gr),
                    radius = gr, center = hc
                )
                drawCircle(Color.White, 2.5.dp.toPx(), hc)
            }
        }
    }
}

@Composable
fun shimmerBrush(): Brush {
    val t = rememberInfiniteTransition(label = "shimmer")
    val x by t.animateFloat(0f, 1400f, infiniteRepeatable(tween(1300, easing = LinearEasing)), label = "x")
    return Brush.linearGradient(
        listOf(Color(0x10FFFFFF), Color(0x33FFFFFF), Color(0x10FFFFFF)),
        start = Offset(x - 400f, 0f),
        end = Offset(x, 200f)
    )
}

/** Logo tile with a breathing glow, an orbiting light and a bobbing arrow. */
@Composable
fun AppLogo(size: Dp = 46.dp) {
    val t = rememberInfiniteTransition(label = "logo")
    val s by t.animateFloat(
        1f, 1.12f, infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "s"
    )
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(3200, easing = LinearEasing)), label = "spin")
    val bob by t.animateFloat(
        -1f, 1f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bob"
    )
    Box(Modifier.size(size + 12.dp), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .size(size)
                .graphicsLayer {
                    scaleX = s
                    scaleY = s
                    alpha = 0.35f
                }
                .clip(RoundedCornerShape(16.dp))
                .background(AccentBrush2)
        )
        Canvas(Modifier.fillMaxSize()) {
            val sw = 2.dp.toPx()
            rotate(spin, center) {
                drawArc(
                    brush = Brush.sweepGradient(0f to Color.Transparent, 0.6f to Pink, 1f to Orange, center = center),
                    startAngle = 0f, sweepAngle = 300f, useCenter = false,
                    topLeft = Offset(sw, sw), size = Size(this.size.width - sw * 2, this.size.height - sw * 2),
                    style = Stroke(sw, cap = StrokeCap.Round)
                )
            }
        }
        Box(
            Modifier
                .size(size)
                .clip(RoundedCornerShape(16.dp))
                .background(AccentBrush2),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Rounded.Download, null, tint = Color.White,
                modifier = Modifier
                    .size(size * 0.58f)
                    .graphicsLayer { translationY = bob * 2.5f * density }
            )
        }
    }
}

/** Floating glass navigation pill with an expanding selected item. */
@Composable
fun BottomBar(
    page: Int,
    activeCount: Int,
    bump: Int,
    onLibraryPos: (Offset) -> Unit,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(34.dp)
    Row(
        modifier
            .clip(shape)
            .background(Color(0xE60F0F18))
            .border(BorderStroke(1.dp, GlassBorder), shape)
            .padding(6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        NavItem(
            icon = Icons.Rounded.Home,
            label = "Home", selected = page == 0, badge = 0, bump = 0, onPos = null
        ) { onSelect(0) }
        NavItem(
            icon = Icons.Rounded.Download,
            label = "Library", selected = page == 1, badge = activeCount, bump = bump, onPos = onLibraryPos
        ) { onSelect(1) }
    }
}

@Composable
private fun NavItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    badge: Int,
    bump: Int,
    onPos: ((Offset) -> Unit)?,
    onClick: () -> Unit
) {
    val w by animateDpAsState(
        if (selected) 136.dp else 58.dp,
        spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMediumLow),
        label = "navw"
    )
    val bgAlpha by animateFloatAsState(if (selected) 1f else 0f, tween(300), label = "navbg")
    val tint by animateColorAsState(if (selected) Color.White else TextLo, label = "navtint")
    val sc = remember { Animatable(1f) }
    LaunchedEffect(bump) {
        if (bump > 0) {
            sc.snapTo(1f)
            sc.animateTo(1.4f, tween(90))
            sc.animateTo(1f, spring(dampingRatio = 0.35f, stiffness = 300f))
        }
    }
    Row(
        Modifier
            .width(w)
            .height(52.dp)
            .onGloballyPositioned { c ->
                if (onPos != null) {
                    val p = c.positionInRoot()
                    onPos(Offset(p.x + c.size.width / 2f, p.y + c.size.height / 2f))
                }
            }
            .pressable(onClick)
            .clip(CircleShape)
            .background(AccentBrush2, CircleShape, bgAlpha),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.graphicsLayer {
            scaleX = sc.value
            scaleY = sc.value
        }) {
            if (badge > 0) {
                BadgedBox(badge = { Badge { Text("$badge") } }) {
                    Icon(icon, null, tint = tint)
                }
            } else {
                Icon(icon, null, tint = tint)
            }
        }
        AnimatedVisibility(
            visible = selected,
            enter = fadeIn(tween(250)) + expandHorizontally(tween(300)),
            exit = fadeOut(tween(120)) + shrinkHorizontally(tween(200))
        ) {
            Text(
                label,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                modifier = Modifier.padding(start = 8.dp)
            )
        }
    }
}
