package com.raja.tubevault.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.raja.tubevault.core.AudioFx
import com.raja.tubevault.core.PlaybackHub
import kotlin.math.sin

/**
 * The "dynamic island" of TubeVault: a floating pill that stays at the top of the
 * app while a song keeps playing after you close the player. It carries the live
 * spectrum of the song, play/pause, and a tap opens the full player again.
 */
@Composable
fun NowPlayingIsland(onOpen: () -> Unit, modifier: Modifier = Modifier) {
    val now = PlaybackHub.now ?: return
    val playing = PlaybackHub.playing
    val ctx = LocalContext.current
    val bands = AudioFx.bands()
    val hasViz = AudioFx.hasVisualizer

    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(playing) {
        while (playing) {
            withFrameNanos { }
            tick++
        }
    }

    val shape = RoundedCornerShape(30.dp)
    Row(
        modifier
            .widthIn(max = 330.dp)
            .clip(shape)
            .background(Color(0xF50B0B14))
            .border(1.dp, GlassBorder, shape)
            .padding(start = 7.dp, end = 7.dp, top = 7.dp, bottom = 7.dp)
            .pressable(onOpen),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            Modifier.size(36.dp).clip(CircleShape).background(Color(0xFF14141E)),
            contentAlignment = Alignment.Center
        ) {
            AsyncImage(
                model = ImageRequest.Builder(ctx).data(now.thumb).crossfade(true).build(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(36.dp).clip(CircleShape)
            )
        }

        Column(Modifier.widthIn(max = 170.dp)) {
            Text(
                now.title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Canvas(Modifier.fillMaxWidth().height(13.dp)) {
                val t = tick
                val n = 20
                val gap = 2.dp.toPx()
                val bw = ((size.width - gap * (n - 1)) / n).coerceAtLeast(1f)
                for (i in 0 until n) {
                    val v = if (hasViz) {
                        bands[(i * AudioFx.BANDS / n).coerceIn(0, AudioFx.BANDS - 1)]
                    } else {
                        (0.30f + 0.35f * sin(t * 0.12f + i * 0.55f)).coerceIn(0.08f, 1f)
                    }
                    val hh = (size.height * (0.18f + 0.82f * v)).coerceAtLeast(2.dp.toPx())
                    drawRoundRect(
                        Brush.verticalGradient(
                            listOf(Orange, Pink),
                            startY = size.height - hh, endY = size.height
                        ),
                        Offset(i * (bw + gap), size.height - hh),
                        Size(bw, hh),
                        CornerRadius(bw / 2f)
                    )
                }
            }
        }

        Spacer(Modifier.weight(1f))

        Box(
            Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(AccentBrush2)
                .pressable { PlaybackHub.toggle() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                null, tint = Color.White, modifier = Modifier.size(20.dp)
            )
        }

        Box(
            Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(Color(0x22FFFFFF))
                .pressable {
                    PlaybackHub.islandHidden = true
                    PlaybackHub.current()?.pause()
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.Close, null, tint = TextLo, modifier = Modifier.size(16.dp))
        }
    }
}
