package com.raja.tubevault.ui

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.runtime.withFrameNanos
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

// ============================================================ small helpers

@Composable
fun rememberHaptics(): (HapticFeedbackType) -> Unit {
    val h = LocalHapticFeedback.current
    return remember(h) {
        { type: HapticFeedbackType -> if (AppSettings.haptics) h.performHapticFeedback(type) }
    }
}

class OffsetRef {
    var value: Offset = Offset.Zero
}

/** Remembers the on-screen centre of a composable without triggering recomposition. */
fun Modifier.trackCenter(ref: OffsetRef): Modifier = this.onGloballyPositioned { c ->
    val p = c.positionInRoot()
    ref.value = Offset(p.x + c.size.width / 2f, p.y + c.size.height / 2f)
}

fun formatEta(sec: Long): String = when {
    sec >= 3600 -> "${sec / 3600}h ${(sec % 3600) / 60}m"
    sec >= 60 -> "${sec / 60}m ${sec % 60}s"
    else -> "${sec}s"
}

private fun smooth(x: Float): Float {
    val v = x.coerceIn(0f, 1f)
    return v * v * (3f - 2f * v)
}

private fun easeOut(x: Float): Float {
    val v = 1f - x.coerceIn(0f, 1f)
    return 1f - v * v * v
}

// ============================================================ live background

private class Particle(
    val x: Float, val y: Float, val speed: Float, val size: Float,
    val depth: Float, val kind: Int, val wob: Float
)

private fun DrawScope.blob(color: Color, cx: Float, cy: Float, r: Float) {
    val c = Offset(cx, cy)
    drawCircle(
        brush = Brush.radialGradient(listOf(color, Color.Transparent), center = c, radius = r),
        radius = r,
        center = c
    )
}

/**
 * Living background: drifting aurora, a rain of "data streams" that speeds up while downloads run,
 * parallax that follows how you tilt the phone, a tint taken from the video you're looking at,
 * and a shock-wave ring whenever a download finishes.
 */
@Composable
fun LiveBackground(activity: Float, tint: Color?, pulse: Int) {
    val ctx = LocalContext.current
    val live = AppSettings.liveBg
    val act by animateFloatAsState(activity, tween(1400), label = "act")
    val mix by animateFloatAsState(if (tint != null) 0.85f else 0f, tween(1200), label = "mix")
    val tintC by animateColorAsState(tint ?: Violet, tween(1400), label = "tint")
    var tx by remember { mutableFloatStateOf(0f) }
    var ty by remember { mutableFloatStateOf(0f) }
    var phase by remember { mutableFloatStateOf(0f) }
    var clock by remember { mutableFloatStateOf(0f) }
    val ring = remember { Animatable(1f) }
    val parts = remember {
        val r = Random(11)
        List(64) {
            Particle(
                x = r.nextFloat(), y = r.nextFloat(),
                speed = 0.5f + r.nextFloat() * 1.0f,
                size = 0.8f + r.nextFloat() * 1.6f,
                depth = 0.3f + r.nextFloat() * 0.7f,
                kind = r.nextInt(4),
                wob = 0.5f + r.nextFloat()
            )
        }
    }

    DisposableEffect(live) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val sensor = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val listener = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val nx = (-e.values[0] / 9.8f).coerceIn(-1f, 1f)
                val ny = (e.values[1] / 9.8f).coerceIn(-1f, 1f)
                tx += (nx - tx) * 0.08f
                ty += (ny - ty) * 0.08f
            }

            override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}
        }
        if (live && sm != null && sensor != null) {
            sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
        }
        onDispose { sm?.unregisterListener(listener) }
    }

    LaunchedEffect(live) {
        if (!live) return@LaunchedEffect
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L) {
                    val dt = ((now - last) / 1_000_000_000f).coerceAtMost(0.05f)
                    clock += dt
                    phase += dt * (0.05f + 0.6f * act)
                }
                last = now
            }
        }
    }

    LaunchedEffect(pulse) {
        if (pulse > 0) {
            ring.snapTo(0f)
            ring.animateTo(1f, tween(1700, easing = FastOutSlowInEasing))
        }
    }

    Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val d = density
        drawRect(Bg)
        val c = clock
        val px = tx * w * 0.06f
        val py = ty * h * 0.03f
        val aCol = lerp(Violet, tintC, mix)
        val bCol = lerp(Pink, tintC, mix * 0.55f)
        val cCol = lerp(Orange, tintC, mix * 0.3f)
        blob(
            aCol.copy(alpha = 0.30f + 0.08f * act),
            w * (0.5f + 0.38f * sin(c * 0.11f)) + px,
            h * (0.14f + 0.10f * sin(c * 0.17f + 1f)) + py,
            w * 0.95f
        )
        blob(
            bCol.copy(alpha = 0.21f + 0.06f * act),
            w * (0.55f + 0.38f * sin(c * 0.13f + 2f)) - px * 1.4f,
            h * (0.58f + 0.12f * sin(c * 0.09f + 0.5f)) - py * 1.4f,
            w * 0.85f
        )
        blob(
            cCol.copy(alpha = 0.14f),
            w * (0.4f + 0.3f * sin(c * 0.1f + 4f)) + px * 0.6f,
            h * (0.88f + 0.08f * sin(c * 0.15f)) + py * 0.6f,
            w * 0.8f
        )

        if (live) {
            val streak = (10f + 70f * act) * d
            for (p in parts) {
                val yy = (p.y + phase * p.speed) % 1f
                val x = p.x * w + sin(c * 0.6f * p.wob + p.y * 20f) * 10f * d + tx * p.depth * 26f * d
                val y = yy * (h + streak) - streak * 0.5f
                val base = when (p.kind) {
                    0 -> Pink
                    1 -> Violet
                    2 -> Cyan
                    else -> Orange
                }
                val edge = sin(yy * PI.toFloat())
                val a = (0.20f + 0.5f * p.depth) * (0.55f + 0.45f * act) * edge
                drawLine(
                    brush = Brush.verticalGradient(
                        listOf(Color.Transparent, base.copy(alpha = a)),
                        startY = y - streak, endY = y
                    ),
                    start = Offset(x, y - streak),
                    end = Offset(x, y),
                    strokeWidth = p.size * d,
                    cap = StrokeCap.Round
                )
                drawCircle(base.copy(alpha = (a * 1.4f).coerceAtMost(1f)), p.size * 1.15f * d, Offset(x, y))
            }
        }

        val r = ring.value
        if (r < 1f) {
            val maxR = maxOf(w, h) * 0.9f
            for (k in 0..1) {
                val rr = (r - k * 0.12f).coerceIn(0f, 1f)
                if (rr > 0f) {
                    drawCircle(
                        Green.copy(alpha = 0.30f * (1f - rr)),
                        radius = maxR * rr,
                        center = Offset(w / 2f, h * 0.45f),
                        style = Stroke(width = 3.dp.toPx() * (1f - rr) + 1f)
                    )
                }
            }
        }
    }
}

// ============================================================ intro splash

private class SP(val a: Float, val d0: Float, val delay: Float, val size: Float, val kind: Int)

/** Cinematic intro: particles spiral into a ring, the ring draws itself, logo pops, name reveals. */
@Composable
fun IntroSplash(onReveal: () -> Unit, onFinished: () -> Unit) {
    var t by remember { mutableFloatStateOf(0f) }
    var skip by remember { mutableStateOf(false) }
    val logo = remember { Animatable(0f) }
    val exit = remember { Animatable(0f) }
    val sp = remember {
        val r = Random(5)
        List(60) {
            SP(
                a = (it / 60f) * 2f * PI.toFloat(),
                d0 = 160f + r.nextFloat() * 420f,
                delay = r.nextFloat() * 0.14f,
                size = 1.4f + r.nextFloat() * 2.4f,
                kind = r.nextInt(3)
            )
        }
    }

    LaunchedEffect(Unit) {
        coroutineScope {
            launch {
                delay(700)
                logo.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = 260f))
            }
            var start = -1L
            var revealed = false
            while (t < 1f) {
                withFrameNanos { now ->
                    if (start < 0) start = now
                    val el = (now - start) / 1_000_000f
                    t = if (skip) 1f else (el / 2400f).coerceAtMost(1f)
                    if (t >= 0.9f && !revealed) {
                        revealed = true
                        onReveal()
                    }
                }
            }
        }
        if (logo.value < 1f) logo.snapTo(1f)
        exit.animateTo(1f, tween(650, easing = FastOutSlowInEasing))
        onFinished()
    }

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                alpha = 1f - exit.value
                val s = 1f + 0.12f * exit.value
                scaleX = s
                scaleY = s
            }
            .background(Bg)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                skip = true
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val d = density
            val cx = size.width / 2f
            val cy = (size.height - 244.dp.toPx()) / 2f + 70.dp.toPx()
            val c = Offset(cx, cy)
            val rad = 62.dp.toPx()
            val tt = t
            val glow = smooth(tt / 0.5f)
            val gr = 300.dp.toPx()
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Violet.copy(alpha = 0.40f * glow), Pink.copy(alpha = 0.16f * glow), Color.Transparent),
                    center = c, radius = gr
                ),
                radius = gr, center = c
            )
            val fo = ((tt - 0.58f) / 0.2f).coerceIn(0f, 1f)
            for (p in sp) {
                val e = easeOut((tt - p.delay) / 0.4f)
                val e0 = easeOut((tt - p.delay - 0.035f) / 0.4f)
                val a1 = p.a + (1f - e) * 2.4f
                val d1 = rad + (1f - e) * p.d0 * d
                val a0 = p.a + (1f - e0) * 2.4f
                val d0 = rad + (1f - e0) * p.d0 * d
                val pos = Offset(cx + cos(a1) * d1, cy + sin(a1) * d1)
                val prev = Offset(cx + cos(a0) * d0, cy + sin(a0) * d0)
                val col = when (p.kind) {
                    0 -> Pink
                    1 -> Orange
                    else -> Violet
                }
                val al = (0.15f + 0.85f * e) * (1f - fo)
                if (al > 0.01f) {
                    drawLine(col.copy(alpha = al * 0.5f), prev, pos, strokeWidth = 1.5f * d, cap = StrokeCap.Round)
                    drawCircle(col.copy(alpha = al), p.size * d, pos)
                }
            }
            val arcP = smooth((tt - 0.26f) / 0.36f)
            val ringAlpha = 1f - 0.55f * smooth((tt - 0.8f) / 0.2f)
            if (arcP > 0f) {
                rotate(-90f, c) {
                    drawArc(
                        brush = Brush.sweepGradient(listOf(Violet, Pink, Orange, Violet), center = c),
                        startAngle = 0f,
                        sweepAngle = 360f * arcP,
                        useCenter = false,
                        topLeft = Offset(cx - rad, cy - rad),
                        size = Size(rad * 2f, rad * 2f),
                        alpha = ringAlpha,
                        style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
                if (arcP < 1f) {
                    val ang = (-90f + 360f * arcP) * PI.toFloat() / 180f
                    val hp = Offset(cx + cos(ang) * rad, cy + sin(ang) * rad)
                    drawCircle(
                        Brush.radialGradient(listOf(Color.White, Pink.copy(alpha = 0.5f), Color.Transparent), center = hp, radius = 16.dp.toPx()),
                        radius = 16.dp.toPx(), center = hp
                    )
                }
            }
        }

        Column(
            Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(Modifier.size(140.dp), contentAlignment = Alignment.Center) {
                Box(
                    Modifier
                        .size(88.dp)
                        .graphicsLayer {
                            val s = logo.value
                            scaleX = s
                            scaleY = s
                            alpha = s.coerceIn(0f, 1f)
                            rotationZ = (1f - s) * -30f
                        }
                        .clip(RoundedCornerShape(28.dp))
                        .background(AccentBrush2),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.Download, null, tint = Color.White, modifier = Modifier.size(50.dp))
                }
            }
            Spacer(Modifier.height(28.dp))
            Row(horizontalArrangement = Arrangement.Center) {
                "TubeVault".forEachIndexed { i, ch ->
                    androidx.compose.material3.Text(
                        ch.toString(),
                        color = lerp(Pink, Orange, i / 8f),
                        fontSize = 42.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.graphicsLayer {
                            val l = ((t - 0.52f - i * 0.03f) / 0.16f).coerceIn(0f, 1f)
                            alpha = l
                            translationY = (1f - l) * 40f
                            val s = 0.6f + 0.4f * l
                            scaleX = s
                            scaleY = s
                        }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Save any video. Keep it forever.",
                color = TextLo,
                fontSize = 14.sp,
                modifier = Modifier.graphicsLayer {
                    alpha = ((t - 0.78f) / 0.15f).coerceIn(0f, 1f)
                }
            )
        }
    }
}

// ============================================================ download start: orb flies to Library

@Composable
fun FlyOrb(from: Offset, to: Offset, audio: Boolean, onArrive: () -> Unit, onDone: () -> Unit) {
    val p = remember { Animatable(0f) }
    val burst = remember { Animatable(0f) }
    val d = LocalDensity.current.density
    val c1 = if (audio) Violet else Pink

    LaunchedEffect(Unit) {
        p.animateTo(1f, tween(900, easing = CubicBezierEasing(0.45f, 0f, 0.25f, 1f)))
        onArrive()
        burst.animateTo(1f, tween(520, easing = LinearEasing))
        onDone()
    }

    Canvas(Modifier.fillMaxSize()) {
        val side = if (to.x >= from.x) -1f else 1f
        val ctrl = Offset(
            (from.x + to.x) / 2f + side * 110f * d,
            minOf(from.y, to.y) - 120f * d
        )

        fun at(t: Float): Offset {
            val u = 1f - t
            return Offset(
                u * u * from.x + 2f * u * t * ctrl.x + t * t * to.x,
                u * u * from.y + 2f * u * t * ctrl.y + t * t * to.y
            )
        }

        val pv = p.value
        if (pv < 1f) {
            for (k in 9 downTo 1) {
                val tt = pv - k * 0.022f
                if (tt > 0f) {
                    val fr = 1f - k / 10f
                    drawCircle(
                        c1.copy(alpha = 0.5f * fr),
                        radius = (13f * fr + 2f) * d * (1f - 0.4f * pv),
                        center = at(tt)
                    )
                }
            }
            val o = at(pv)
            val gr = 30f * d
            drawCircle(
                Brush.radialGradient(listOf(Orange.copy(alpha = 0.9f), Pink.copy(alpha = 0.35f), Color.Transparent), center = o, radius = gr),
                radius = gr, center = o
            )
            drawCircle(Color.White, 6f * d * (1f - 0.4f * pv), o)
        } else {
            val b = burst.value
            if (b < 1f) {
                drawCircle(
                    Pink.copy(alpha = (1f - b) * 0.8f),
                    radius = 14f * d + 52f * d * b,
                    center = to,
                    style = Stroke(width = 3f * d * (1f - b) + 0.5f)
                )
                for (k in 0 until 8) {
                    val ang = k * (PI.toFloat() / 4f)
                    val r1 = 18f * d + 40f * d * b
                    val r2 = r1 + 10f * d * (1f - b)
                    drawLine(
                        Orange.copy(alpha = 1f - b),
                        Offset(to.x + cos(ang) * r1, to.y + sin(ang) * r1),
                        Offset(to.x + cos(ang) * r2, to.y + sin(ang) * r2),
                        strokeWidth = 3f * d,
                        cap = StrokeCap.Round
                    )
                }
            }
        }
    }
}

// ============================================================ completion bits

private class Confetti(
    val angle: Float, val speed: Float, val size: Float,
    val color: Color, val spin: Float, val rect: Boolean
)

private val confettiColors = listOf(Pink, Orange, Violet, Cyan, Green)

/** One-shot confetti explosion; plays once when it enters the composition. */
@Composable
fun ConfettiBurst(
    modifier: Modifier = Modifier,
    originX: Float = 0.5f,
    originY: Float = 0.5f,
    count: Int = 40,
    durationMs: Int = 1400
) {
    val p = remember { Animatable(0f) }
    val seeds = remember {
        val r = Random(System.nanoTime())
        List(count) {
            Confetti(
                angle = r.nextFloat() * 2f * PI.toFloat(),
                speed = 0.35f + r.nextFloat() * 0.9f,
                size = 3f + r.nextFloat() * 4f,
                color = confettiColors[r.nextInt(confettiColors.size)],
                spin = r.nextFloat() * 8f,
                rect = r.nextBoolean()
            )
        }
    }
    LaunchedEffect(Unit) { p.animateTo(1f, tween(durationMs, easing = LinearEasing)) }
    Canvas(modifier) {
        val t = p.value
        if (t < 1f) {
            val o = Offset(size.width * originX, size.height * originY)
            val d = density
            val ease = easeOut(t)
            val alpha = 1f - ((t - 0.6f) / 0.4f).coerceIn(0f, 1f)
            for (c in seeds) {
                val reach = 220f * d * c.speed * ease
                val pos = Offset(
                    o.x + cos(c.angle) * reach,
                    o.y + sin(c.angle) * reach + t * t * 140f * d
                )
                val s = c.size * d
                if (c.rect) {
                    rotate(c.spin * t * 360f, pos) {
                        drawRect(c.color.copy(alpha = alpha), Offset(pos.x - s, pos.y - s * 0.5f), Size(s * 2f, s))
                    }
                } else {
                    drawCircle(c.color.copy(alpha = alpha), s * 0.7f, pos)
                }
            }
        }
    }
}

/** A check mark that draws itself. */
@Composable
fun AnimatedCheck(color: Color, modifier: Modifier = Modifier, durationMs: Int = 450) {
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) { p.animateTo(1f, tween(durationMs, easing = FastOutSlowInEasing)) }
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val a = Offset(w * 0.22f, h * 0.54f)
        val b = Offset(w * 0.42f, h * 0.73f)
        val c = Offset(w * 0.78f, h * 0.32f)
        val l1 = (b - a).getDistance()
        val l2 = (c - b).getDistance()
        val cur = p.value * (l1 + l2)
        val stroke = w * 0.11f
        val d1 = minOf(cur, l1)
        drawLine(color, a, a + (b - a) * (d1 / l1), stroke, StrokeCap.Round)
        if (cur > l1) {
            val d2 = cur - l1
            drawLine(color, b, b + (c - b) * (d2 / l2), stroke, StrokeCap.Round)
        }
    }
}

// ============================================================ progress visuals

/** Circular progress ring. progress < 0 -> spinning arc. */
@Composable
fun RingProgress(
    progress: Float,
    modifier: Modifier = Modifier,
    stroke: Dp = 4.dp,
    content: @Composable BoxScope.() -> Unit = {}
) {
    val p by animateFloatAsState(progress.coerceIn(0f, 1f), tween(400), label = "ring")
    val t = rememberInfiniteTransition(label = "ringspin")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(1000, easing = LinearEasing)), label = "spin")
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = stroke.toPx()
            val sz = Size(size.width - sw, size.height - sw)
            val tl = Offset(sw / 2f, sw / 2f)
            drawArc(
                color = Color(0x33FFFFFF), startAngle = 0f, sweepAngle = 360f, useCenter = false,
                topLeft = tl, size = sz, style = Stroke(sw)
            )
            if (progress < 0f) {
                rotate(spin, center) {
                    drawArc(
                        brush = Brush.sweepGradient(0f to Pink, 0.3f to Orange, 1f to Orange, center = center),
                        startAngle = 0f, sweepAngle = 110f, useCenter = false,
                        topLeft = tl, size = sz, style = Stroke(sw, cap = StrokeCap.Round)
                    )
                }
            } else {
                rotate(-90f, center) {
                    drawArc(
                        brush = Brush.sweepGradient(0f to Pink, p.coerceAtLeast(0.02f) to Orange, 1f to Orange, center = center),
                        startAngle = 0f, sweepAngle = 360f * p, useCenter = false,
                        topLeft = tl, size = sz, style = Stroke(sw, cap = StrokeCap.Round)
                    )
                }
            }
        }
        content()
    }
}

private fun Path.curveThrough(pts: List<Offset>) {
    for (i in 1 until pts.size) {
        val p0 = pts[i - 1]
        val p1 = pts[i]
        quadraticBezierTo(p0.x, p0.y, (p0.x + p1.x) / 2f, (p0.y + p1.y) / 2f)
    }
    lineTo(pts.last().x, pts.last().y)
}

/** Smooth live speed graph. */
@Composable
fun Sparkline(values: List<Float>, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        if (values.size >= 2) {
            val mx = (values.maxOrNull() ?: 1f).coerceAtLeast(1f) * 1.15f
            val step = size.width / (values.size - 1)
            val pts = values.mapIndexed { i, v ->
                Offset(i * step, size.height - (v / mx) * size.height * 0.92f - 2f)
            }
            val line = Path().apply {
                moveTo(pts[0].x, pts[0].y)
                curveThrough(pts)
            }
            val fill = Path().apply {
                moveTo(pts[0].x, size.height)
                lineTo(pts[0].x, pts[0].y)
                curveThrough(pts)
                lineTo(pts.last().x, size.height)
                close()
            }
            drawPath(fill, Brush.verticalGradient(listOf(Pink.copy(alpha = 0.35f), Color.Transparent)))
            drawPath(line, AccentBrush, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            drawCircle(Orange, 3.dp.toPx(), pts.last())
        }
    }
}
