package com.raja.tubevault.core

/** Called from C++ while whisper.cpp is working (0..100). */
interface WhisperProgress {
    fun onProgress(percent: Int)
}

/** Thin bridge to whisper.cpp (libtubevault_whisper.so, built by CMake). */
object WhisperNative {
    @Volatile
    private var tried = false

    @Volatile
    private var ok = false

    /** true when the native library could be loaded on this phone */
    fun available(): Boolean {
        if (!tried) {
            tried = true
            ok = try {
                System.loadLibrary("tubevault_whisper")
                true
            } catch (_: Throwable) {
                false
            }
        }
        return ok
    }

    /** preset: 0 = tiny, 1 = base, 2 = small (picks the right attention heads for word timing) */
    external fun nativeInit(path: String, preset: Int): Long

    external fun nativeFree(handle: Long)

    external fun nativeAbort(abort: Boolean)

    /** stop a running transcription (no-op when the library isn't loaded) */
    fun nativeAbortSafe() {
        if (ok) {
            try {
                nativeAbort(true)
            } catch (_: Throwable) {
            }
        }
    }

    /** @return the transcript in the line format described in whisper_jni.cpp, or null on failure / cancel */
    external fun nativeTranscribe(
        handle: Long,
        samples: FloatArray,
        language: String,
        threads: Int,
        listener: WhisperProgress?
    ): ByteArray?
}
