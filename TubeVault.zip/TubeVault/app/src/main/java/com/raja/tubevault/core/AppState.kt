package com.raja.tubevault.core

/** Is any TubeVault screen visible right now? (the floating island only shows when it is not) */
object AppState {
    @Volatile
    var foreground = false
}
