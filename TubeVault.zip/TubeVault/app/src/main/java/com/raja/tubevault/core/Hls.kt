package com.raja.tubevault.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

/** Minimal HLS (.m3u8) support – used for ended live streams / live classes. */
object Hls {
    data class Variant(val url: String, val height: Int, val bandwidth: Long, val fps: Int, val audioUrl: String?)

    private class Media(val init: String?, val segments: List<String>)

    private fun get(url: String): okhttp3.Response {
        val req = Request.Builder().url(url)
            .header("User-Agent", Net.userAgent(url))
            .header("Accept-Encoding", "identity")
            .build()
        return Net.client.newCall(req).execute()
    }

    fun fetchText(url: String): String =
        get(url).use { r ->
            if (!r.isSuccessful) throw HttpStatusException(r.code)
            r.body?.string() ?: throw IOException("Empty playlist")
        }

    private fun resolve(base: String, ref: String): String =
        base.toHttpUrl().resolve(ref)?.toString() ?: ref

    private fun attrs(line: String): Map<String, String> {
        val out = HashMap<String, String>()
        val body = line.substringAfter(':')
        Regex("([A-Z0-9-]+)=(\"[^\"]*\"|[^,]*)").findAll(body).forEach {
            out[it.groupValues[1]] = it.groupValues[2].trim('"')
        }
        return out
    }

    /** Returns the quality variants of a master playlist (or a single variant if it's a media playlist). */
    fun variants(masterUrl: String, text: String): List<Variant> {
        if (!text.contains("#EXT-X-STREAM-INF")) {
            return listOf(Variant(masterUrl, 0, 0, 0, null))
        }
        val lines = text.lines().map { it.trim() }
        val audioGroups = HashMap<String, String>()
        for (l in lines) {
            if (l.startsWith("#EXT-X-MEDIA") ) {
                val a = attrs(l)
                if (a["TYPE"] == "AUDIO" && a["URI"] != null) {
                    val g = a["GROUP-ID"] ?: continue
                    if (!audioGroups.containsKey(g) || a["DEFAULT"] == "YES") audioGroups[g] = resolve(masterUrl, a["URI"]!!)
                }
            }
        }
        val result = ArrayList<Variant>()
        var i = 0
        while (i < lines.size) {
            val l = lines[i]
            if (l.startsWith("#EXT-X-STREAM-INF")) {
                val a = attrs(l)
                var j = i + 1
                while (j < lines.size && (lines[j].isEmpty() || lines[j].startsWith("#"))) j++
                if (j < lines.size) {
                    val res = a["RESOLUTION"]?.substringAfter('x')?.toIntOrNull() ?: 0
                    val bw = a["AVERAGE-BANDWIDTH"]?.toLongOrNull() ?: a["BANDWIDTH"]?.toLongOrNull() ?: 0L
                    val fps = a["FRAME-RATE"]?.toDoubleOrNull()?.toInt() ?: 0
                    val codecs = a["CODECS"] ?: ""
                    val videoless = res == 0 && !codecs.contains("avc") && !codecs.contains("hvc") && !codecs.contains("hev")
                    if (!videoless) {
                        result.add(Variant(resolve(masterUrl, lines[j]), res, bw, fps, a["AUDIO"]?.let { audioGroups[it] }))
                    }
                    i = j
                }
            }
            i++
        }
        return result
    }

    private fun parseMedia(url: String, text: String): Media {
        if (text.contains("#EXT-X-KEY") && Regex("#EXT-X-KEY:METHOD=(?!NONE)").containsMatchIn(text)) {
            throw IOException("This stream is encrypted and can't be saved.")
        }
        var init: String? = null
        val segs = ArrayList<String>()
        for (raw in text.lines()) {
            val l = raw.trim()
            if (l.isEmpty()) continue
            if (l.startsWith("#EXT-X-MAP")) {
                attrs(l)["URI"]?.let { init = resolve(url, it) }
            } else if (!l.startsWith("#")) {
                segs.add(resolve(url, l))
            }
        }
        if (segs.isEmpty()) throw IOException("The playlist has no video segments yet.")
        return Media(init, segs)
    }

    private fun fetchBytes(url: String): ByteArray =
        get(url).use { r ->
            if (!r.isSuccessful) throw HttpStatusException(r.code)
            r.body?.bytes() ?: throw IOException("Empty segment")
        }

    private suspend fun fetchRetry(url: String): ByteArray {
        var attempt = 0
        while (true) {
            try {
                return fetchBytes(url)
            } catch (e: IOException) {
                attempt++
                if (attempt >= 4) throw e
                delay(600L * attempt)
            }
        }
    }

    /** Downloads every segment of a media playlist and joins them into [dest]. */
    suspend fun download(playlistUrl: String, dest: File, onBytes: (Long) -> Unit) {
        val ctx = currentCoroutineContext()
        val media = withContext(Dispatchers.IO) { parseMedia(playlistUrl, fetchText(playlistUrl)) }
        FileOutputStream(dest).use { out ->
            media.init?.let {
                val b = withContext(Dispatchers.IO) { fetchBytes(it) }
                out.write(b)
                onBytes(b.size.toLong())
            }
            for (window in media.segments.chunked(4)) {
                ctx.ensureActive()
                val parts = coroutineScope {
                    window.map { u ->
                        async(Dispatchers.IO) { fetchRetry(u) }
                    }.awaitAll()
                }
                for (b in parts) {
                    out.write(b)
                    onBytes(b.size.toLong())
                }
            }
        }
        if (dest.length() <= 0L) throw IOException("Downloaded file is empty")
    }
}
