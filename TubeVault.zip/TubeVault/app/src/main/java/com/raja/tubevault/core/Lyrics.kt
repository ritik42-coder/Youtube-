package com.raja.tubevault.core

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.max
import kotlin.math.min

// ============================================================================ model

data class LyricWord(val text: String, val startMs: Long, val endMs: Long)

/** One sung line. [isBreak] lines are the "• • •" instrumental gaps (never saved, built at display time). */
data class LyricLine(
    val startMs: Long,
    val endMs: Long,
    val words: List<LyricWord>,
    val isBreak: Boolean = false
)

data class LyricsDoc(val source: String, val language: String, val lines: List<LyricLine>)

// ============================================================================ storage

/** Lyrics are saved next to the app (one small JSON per song) so a song is only transcribed once. */
object LyricsStore {
    private fun dir(ctx: Context): File = File(ctx.applicationContext.filesDir, "lyrics").also { it.mkdirs() }

    private fun file(ctx: Context, id: String): File {
        val safe = id.replace(Regex("[^A-Za-z0-9_-]"), "_").take(60)
        return File(dir(ctx), safe + "_" + Integer.toHexString(id.hashCode()) + ".json")
    }

    fun has(ctx: Context, id: String): Boolean = file(ctx, id).exists()

    fun delete(ctx: Context, id: String) {
        try {
            file(ctx, id).delete()
        } catch (_: Throwable) {
        }
    }

    fun save(ctx: Context, id: String, doc: LyricsDoc) {
        val lines = JSONArray()
        for (l in doc.lines) {
            val words = JSONArray()
            for (w in l.words) words.put(JSONArray().put(w.text).put(w.startMs).put(w.endMs))
            lines.put(JSONObject().put("s", l.startMs).put("e", l.endMs).put("w", words))
        }
        val root = JSONObject().put("v", 1).put("src", doc.source).put("lang", doc.language).put("lines", lines)
        val f = file(ctx, id)
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeText(root.toString())
        if (!tmp.renameTo(f)) {
            f.writeText(root.toString())
            tmp.delete()
        }
    }

    fun load(ctx: Context, id: String): LyricsDoc? {
        val f = file(ctx, id)
        if (!f.exists()) return null
        return try {
            val root = JSONObject(f.readText())
            val arr = root.getJSONArray("lines")
            val lines = ArrayList<LyricLine>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val wa = o.getJSONArray("w")
                val words = ArrayList<LyricWord>()
                for (j in 0 until wa.length()) {
                    val w = wa.getJSONArray(j)
                    words.add(LyricWord(w.getString(0), w.getLong(1), w.getLong(2)))
                }
                if (words.isNotEmpty()) lines.add(LyricLine(o.getLong("s"), o.getLong("e"), words))
            }
            if (lines.isEmpty()) null else LyricsDoc(root.optString("src", ""), root.optString("lang", "auto"), lines)
        } catch (_: Throwable) {
            null
        }
    }
}

// ============================================================================ timeline (adds the instrumental "dots")

object LyricsTimeline {
    private const val INTRO_MIN_MS = 4500L
    private const val GAP_MIN_MS = 6500L

    fun withBreaks(lines: List<LyricLine>): List<LyricLine> {
        if (lines.isEmpty()) return lines
        val out = ArrayList<LyricLine>(lines.size + 4)
        val first = lines.first()
        if (first.startMs >= INTRO_MIN_MS) out.add(LyricLine(400L, first.startMs - 300L, emptyList(), true))
        for (i in lines.indices) {
            out.add(lines[i])
            val next = lines.getOrNull(i + 1) ?: continue
            if (next.startMs - lines[i].endMs >= GAP_MIN_MS) {
                out.add(LyricLine(lines[i].endMs + 400L, next.startMs - 300L, emptyList(), true))
            }
        }
        return out
    }
}

// ============================================================================ Whisper output -> lines

/** Turns the byte transcript produced by whisper_jni.cpp into karaoke lines with per-word timing. */
object WhisperParser {
    private class Tok(val dtw: Long, val t0: Long, val t1: Long, val p: Int, val bytes: ByteArray)
    private class Seg(val t0: Long, val t1: Long, val nsp: Int) {
        val toks = ArrayList<Tok>()
    }

    private class WB(val text: String, val dtw: Long, val t0: Long, val t1: Long, val p: Int)

    private val JUNK = listOf(
        "thanks for watching", "thank you for watching", "subscribe", "subtitles by", "amara.org",
        "like and subscribe", "please subscribe", "www."
    )

    fun parse(raw: ByteArray): List<LyricLine> {
        val segs = ArrayList<Seg>()
        var i = 0
        val n = raw.size
        while (i < n) {
            var e = i
            while (e < n && raw[e] != '\n'.code.toByte()) e++
            if (e > i) readLine(raw, i, e, segs)
            i = e + 1
        }

        val lines = ArrayList<LyricLine>()
        var lastNorm = ""
        var repeat = 0
        for (seg in segs) {
            if (seg.toks.isEmpty()) continue
            val words = groupWords(seg)
            if (words.isEmpty()) continue
            val text = words.joinToString(" ") { it.text }
            val low = text.lowercase()
            if (JUNK.any { low.contains(it) }) continue
            val meanP = words.sumOf { it.p } / words.size
            if (meanP < 90 && seg.nsp > 600) continue // quiet + unsure = hallucination
            val norm = low.filter { it.isLetterOrDigit() }
            if (norm.isEmpty()) continue
            if (norm == lastNorm) {
                repeat++
                if (repeat >= 3) continue // endless loop of the same line
            } else {
                repeat = 0
                lastNorm = norm
            }
            lines.addAll(buildLines(seg, words))
        }
        return tidy(lines)
    }

    // ---------------------------------------------------------------- reading the byte format

    private fun readLine(raw: ByteArray, a: Int, b: Int, segs: ArrayList<Seg>) {
        val kind = raw[a].toInt().toChar()
        val tabs = IntArray(6)
        var found = 0
        var k = a
        val need = if (kind == 'S') 3 else 5
        while (k < b && found < need) {
            if (raw[k] == '\t'.code.toByte()) tabs[found++] = k
            k++
        }
        if (found < need) return
        try {
            if (kind == 'S') {
                val h = String(raw, a, b - a, Charsets.ISO_8859_1).split('\t')
                segs.add(Seg(h[1].toLong(), h[2].toLong(), h[3].toInt()))
            } else if (kind == 'T' && segs.isNotEmpty()) {
                val h = String(raw, a, tabs[4] - a, Charsets.ISO_8859_1).split('\t')
                val bytes = raw.copyOfRange(tabs[4] + 1, b)
                segs.last().toks.add(Tok(h[1].toLong(), h[2].toLong(), h[3].toLong(), h[4].toInt(), bytes))
            }
        } catch (_: Throwable) {
        }
    }

    /** A new word starts at every token that begins with a space (Whisper's own word marker). */
    private fun groupWords(seg: Seg): List<WB> {
        val words = ArrayList<WB>()
        var cur: ByteArrayOutputStream? = null
        var cDtw = -1L
        var cT0 = 0L
        var cT1 = 0L
        var pSum = 0
        var pN = 0

        fun flush() {
            val c = cur ?: return
            val s = String(c.toByteArray(), Charsets.UTF_8).trim()
            if (s.isNotEmpty() && s.any { it.isLetterOrDigit() }) {
                words.add(WB(s, cDtw, cT0, cT1, if (pN > 0) pSum / pN else 0))
            }
            cur = null
        }

        for (t in seg.toks) {
            val startsWithSpace = t.bytes.isNotEmpty() && t.bytes[0] == 0x20.toByte()
            if (startsWithSpace || cur == null) {
                flush()
                cur = ByteArrayOutputStream()
                cDtw = t.dtw
                cT0 = t.t0
                pSum = 0
                pN = 0
            }
            cur!!.write(t.bytes)
            cT1 = t.t1
            pSum += t.p
            pN++
        }
        flush()

        // Languages written without spaces (Japanese, Chinese...): split the one long "word" into small pieces
        if (words.size == 1 && words[0].text.codePointCount(0, words[0].text.length) >= 6) {
            val w = words[0]
            val cps = w.text.codePoints().toArray()
            val pieces = ArrayList<WB>()
            var i = 0
            while (i < cps.size) {
                val end = min(i + 2, cps.size)
                pieces.add(WB(String(cps, i, end - i), -1L, w.t0, w.t1, w.p))
                i = end
            }
            return pieces
        }
        return words
    }

    // ---------------------------------------------------------------- timing

    private fun capMs(text: String): Long = (text.length * 140L + 300L).coerceIn(350L, 2500L)

    private fun buildLines(seg: Seg, words: List<WB>): List<LyricLine> {
        val segS = seg.t0 * 10L
        val segE = max(seg.t1 * 10L, segS + 600L)
        val n = words.size
        val starts = LongArray(n)

        // 1) DTW times (best), 2) plain token times, 3) spread by letter count
        var ok = false
        if (words.all { it.dtw >= 0L }) {
            for (i in 0 until n) starts[i] = words[i].dtw * 10L
            ok = plausible(starts, segS, segE, n)
        }
        if (!ok) {
            for (i in 0 until n) starts[i] = words[i].t0 * 10L
            ok = plausible(starts, segS, segE, n)
        }
        if (!ok) {
            val total = words.sumOf { it.text.length + 1 }.toFloat()
            var acc = 0
            for (i in 0 until n) {
                starts[i] = segS + ((segE - segS) * (acc / total)).toLong()
                acc += words[i].text.length + 1
            }
        }
        for (i in 1 until n) if (starts[i] < starts[i - 1]) starts[i] = starts[i - 1]

        val lw = ArrayList<LyricWord>(n)
        for (i in 0 until n) {
            val cap = capMs(words[i].text)
            val hardEnd = if (i + 1 < n) starts[i + 1] else segE
            var end = min(hardEnd, starts[i] + cap)
            if (end < starts[i] + 150L) end = starts[i] + 150L
            lw.add(LyricWord(words[i].text, starts[i], end))
        }
        return splitLines(lw)
    }

    private fun plausible(starts: LongArray, segS: Long, segE: Long, n: Int): Boolean {
        if (n >= 3 && starts[n - 1] - starts[0] < 250L) return false // everything on one spot
        var outside = 0
        var backwards = 0
        for (i in 0 until n) {
            if (starts[i] < segS - 1200L || starts[i] > segE + 1200L) outside++
            if (i > 0 && starts[i] < starts[i - 1] - 80L) backwards++
        }
        return outside * 3 <= n && backwards * 4 <= n
    }

    private fun endsClause(s: String): Boolean {
        val c = s.lastOrNull() ?: return false
        return c in ".!?;:,…。！？،؟"
    }

    private fun splitLines(words: List<LyricWord>): List<LyricLine> {
        val groups = ArrayList<ArrayList<LyricWord>>()
        var cur = ArrayList<LyricWord>()
        var chars = 0
        for (w in words) {
            val gap = if (cur.isNotEmpty()) w.startMs - cur.last().endMs else 0L
            val wantBreak = cur.isNotEmpty() && (
                cur.size >= 9 ||
                    chars + w.text.length + 1 > 46 ||
                    (gap > 900L && cur.size >= 2) ||
                    (cur.size >= 4 && endsClause(cur.last().text))
                )
            if (wantBreak) {
                groups.add(cur)
                cur = ArrayList()
                chars = 0
            }
            cur.add(w)
            chars += w.text.length + 1
        }
        if (cur.isNotEmpty()) groups.add(cur)
        // never leave a lonely last word on its own line when it follows closely
        if (groups.size >= 2) {
            val last = groups.last()
            val prev = groups[groups.size - 2]
            if (last.size == 1 && prev.size <= 8 && last[0].startMs - prev.last().endMs < 600L) {
                prev.addAll(last)
                groups.removeAt(groups.size - 1)
            }
        }
        return groups.map { LyricLine(it.first().startMs, it.last().endMs, it) }
    }

    /** sort, make sure lines never overlap */
    private fun tidy(lines: List<LyricLine>): List<LyricLine> {
        val s = lines.sortedBy { it.startMs }
        val out = ArrayList<LyricLine>(s.size)
        for (i in s.indices) {
            val l = s[i]
            val next = s.getOrNull(i + 1)
            var end = l.endMs
            if (next != null && end > next.startMs) end = max(l.startMs + 200L, next.startMs)
            val words = if (end == l.endMs) l.words else {
                l.words.map { w -> if (w.endMs > end) w.copy(endMs = max(w.startMs + 80L, end)) else w }
            }
            out.add(LyricLine(l.startMs, end, words))
        }
        return out
    }
}

// ============================================================================ .lrc (synced lyrics from the internet)

object LrcParser {
    private val TAG = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?]""")
    private val WORD_TAG = Regex("""<\d+:\d+(?:[.:]\d+)?>""")

    private class Item(val t: Long, val text: String)

    fun parse(text: String, durationMs: Long): List<LyricLine> {
        val items = ArrayList<Item>()
        for (raw in text.lines()) {
            val tags = TAG.findAll(raw).toList()
            if (tags.isEmpty()) continue
            val content = raw.substring(tags.last().range.last + 1).replace(WORD_TAG, "").trim()
            for (m in tags) {
                val mins = m.groupValues[1].toLong()
                val secs = m.groupValues[2].toLong()
                val fr = m.groupValues[3]
                val ms = when (fr.length) {
                    0 -> 0L
                    1 -> fr.toLong() * 100L
                    2 -> fr.toLong() * 10L
                    else -> fr.take(3).toLong()
                }
                items.add(Item(mins * 60_000L + secs * 1000L + ms, content))
            }
        }
        items.sortBy { it.t }
        val lines = ArrayList<LyricLine>()
        for (i in items.indices) {
            val it = items[i]
            if (it.text.isBlank()) continue
            val nextT = items.getOrNull(i + 1)?.t ?: (if (durationMs > it.t) durationMs else it.t + 6000L)
            val parts = it.text.split(Regex("\\s+")).filter { p -> p.isNotEmpty() }
            if (parts.isEmpty()) continue
            val chars = parts.sumOf { p -> p.length + 1 }
            val sung = (chars * 130L + 800L).coerceAtLeast(1200L)
            val end = min(nextT - 80L, it.t + sung).coerceAtLeast(it.t + 600L)
            var acc = 0
            val words = parts.map { p ->
                val s = it.t + ((end - it.t) * (acc.toFloat() / chars)).toLong()
                acc += p.length + 1
                val e = it.t + ((end - it.t) * (acc.toFloat() / chars)).toLong()
                LyricWord(p, s, max(e, s + 80L))
            }
            lines.add(LyricLine(it.t, end, words))
        }
        return lines
    }
}
