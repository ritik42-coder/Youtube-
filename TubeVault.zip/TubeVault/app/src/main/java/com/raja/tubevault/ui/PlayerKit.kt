package com.raja.tubevault.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BrightnessMedium
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.VolumeDown
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.raja.tubevault.core.AudioFx
import com.raja.tubevault.core.DownloadItem
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

// ================================================================= speed maths

internal const val SPEED_MIN = 0.25f
internal const val SPEED_MAX = 8f
internal val SPEED_PRESETS = listOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 2.5f, 3f, 4f, 5f, 6f, 8f)

/** The speed slider is logarithmic so 0.25x-1x gets as much room as 2x-8x. */
internal fun speedToFrac(s: Float): Float =
    (ln(s.coerceIn(SPEED_MIN, SPEED_MAX) / SPEED_MIN) / ln(SPEED_MAX / SPEED_MIN)).coerceIn(0f, 1f)

internal fun fracToSpeed(f: Float): Float = SPEED_MIN * (SPEED_MAX / SPEED_MIN).pow(f.coerceIn(0f, 1f))

internal fun snapSpeed(s: Float): Float = (s * 20f).roundToInt() / 20f

internal fun fmtSpeed(s: Float): String {
    val t = String.format(Locale.US, "%.2f", s).trimEnd('0').trimEnd('.')
    return t + "x"
}

internal fun fmtTime(ms: Long): String {
    val t = ms.coerceAtLeast(0L) / 1000
    val h = t / 3600
    val m = (t % 3600) / 60
    val s = t % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.US, "%d:%02d", m, s)
}

// ================================================================= small widgets

@Composable
internal fun PlayerIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: androidx.compose.ui.unit.Dp = 44.dp,
    tint: Color = Color.White,
    active: Boolean = false,
    enabled: Boolean = true
) {
    Box(
        modifier
            .size(size)
            .graphicsLayer { alpha = if (enabled) 1f else 0.35f }
            .pressable { if (enabled) onClick() }
            .clip(CircleShape)
            .then(if (active) Modifier.background(AccentBrush) else Modifier.background(Color(0x33FFFFFF))),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(size * 0.5f))
    }
}

// ================================================================= glow slider

/**
 * Premium 0..1 slider: gradient fill, springy glowing thumb that grows while dragging,
 * optional tick dots. Used for speed, volume and brightness.
 */
@Composable
internal fun GlowSlider(
    value: Float,
    onChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    ticks: List<Float> = emptyList(),
    colors: List<Color> = listOf(Pink, Orange),
    onFinished: () -> Unit = {}
) {
    var widthPx by remember { mutableFloatStateOf(1f) }
    var dragging by remember { mutableStateOf(false) }
    val cur by rememberUpdatedState(onChange)
    val fin by rememberUpdatedState(onFinished)
    val haptic = rememberHaptics()
    val grow by animateFloatAsState(if (dragging) 1f else 0f, spring(dampingRatio = 0.5f, stiffness = 400f), label = "gsg")
    val shown by animateFloatAsState(value.coerceIn(0f, 1f), tween(if (dragging) 0 else 200), label = "gsv")

    Box(
        modifier
            .height(44.dp)
            .onSizeChanged { widthPx = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) {
                detectTapGestures { o ->
                    cur((o.x / widthPx).coerceIn(0f, 1f))
                    haptic(HapticFeedbackType.TextHandleMove)
                    fin()
                }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { o ->
                        dragging = true
                        haptic(HapticFeedbackType.TextHandleMove)
                        cur((o.x / widthPx).coerceIn(0f, 1f))
                    },
                    onDragEnd = { dragging = false; fin() },
                    onDragCancel = { dragging = false; fin() },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        cur((change.position.x / widthPx).coerceIn(0f, 1f))
                    }
                )
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cy = size.height / 2f
            val pad = 14.dp.toPx()
            val w = size.width - pad * 2f
            val th = (6f + 5f * grow).dp.toPx()
            val x = pad + w * shown
            drawRoundRect(Color(0x33FFFFFF), Offset(pad, cy - th / 2f), Size(w, th), CornerRadius(th / 2f))
            if (x > pad) {
                drawRoundRect(
                    Brush.horizontalGradient(colors, startX = pad, endX = pad + w),
                    Offset(pad, cy - th / 2f), Size(x - pad, th), CornerRadius(th / 2f)
                )
            }
            for (t in ticks) {
                val tx = pad + w * t
                drawCircle(Color.White.copy(alpha = if (t <= shown) 0.9f else 0.35f), 2.2.dp.toPx(), Offset(tx, cy))
            }
            val gr = (20f + 10f * grow).dp.toPx()
            drawCircle(
                Brush.radialGradient(listOf(colors.last().copy(alpha = 0.55f), Color.Transparent), center = Offset(x, cy), radius = gr),
                gr, Offset(x, cy)
            )
            drawCircle(Color.White, (9f + 3f * grow).dp.toPx(), Offset(x, cy))
            drawCircle(colors.last(), (4.5f + 1.5f * grow).dp.toPx(), Offset(x, cy))
        }
    }
}

// ================================================================= seek bar

/**
 * The hero slider. Buffered track, gradient progress with a moving shimmer,
 * comet-tail sparks behind the thumb while playing, pulsing thumb ring, and a springy
 * time bubble that pops above the thumb while scrubbing.
 */
@Composable
internal fun FancySeekBar(
    positionMs: Long,
    durationMs: Long,
    bufferedMs: Long,
    playing: Boolean,
    onScrubStart: () -> Unit,
    onScrub: (Float) -> Unit,
    onCommit: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var widthPx by remember { mutableFloatStateOf(1f) }
    var dragging by remember { mutableStateOf(false) }
    var dragFrac by remember { mutableFloatStateOf(0f) }
    val haptic = rememberHaptics()
    val density = LocalDensity.current
    val start by rememberUpdatedState(onScrubStart)
    val scrub by rememberUpdatedState(onScrub)
    val commit by rememberUpdatedState(onCommit)

    val dur = durationMs.coerceAtLeast(1L)
    val live = (positionMs.toFloat() / dur).coerceIn(0f, 1f)
    val target = if (dragging) dragFrac else live
    val frac by animateFloatAsState(target, tween(if (dragging) 0 else 110, easing = LinearEasing), label = "sk")
    val grow by animateFloatAsState(if (dragging) 1f else 0f, spring(dampingRatio = 0.5f, stiffness = 380f), label = "skg")
    val bubble by animateFloatAsState(if (dragging) 1f else 0f, spring(dampingRatio = 0.55f, stiffness = 450f), label = "skb")
    val bufFrac by animateFloatAsState((bufferedMs.toFloat() / dur).coerceIn(0f, 1f), tween(300), label = "skbuf")

    val inf = rememberInfiniteTransition(label = "skinf")
    val pulse by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1500, easing = LinearEasing)), label = "skp")
    val flow by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1100, easing = LinearEasing)), label = "skf")
    val shimmer by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "sks")

    val padPx = with(density) { 14.dp.toPx() }
    val bubbleW = with(density) { 70.dp.toPx() }

    Box(
        modifier
            .height(66.dp)
            .onSizeChanged { widthPx = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) {
                detectTapGestures { o ->
                    val f = ((o.x - padPx) / (widthPx - padPx * 2f)).coerceIn(0f, 1f)
                    haptic(HapticFeedbackType.TextHandleMove)
                    commit(f)
                }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { o ->
                        dragging = true
                        dragFrac = ((o.x - padPx) / (widthPx - padPx * 2f)).coerceIn(0f, 1f)
                        haptic(HapticFeedbackType.LongPress)
                        start()
                        scrub(dragFrac)
                    },
                    onDragEnd = { dragging = false; commit(dragFrac) },
                    onDragCancel = { dragging = false; commit(dragFrac) },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        val nf = ((change.position.x - padPx) / (widthPx - padPx * 2f)).coerceIn(0f, 1f)
                        if ((nf * 20f).toInt() != (dragFrac * 20f).toInt()) haptic(HapticFeedbackType.TextHandleMove)
                        dragFrac = nf
                        scrub(nf)
                    }
                )
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cy = size.height - 20.dp.toPx()
            val pad = padPx
            val w = size.width - pad * 2f
            val th = (5f + 5f * grow).dp.toPx()
            val r = CornerRadius(th / 2f)
            val x = pad + w * frac

            // track + buffered
            drawRoundRect(Color(0x30FFFFFF), Offset(pad, cy - th / 2f), Size(w, th), r)
            drawRoundRect(Color(0x45FFFFFF), Offset(pad, cy - th / 2f), Size(w * bufFrac, th), r)

            // played gradient
            if (x > pad + 1f) {
                val fillW = x - pad
                drawRoundRect(
                    Brush.horizontalGradient(listOf(Pink, Orange, Violet), startX = pad, endX = pad + w),
                    Offset(pad, cy - th / 2f), Size(fillW, th), r
                )
                // moving highlight band
                val sx = pad + fillW * shimmer * 1.4f - 30.dp.toPx()
                drawRoundRect(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, Color.White.copy(alpha = 0.55f), Color.Transparent),
                        startX = sx - 36.dp.toPx(), endX = sx + 36.dp.toPx()
                    ),
                    Offset(pad, cy - th / 2f), Size(fillW, th), r
                )
            }

            // comet-tail sparks
            if (playing && !dragging) {
                for (i in 0 until 7) {
                    val t = (flow + i / 7f) % 1f
                    val sx = x - t * 40.dp.toPx()
                    if (sx > pad) {
                        val sy = cy + sin(t * 6.2832f + i * 1.7f) * 7.dp.toPx()
                        drawCircle(
                            Color.White.copy(alpha = (1f - t) * 0.85f),
                            (2.4f * (1f - t) + 0.6f).dp.toPx(), Offset(sx, sy)
                        )
                    }
                }
            }

            // glow + pulsing ring + thumb
            val gr = (22f + 12f * grow).dp.toPx()
            drawCircle(
                Brush.radialGradient(listOf(Pink.copy(alpha = 0.6f), Color.Transparent), center = Offset(x, cy), radius = gr),
                gr, Offset(x, cy)
            )
            if (playing && !dragging) {
                drawCircle(
                    Orange.copy(alpha = (1f - pulse) * 0.55f),
                    (10f + 10f * pulse).dp.toPx(), Offset(x, cy), style = Stroke(1.6.dp.toPx())
                )
            }
            drawCircle(Color.White, (7f + 5f * grow).dp.toPx(), Offset(x, cy))
            drawCircle(Pink, (3.5f + 2.5f * grow).dp.toPx(), Offset(x, cy))
        }

        // time bubble
        if (bubble > 0.01f) {
            val tx = with(density) { padPx + (widthPx - padPx * 2f) * frac - bubbleW / 2f }
            val clamped = tx.coerceIn(0f, (widthPx - bubbleW).coerceAtLeast(0f))
            Box(
                Modifier
                    .offset { IntOffset(clamped.roundToInt(), 0) }
                    .width(70.dp)
                    .height(30.dp)
                    .graphicsLayer {
                        scaleX = bubble
                        scaleY = bubble
                        alpha = bubble.coerceIn(0f, 1f)
                        transformOrigin = TransformOrigin(0.5f, 1f)
                        translationY = -4f * (1f - bubble)
                    }
                    .clip(RoundedCornerShape(50))
                    .background(AccentBrush2),
                contentAlignment = Alignment.Center
            ) {
                Text(fmtTime((dragFrac * dur).toLong()), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}

// ================================================================= speed gauge + panel

@Composable
private fun SpeedGauge(speed: Float, modifier: Modifier = Modifier) {
    val frac by animateFloatAsState(speedToFrac(speed), spring(dampingRatio = 0.6f, stiffness = 260f), label = "gf")
    val shownSpeed by animateFloatAsState(speed, spring(stiffness = 300f), label = "gs")
    val inf = rememberInfiniteTransition(label = "gauge")
    val glow by inf.animateFloat(0.55f, 1f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), androidx.compose.animation.core.RepeatMode.Reverse), label = "gg")

    Box(modifier, contentAlignment = Alignment.BottomCenter) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = 14.dp.toPx()
            val d = min(size.width - sw, (size.height - sw) * 2f)
            val tl = Offset((size.width - d) / 2f, sw / 2f)
            val c = Offset(size.width / 2f, sw / 2f + d / 2f)
            drawArc(Color(0x22FFFFFF), 180f, 180f, false, tl, Size(d, d), style = Stroke(sw, cap = StrokeCap.Round))
            if (frac > 0.002f) {
                drawArc(
                    brush = Brush.sweepGradient(0f to Cyan, 0.5f to Cyan, 0.72f to Violet, 1f to Pink, center = c),
                    startAngle = 180f, sweepAngle = 180f * frac, useCenter = false,
                    topLeft = tl, size = Size(d, d), style = Stroke(sw, cap = StrokeCap.Round)
                )
            }
            // preset ticks
            for (p in SPEED_PRESETS) {
                val a = PI.toFloat() * (1f + speedToFrac(p))
                val r1 = d / 2f - sw * 1.1f
                val r2 = d / 2f - sw * 1.6f
                drawLine(
                    Color.White.copy(alpha = if (abs(p - 1f) < 0.001f) 0.8f else 0.3f),
                    Offset(c.x + r1 * cos(a), c.y + r1 * sin(a)),
                    Offset(c.x + r2 * cos(a), c.y + r2 * sin(a)),
                    strokeWidth = if (abs(p - 1f) < 0.001f) 2.5.dp.toPx() else 1.5.dp.toPx(), cap = StrokeCap.Round
                )
            }
            val a = PI.toFloat() * (1f + frac)
            val nx = c.x + (d / 2f) * cos(a)
            val ny = c.y + (d / 2f) * sin(a)
            drawCircle(
                Brush.radialGradient(listOf(Pink.copy(alpha = 0.7f * glow), Color.Transparent), center = Offset(nx, ny), radius = 26.dp.toPx()),
                26.dp.toPx(), Offset(nx, ny)
            )
            drawCircle(Color.White, 8.dp.toPx(), Offset(nx, ny))
        }
        Text(
            fmtSpeed(shownSpeed),
            style = TextStyle(brush = AccentBrush2, fontSize = 38.sp, fontWeight = FontWeight.Black),
            modifier = Modifier.padding(bottom = 6.dp)
        )
    }
}

@Composable
private fun SpeedChip(p: Float, selected: Boolean, onClick: () -> Unit) {
    val sc by animateFloatAsState(if (selected) 1.1f else 1f, spring(dampingRatio = 0.5f, stiffness = 500f), label = "chip")
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .pressable(onClick)
            .clip(shape)
            .then(if (selected) Modifier.background(AccentBrush) else Modifier.background(Glass))
            .border(BorderStroke(1.dp, if (selected) Color.Transparent else GlassBorder), shape)
            .padding(horizontal = 16.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(fmtSpeed(p), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

@Composable
internal fun SpeedPanelContent(
    speed: Float,
    pitchLock: Boolean,
    onSpeed: (Float) -> Unit,
    onPitchLock: (Boolean) -> Unit
) {
    val haptic = rememberHaptics()
    val focus = LocalFocusManager.current
    var text by remember { mutableStateOf("") }
    var note by remember { mutableStateOf<String?>(null) }
    var focused by remember { mutableStateOf(false) }

    fun apply() {
        val v = text.trim().replace(',', '.').trimEnd('x', 'X').toFloatOrNull()
        if (v == null || v <= 0f) {
            note = "Type a number, for example 1.35"
            return
        }
        val c = v.coerceIn(0.1f, 8f)
        note = if (c != v) "Limited to 0.1x - 8x" else null
        onSpeed((c * 100f).roundToInt() / 100f)
        text = ""
        focus.clearFocus()
        haptic(HapticFeedbackType.LongPress)
    }

    Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Playback speed", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
            AnimatedVisibility(abs(speed - 1f) > 0.001f, enter = fadeIn() + scaleIn(), exit = fadeOut() + scaleOut()) {
                Box(
                    Modifier
                        .pressable { onSpeed(1f); haptic(HapticFeedbackType.LongPress) }
                        .clip(RoundedCornerShape(50))
                        .background(Glass)
                        .border(BorderStroke(1.dp, GlassBorder), RoundedCornerShape(50))
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) { Text("Reset to 1x", color = TextHi, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
            }
        }

        SpeedGauge(speed, Modifier.fillMaxWidth().height(118.dp))

        Column {
            GlowSlider(
                value = speedToFrac(speed),
                onChange = { onSpeed(snapSpeed(fracToSpeed(it)).coerceIn(SPEED_MIN, SPEED_MAX)) },
                modifier = Modifier.fillMaxWidth(),
                ticks = SPEED_PRESETS.map { speedToFrac(it) },
                colors = listOf(Cyan, Violet, Pink)
            )
            Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("0.25x", color = TextLo, fontSize = 11.sp)
                Text("1x", color = TextLo, fontSize = 11.sp)
                Text("8x", color = TextLo, fontSize = 11.sp)
            }
        }

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            items(SPEED_PRESETS) { p ->
                SpeedChip(p, abs(p - speed) < 0.001f) {
                    haptic(HapticFeedbackType.TextHandleMove)
                    onSpeed(p)
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PlayerIconButton(Icons.Rounded.Remove, {
                onSpeed(((speed - 0.05f).coerceAtLeast(0.1f) * 100f).roundToInt() / 100f)
            }, size = 42.dp)
            val bc = if (focused) Pink.copy(alpha = 0.9f) else GlassBorder
            Box(
                Modifier
                    .weight(1f)
                    .height(42.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Glass)
                    .border(BorderStroke(1.dp, bc), RoundedCornerShape(50))
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                if (text.isEmpty()) Text("Custom speed  (0.1 - 8)", color = TextLo, fontSize = 13.sp)
                BasicTextField(
                    value = text,
                    onValueChange = { s -> text = s.filter { it.isDigit() || it == '.' || it == ',' }.take(6); note = null },
                    singleLine = true,
                    textStyle = TextStyle(color = TextHi, fontSize = 15.sp, fontWeight = FontWeight.SemiBold),
                    cursorBrush = SolidColor(Pink),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { apply() }),
                    modifier = Modifier.fillMaxWidth().onFocusChanged { focused = it.isFocused }
                )
            }
            Box(
                Modifier
                    .height(42.dp)
                    .pressable { apply() }
                    .clip(RoundedCornerShape(50))
                    .background(AccentBrush)
                    .padding(horizontal = 18.dp),
                contentAlignment = Alignment.Center
            ) { Text("Set", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
            PlayerIconButton(Icons.Rounded.Add, {
                onSpeed(((speed + 0.05f).coerceAtMost(8f) * 100f).roundToInt() / 100f)
            }, size = 42.dp)
        }
        AnimatedVisibility(note != null) {
            Text(note ?: "", color = Orange, fontSize = 12.sp)
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Keep voice pitch natural", color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Text("Turn off for a chipmunk / slow-mo voice effect", color = TextLo, fontSize = 12.sp)
            }
            PremiumSwitch(pitchLock, onPitchLock)
        }
        Spacer(Modifier.height(14.dp))
    }
}

// ================================================================= sound panel

@Composable
internal fun SoundPanelContent(
    volume: Float,
    muted: Boolean,
    brightness: Float,
    preset: Int,
    bass: Int,
    onVolume: (Float) -> Unit,
    onMute: () -> Unit,
    onBrightness: (Float) -> Unit,
    onPreset: (Int) -> Unit,
    onBass: (Int) -> Unit
) {
    val boosted = volume > 1.001f
    val pct = (volume * 100f).roundToInt()
    val icon = when {
        muted || volume <= 0.001f -> Icons.Rounded.VolumeOff
        volume < 0.5f -> Icons.Rounded.VolumeDown
        else -> Icons.Rounded.VolumeUp
    }
    Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Sound & display", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            PlayerIconButton(icon, onMute, size = 46.dp, active = muted)
            Column(Modifier.weight(1f)) {
                Row {
                    Text("Volume", color = TextLo, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Text(
                        if (muted) "Muted" else "$pct%",
                        color = if (boosted && !muted) Orange else TextHi,
                        fontWeight = FontWeight.Bold, fontSize = 13.sp
                    )
                }
                GlowSlider(
                    value = if (muted) 0f else volume / 2f,
                    onChange = { onVolume((it * 2f * 20f).roundToInt() / 20f) },
                    modifier = Modifier.fillMaxWidth(),
                    ticks = listOf(0.5f),
                    colors = if (boosted) listOf(Orange, Pink) else listOf(Cyan, Violet)
                )
            }
        }
        AnimatedVisibility(boosted && !muted) {
            Text(
                "Boost above 100% uses a loudness enhancer. Lower it if the sound distorts.",
                color = Orange, fontSize = 12.sp
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.size(46.dp).clip(CircleShape).background(Color(0x33FFFFFF)),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.BrightnessMedium, null, tint = Color.White, modifier = Modifier.size(22.dp)) }
            Column(Modifier.weight(1f)) {
                Row {
                    Text("Brightness", color = TextLo, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Text("${(brightness * 100f).roundToInt()}%", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                GlowSlider(
                    value = brightness,
                    onChange = { onBrightness(it.coerceIn(0.02f, 1f)) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = listOf(Orange, Color(0xFFFFE08A))
                )
            }
        }

        // ------------------------------------------------------------ studio
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Studio", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(Modifier.width(8.dp))
            Text(
                AudioFx.PRESETS[preset.coerceIn(0, AudioFx.PRESETS.size - 1)],
                color = Orange, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
            )
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(AudioFx.PRESETS.size) { i ->
                val sel = i == preset
                Box(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .then(
                            if (sel) Modifier.background(AccentBrush)
                            else Modifier.background(Color(0x22FFFFFF))
                        )
                        .clickable { onPreset(i) }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        AudioFx.PRESETS[i], color = Color.White, fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.size(46.dp).clip(CircleShape).background(Color(0x33FFFFFF)),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.VolumeUp, null, tint = Color.White, modifier = Modifier.size(22.dp)) }
            Column(Modifier.weight(1f)) {
                Row {
                    Text("Bass boost", color = TextLo, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Text("$bass%", color = if (bass > 0) Orange else TextHi, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                GlowSlider(
                    value = bass / 100f,
                    onChange = { onBass((it * 100f).roundToInt()) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = listOf(Violet, Pink)
                )
            }
        }
        Spacer(Modifier.height(14.dp))
    }
}

// ================================================================= bottom sheet

@Composable
internal fun PlayerPanel(visible: Boolean, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val cfg = LocalConfiguration.current
    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(visible, enter = fadeIn(tween(220)), exit = fadeOut(tween(200))) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color(0x99000000))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onDismiss() }
            )
        }
        AnimatedVisibility(
            visible,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(spring(dampingRatio = 0.82f, stiffness = 330f)) { it } + fadeIn(tween(180)),
            exit = slideOutVertically(tween(240)) { it } + fadeOut(tween(160))
        ) {
            Column(
                Modifier
                    .widthIn(max = 560.dp)
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .imePadding()
                    .heightIn(max = (cfg.screenHeightDp * 0.94f).dp)
                    .clip(RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp))
                    .background(Color(0xF2111119))
                    .border(
                        BorderStroke(1.dp, GlassBorder),
                        RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp)
                    )
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                    .verticalScroll(rememberScrollState())
            ) {
                Box(
                    Modifier
                        .padding(top = 10.dp, bottom = 14.dp)
                        .align(Alignment.CenterHorizontally)
                        .size(width = 42.dp, height = 4.dp)
                        .clip(RoundedCornerShape(50))
                        .background(Color(0x55FFFFFF))
                )
                content()
            }
        }
    }
}

@Composable
internal fun PlayerTile(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    active: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val sc by animateFloatAsState(if (active) 1.03f else 1f, spring(dampingRatio = 0.5f, stiffness = 500f), label = "tile")
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .graphicsLayer { scaleX = sc; scaleY = sc }
            .pressable(onClick)
            .clip(shape)
            .then(if (active) Modifier.background(AccentBrush) else Modifier.background(Glass))
            .border(BorderStroke(1.dp, if (active) Color.Transparent else GlassBorder), shape)
            .padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(24.dp))
        Text(label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

// ================================================================= HUD + ripples

/** kind: 0 brightness, 1 volume, 2 seek, 3 toast */
internal data class Hud(val kind: Int, val value: Float, val text: String, val sub: String = "")

@Composable
internal fun BoxScopeHud(hud: Hud?, last: Hud?, modifier: Modifier = Modifier) {
    val h = hud ?: last
    Box(modifier.fillMaxSize()) {
        AnimatedVisibility(
            visible = hud != null && h != null && (h.kind == 0 || h.kind == 1),
            modifier = Modifier
                .align(if (h?.kind == 0) Alignment.CenterStart else Alignment.CenterEnd)
                .padding(horizontal = 28.dp),
            enter = fadeIn(tween(150)) + scaleIn(spring(dampingRatio = 0.6f, stiffness = 400f), 0.7f),
            exit = fadeOut(tween(250)) + scaleOut(tween(250), 0.8f)
        ) {
            if (h != null) {
                val fill by animateFloatAsState(h.value.coerceIn(0f, 1f), tween(80), label = "hudfill")
                Column(
                    Modifier
                        .width(58.dp)
                        .height(190.dp)
                        .clip(RoundedCornerShape(29.dp))
                        .background(Color(0xCC101018))
                        .border(BorderStroke(1.dp, GlassBorder), RoundedCornerShape(29.dp))
                        .padding(vertical = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        when {
                            h.kind == 0 -> Icons.Rounded.BrightnessMedium
                            h.value <= 0.001f -> Icons.Rounded.VolumeOff
                            h.value < 0.25f -> Icons.Rounded.VolumeDown
                            else -> Icons.Rounded.VolumeUp
                        }, null, tint = Color.White, modifier = Modifier.size(22.dp)
                    )
                    Box(
                        Modifier
                            .weight(1f)
                            .padding(vertical = 10.dp)
                            .width(8.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color(0x33FFFFFF)),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .fillMaxHeight(fill)
                                .background(
                                    Brush.verticalGradient(
                                        if (h.kind == 1 && h.sub == "boost") listOf(Pink, Orange) else listOf(Violet, Cyan)
                                    )
                                )
                        )
                    }
                    Text(h.text, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        AnimatedVisibility(
            visible = hud != null && h != null && h.kind == 2,
            modifier = Modifier.align(Alignment.Center),
            enter = fadeIn(tween(120)) + scaleIn(spring(dampingRatio = 0.6f, stiffness = 450f), 0.8f),
            exit = fadeOut(tween(250)) + scaleOut(tween(250), 0.9f)
        ) {
            if (h != null) {
                Column(
                    Modifier
                        .clip(RoundedCornerShape(26.dp))
                        .background(Color(0xCC101018))
                        .border(BorderStroke(1.dp, GlassBorder), RoundedCornerShape(26.dp))
                        .padding(horizontal = 26.dp, vertical = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(h.text, style = TextStyle(brush = AccentBrush2, fontSize = 34.sp, fontWeight = FontWeight.Black))
                    Text(h.sub, color = TextLo, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        AnimatedVisibility(
            visible = hud != null && h != null && h.kind == 3,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 84.dp),
            enter = fadeIn(tween(150)) + slideInVertically(spring(dampingRatio = 0.7f, stiffness = 400f)) { -it },
            exit = fadeOut(tween(220)) + slideOutVertically(tween(220)) { -it }
        ) {
            if (h != null) {
                Box(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Color(0xDD101018))
                        .border(BorderStroke(1.dp, GlassBorder), RoundedCornerShape(50))
                        .padding(horizontal = 18.dp, vertical = 9.dp)
                ) { Text(h.text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
            }
        }
    }
}

/** Double-tap seek feedback: expanding half-circle with sequential chevrons. */
@Composable
internal fun SeekRipple(side: Int, seconds: Int, id: Long, modifier: Modifier = Modifier) {
    val p = remember { Animatable(0f) }
    LaunchedEffect(id) {
        p.snapTo(0f)
        p.animateTo(1f, tween(650, easing = FastOutSlowInEasing))
    }
    val shape = if (side < 0) RoundedCornerShape(topEndPercent = 50, bottomEndPercent = 50)
    else RoundedCornerShape(topStartPercent = 50, bottomStartPercent = 50)
    Box(modifier.clip(shape), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = if (side < 0) 0f else size.width
            val r = size.maxDimension * (0.3f + 0.95f * p.value)
            drawCircle(Color.White.copy(alpha = 0.18f * (1f - p.value * 0.7f)), r, Offset(cx, size.height / 2f))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row {
                for (i in 0 until 3) {
                    val idx = if (side < 0) 2 - i else i
                    val a = (1f - abs(p.value * 3.2f - idx - 0.6f)).coerceIn(0.25f, 1f)
                    Icon(
                        Icons.Rounded.PlayArrow, null, tint = Color.White.copy(alpha = a),
                        modifier = Modifier
                            .size(26.dp)
                            .graphicsLayer { rotationZ = if (side < 0) 180f else 0f }
                    )
                }
            }
            Text("$seconds seconds", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
    }
}

/** "Hold = 2x" pill with racing chevrons. */
@Composable
internal fun HoldBoostPill(label: String, modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "hold")
    val t by inf.animateFloat(0f, 3f, infiniteRepeatable(tween(750, easing = LinearEasing)), label = "ht")
    Row(
        modifier
            .clip(RoundedCornerShape(50))
            .background(Color(0xDD101018))
            .border(BorderStroke(1.dp, Pink.copy(alpha = 0.7f)), RoundedCornerShape(50))
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(label, color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp)
        Spacer(Modifier.width(4.dp))
        for (i in 0 until 3) {
            val a = (1f - abs(t - i - 0.5f)).coerceIn(0.2f, 1f)
            Icon(Icons.Rounded.PlayArrow, null, tint = Pink.copy(alpha = a), modifier = Modifier.size(16.dp))
        }
    }
}

// ================================================================= audio stage

/**
 * Shown instead of a video surface for audio files: blurred cover, a vinyl that spins
 * in sync with the playback speed, expanding sound rings and a live equaliser.
 */
@Composable
internal fun AudioStage(item: DownloadItem, playing: Boolean, speed: Float, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val clock = remember { mutableFloatStateOf(0f) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(playing, speed) {
        if (playing) {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                clock.floatValue += (now - last) / 1_000_000_000f * speed.coerceIn(0.25f, 4f)
                last = now
                tick++
            }
        }
    }
    val energy by animateFloatAsState(if (playing) 1f else 0.06f, tween(600), label = "energy")

    Box(modifier.fillMaxSize().background(Color(0xFF07070D))) {
        AsyncImage(
            model = ImageRequest.Builder(ctx).data(item.thumbnail).build(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize().blur(48.dp).graphicsLayer { alpha = 0.5f }
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0x99000000), Color(0xEE07070D)))
            )
        )
        Column(
            Modifier.fillMaxSize().padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(Modifier.size(250.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    for (i in 0 until 3) {
                        val ph = ((clock.floatValue * 0.5f + i / 3f) % 1f)
                        val rr = size.minDimension * (0.34f + 0.16f * ph * 1.4f)
                        drawCircle(
                            Pink.copy(alpha = (1f - ph) * 0.35f * energy), rr, center,
                            style = Stroke(2.dp.toPx())
                        )
                    }
                }
                Box(
                    Modifier
                        .size(170.dp)
                        .graphicsLayer { rotationZ = clock.floatValue * 28f }
                        .clip(CircleShape)
                        .background(Color(0xFF14141E))
                        .border(BorderStroke(3.dp, Color(0x33FFFFFF)), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = ImageRequest.Builder(ctx).data(item.thumbnail).crossfade(true).build(),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize().padding(10.dp).clip(CircleShape)
                    )
                    Box(Modifier.size(26.dp).clip(CircleShape).background(Color(0xFF07070D)))
                }
            }
            Spacer(Modifier.height(18.dp))
            Canvas(Modifier.fillMaxWidth().height(64.dp)) {
                // real spectrum of the song when we are allowed to listen to it,
                // a soft wave otherwise
                val frame = tick
                val bands = AudioFx.bands()
                val live = AudioFx.hasVisualizer
                val n = 26
                val gap = 4.dp.toPx()
                val bw = (size.width - gap * (n - 1)) / n
                for (i in 0 until n) {
                    val v = if (live) {
                        bands[(i * AudioFx.BANDS / n).coerceIn(0, AudioFx.BANDS - 1)]
                    } else {
                        val t = clock.floatValue * 3.2f
                        (0.5f + 0.5f * sin(t + i * 0.55f)) *
                            (0.55f + 0.45f * sin(t * 0.63f + i * 1.3f).let { abs(it) })
                    }
                    val hh = (size.height * (0.08f + 0.92f * v * energy)).coerceAtLeast(3.dp.toPx())
                    drawRoundRect(
                        Brush.verticalGradient(listOf(Orange, Pink), startY = size.height - hh, endY = size.height),
                        Offset(i * (bw + gap), size.height - hh), Size(bw, hh), CornerRadius(bw / 2f)
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
            Text(
                item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp,
                textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            if (item.uploader.isNotEmpty()) {
                Text(item.uploader, color = TextLo, fontSize = 13.sp, maxLines = 1)
            }
        }
    }
}
