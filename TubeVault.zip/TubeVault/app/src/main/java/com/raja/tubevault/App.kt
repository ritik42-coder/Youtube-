package com.raja.tubevault

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.raja.tubevault.core.Downloads
import com.raja.tubevault.core.NpDownloader
import com.raja.tubevault.ui.AppSettings
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.localization.Localization

class App : Application(), coil.ImageLoaderFactory {
    /** Coil also shows encrypted vault thumbnails (decrypted in memory only). */
    override fun newImageLoader(): coil.ImageLoader = coil.ImageLoader.Builder(this)
        .components { add(com.raja.tubevault.core.VaultThumbFetcher.Factory()) }
        .crossfade(true)
        .build()

    override fun onCreate() {
        super.onCreate()
        NewPipe.init(NpDownloader.instance, Localization("en", "US"))
        com.raja.tubevault.core.Vault.init(this)
        Downloads.init(this)
        com.raja.tubevault.core.WidgetUi.start(this)
        com.raja.tubevault.core.AiStems.init(this)
        com.raja.tubevault.core.UniversalRepo.warmUp(this)
        AppSettings.init(this)
        com.raja.tubevault.ui.Premium.init(this)
        com.raja.tubevault.core.Playlists.init(this)
        com.raja.tubevault.core.PlayStats.init(this)
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            private var started = 0
            override fun onActivityStarted(activity: android.app.Activity) {
                started++
                com.raja.tubevault.core.AppState.foreground = true
            }

            override fun onActivityStopped(activity: android.app.Activity) {
                started = (started - 1).coerceAtLeast(0)
                com.raja.tubevault.core.AppState.foreground = started > 0
                // Leaving TubeVault locks the Vault straight away
                if (started == 0) {
                    com.raja.tubevault.core.Vault.lock()
                    // a Vault video stays private: close the full-screen player (music keeps playing)
                    val cur = com.raja.tubevault.core.PlayerHub.current
                    if (cur != null && cur.place == com.raja.tubevault.core.Place.VAULT && !cur.isAudio &&
                        com.raja.tubevault.ui.PlayerHost.request != null && !com.raja.tubevault.ui.PlayerHost.inPip
                    ) com.raja.tubevault.ui.PlayerHost.close()
                }
            }

            override fun onActivityCreated(activity: android.app.Activity, savedInstanceState: android.os.Bundle?) {}
            override fun onActivityResumed(activity: android.app.Activity) {}
            override fun onActivityPaused(activity: android.app.Activity) {}
            override fun onActivitySaveInstanceState(activity: android.app.Activity, outState: android.os.Bundle) {}
            override fun onActivityDestroyed(activity: android.app.Activity) {}
        })
        createChannels()
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_PROGRESS, "Downloads in progress", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_DONE, "Finished downloads", NotificationManager.IMPORTANCE_DEFAULT)
        )
        nm.createNotificationChannel(
            NotificationChannel(com.raja.tubevault.core.Updater.CH_UPDATE, "App updates", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    companion object {
        const val CH_PROGRESS = "tv_progress"
        const val CH_DONE = "tv_done"
    }
}
