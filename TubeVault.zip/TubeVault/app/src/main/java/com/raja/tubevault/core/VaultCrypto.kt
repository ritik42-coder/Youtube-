package com.raja.tubevault.core

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.math.BigInteger
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Vault encryption.
 *  - Every file is AES-256 encrypted (CTR mode: the player can jump to any second without
 *    decrypting the whole file). File = 16-byte random IV + ciphertext.
 *  - The AES key is random and itself encrypted by a key that lives in the phone's
 *    hardware-backed Android Keystore, so the files are useless if copied off the phone.
 *  - The password is never stored: only a salted PBKDF2-SHA256 hash.
 */
object VaultCrypto {
    private const val KS = "AndroidKeyStore"
    private const val ALIAS = "tubevault_vault_master"
    private const val PREFS = "tv_vault_keys"
    private val rnd = SecureRandom()
    @Volatile private var cached: SecretKey? = null

    fun key(ctx: Context): SecretKey {
        cached?.let { return it }
        synchronized(this) {
            cached?.let { return it }
            val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val wrapped = prefs.getString("wrapped", null)
            val raw: ByteArray = if (wrapped != null) {
                val b = Base64.decode(wrapped, Base64.NO_WRAP)
                val c = Cipher.getInstance("AES/GCM/NoPadding")
                c.init(Cipher.DECRYPT_MODE, master(), GCMParameterSpec(128, b, 0, 12))
                c.doFinal(b, 12, b.size - 12)
            } else {
                val fresh = ByteArray(32).also { rnd.nextBytes(it) }
                val c = Cipher.getInstance("AES/GCM/NoPadding")
                c.init(Cipher.ENCRYPT_MODE, master())
                val out = c.iv + c.doFinal(fresh)
                prefs.edit().putString("wrapped", Base64.encodeToString(out, Base64.NO_WRAP)).commit()
                fresh
            }
            return SecretKeySpec(raw, "AES").also { cached = it }
        }
    }

    private fun master(): SecretKey {
        val ks = KeyStore.getInstance(KS).apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KS)
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    /** Forget the key completely (Reset Vault). */
    fun destroy(ctx: Context) {
        cached = null
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().commit()
        try {
            KeyStore.getInstance(KS).apply { load(null) }.deleteEntry(ALIAS)
        } catch (_: Throwable) {
        }
    }

    // ----------------------------------------------------------- streaming files (AES-CTR)

    /** Cipher positioned at plaintext byte [position] (random access). */
    fun ctr(key: SecretKey, iv: ByteArray, position: Long, mode: Int): Cipher {
        val block = position / 16
        val counter = BigInteger(1, iv).add(BigInteger.valueOf(block)).mod(BigInteger.ONE.shiftLeft(128))
        val bytes = counter.toByteArray()
        val ivAt = ByteArray(16)
        val n = minOf(16, bytes.size)
        System.arraycopy(bytes, bytes.size - n, ivAt, 16 - n, n)
        val c = Cipher.getInstance("AES/CTR/NoPadding")
        c.init(mode, key, IvParameterSpec(ivAt))
        val skip = (position % 16).toInt()
        if (skip > 0) c.update(ByteArray(skip))
        return c
    }

    fun encrypt(ctx: Context, input: InputStream, dest: File, onBytes: (Long) -> Unit = {}) {
        val iv = ByteArray(16).also { rnd.nextBytes(it) }
        val c = ctr(key(ctx), iv, 0, Cipher.ENCRYPT_MODE)
        FileOutputStream(dest).use { out ->
            out.write(iv)
            val buf = ByteArray(256 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                c.update(buf, 0, n)?.let { out.write(it) }
                onBytes(n.toLong())
            }
            c.doFinal()?.takeIf { it.isNotEmpty() }?.let { out.write(it) }
        }
    }

    fun decrypt(ctx: Context, src: File, out: OutputStream) {
        RandomAccessFile(src, "r").use { raf ->
            val iv = ByteArray(16)
            raf.readFully(iv)
            val c = ctr(key(ctx), iv, 0, Cipher.DECRYPT_MODE)
            val buf = ByteArray(256 * 1024)
            while (true) {
                val n = raf.read(buf)
                if (n < 0) break
                c.update(buf, 0, n)?.let { out.write(it) }
            }
        }
    }

    // ----------------------------------------------------------- small blobs (AES-GCM, authenticated)

    fun seal(ctx: Context, plain: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        val iv = ByteArray(12).also { rnd.nextBytes(it) }
        c.init(Cipher.ENCRYPT_MODE, key(ctx), GCMParameterSpec(128, iv))
        return iv + c.doFinal(plain)
    }

    fun open(ctx: Context, blob: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(ctx), GCMParameterSpec(128, blob, 0, 12))
        return c.doFinal(blob, 12, blob.size - 12)
    }

    // ----------------------------------------------------------- password

    fun newSalt(): ByteArray = ByteArray(16).also { rnd.nextBytes(it) }

    fun hash(password: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, 60_000, 256)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    fun same(a: ByteArray, b: ByteArray) = MessageDigest.isEqual(a, b)
}
