package com.raja.tubevault.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.raja.tubevault.core.Downloads
import com.raja.tubevault.core.Errors
import com.raja.tubevault.core.FormatOption
import com.raja.tubevault.core.MediaInfo
import com.raja.tubevault.core.YouTubeRepo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface FetchState {
    data object Idle : FetchState
    data object Loading : FetchState
    data class Error(val message: String) : FetchState
    data class Ready(val info: MediaInfo) : FetchState
}

class MainViewModel : ViewModel() {
    var url by mutableStateOf("")
    var state by mutableStateOf<FetchState>(FetchState.Idle)
    var page by mutableIntStateOf(0)
    var formatTab by mutableIntStateOf(0)
    var queued by mutableStateOf<Set<String>>(emptySet())
    private var job: Job? = null

    fun onSharedText(text: String) {
        url = extractUrl(text)
        page = 0
        fetch()
    }

    fun fetch() {
        val link = extractUrl(url).trim()
        if (link.isEmpty()) return
        url = link
        job?.cancel()
        job = viewModelScope.launch {
            state = FetchState.Loading
            state = try {
                val info = withContext(Dispatchers.IO) { YouTubeRepo.fetch(link) }
                queued = emptySet()
                formatTab = 0
                FetchState.Ready(info)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                FetchState.Error(Errors.friendly(e))
            }
        }
    }

    fun clear() {
        job?.cancel()
        url = ""
        state = FetchState.Idle
    }

    fun download(info: MediaInfo, opt: FormatOption) {
        if (opt.key in queued) return
        Downloads.enqueue(info, opt)
        queued = queued + opt.key
    }

    private fun extractUrl(text: String): String {
        val m = Regex("https?://[^\\s]+").find(text)
        return (m?.value ?: text).trim()
    }
}
