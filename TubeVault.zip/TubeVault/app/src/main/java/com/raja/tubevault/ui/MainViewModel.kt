package com.raja.tubevault.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.raja.tubevault.core.Downloads
import com.raja.tubevault.core.Errors
import com.raja.tubevault.core.FormatOption
import com.raja.tubevault.core.MediaInfo
import com.raja.tubevault.core.YouTubeRepo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface FetchState {
    data object Idle : FetchState
    data object Loading : FetchState
    data class Error(val message: String) : FetchState
    data class Ready(val info: MediaInfo) : FetchState
}

/** A glowing orb that flies from a tapped download button to the Library tab. */
data class Launch(val id: Long, val from: Offset, val audio: Boolean)

class MainViewModel : ViewModel() {
    var url by mutableStateOf("")
    var state by mutableStateOf<FetchState>(FetchState.Idle)
    var page by mutableIntStateOf(0)
    var formatTab by mutableIntStateOf(0)
    var queued by mutableStateOf<Set<String>>(emptySet())
    /** Dominant colour of the current video thumbnail – tints the live background. */
    var ambient by mutableStateOf<Color?>(null)
    var clipLink by mutableStateOf<String?>(null)
    var lastClip by mutableStateOf("")
    var launches by mutableStateOf<List<Launch>>(emptyList())
    private var launchId = 0L
    private var dismissedClip: String? = null
    private var job: Job? = null

    fun checkClipboard(ctx: Context) {
        try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip ?: return
            if (clip.itemCount == 0) return
            val text = clip.getItemAt(0).coerceToText(ctx)?.toString() ?: return
            val link = extractUrl(text)
            val isYt = Regex("https?://([\\w-]+\\.)?(youtube\\.com|youtu\\.be)/\\S+").containsMatchIn(link)
            if (isYt && link != url && link != dismissedClip && link != clipLink) {
                lastClip = link
                clipLink = link
            }
        } catch (_: Throwable) {
        }
    }

    fun useClip() {
        val l = clipLink ?: return
        clipLink = null
        page = 0
        url = l
        fetch()
    }

    fun dismissClip() {
        dismissedClip = clipLink
        clipLink = null
    }

    fun removeLaunch(id: Long) {
        launches = launches.filterNot { it.id == id }
    }

    fun onSharedText(text: String) {
        url = extractUrl(text)
        page = 0
        fetch()
    }

    fun fetch() {
        val link = extractUrl(url).trim()
        if (link.isEmpty()) return
        url = link
        clipLink = null
        ambient = null
        job?.cancel()
        job = viewModelScope.launch {
            state = FetchState.Loading
            state = try {
                val info = withContext(Dispatchers.IO) { YouTubeRepo.fetch(link) }
                queued = emptySet()
                formatTab = 0
                FetchState.Ready(info)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                FetchState.Error(Errors.friendly(e))
            }
        }
    }

    fun clear() {
        job?.cancel()
        url = ""
        ambient = null
        state = FetchState.Idle
    }

    fun download(info: MediaInfo, opt: FormatOption, origin: Offset = Offset.Zero) {
        if (opt.key in queued) return
        Downloads.enqueue(info, opt)
        queued = queued + opt.key
        if (origin != Offset.Zero) launches = launches + Launch(launchId++, origin, opt.isAudio)
    }

    private fun extractUrl(text: String): String {
        val m = Regex("https?://[^\\s]+").find(text)
        return (m?.value ?: text).trim()
    }
}
