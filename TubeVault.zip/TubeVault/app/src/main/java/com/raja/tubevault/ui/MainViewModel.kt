package com.raja.tubevault.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.raja.tubevault.core.Downloads
import com.raja.tubevault.core.Errors
import com.raja.tubevault.core.FormatOption
import com.raja.tubevault.core.MediaInfo
import com.raja.tubevault.core.LinkCache
import com.raja.tubevault.core.Place
import com.raja.tubevault.core.YouTubeRepo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface FetchState {
    data object Idle : FetchState
    data object Loading : FetchState
    data class Error(val message: String) : FetchState
    data class Ready(val info: MediaInfo) : FetchState
}

/** A glowing orb that flies from a tapped download button to the Library tab. */
data class Launch(val id: Long, val from: Offset, val audio: Boolean)

class MainViewModel : ViewModel() {
    var url by mutableStateOf("")
    var state by mutableStateOf<FetchState>(FetchState.Idle)
    var page by mutableIntStateOf(0)
    var formatTab by mutableIntStateOf(0)
    var queued by mutableStateOf<Set<String>>(emptySet())
    /** Dominant colour of the current video thumbnail – tints the live background. */
    var ambient by mutableStateOf<Color?>(null)
    var clipLink by mutableStateOf<String?>(null)
    var lastClip by mutableStateOf("")
    var launches by mutableStateOf<List<Launch>>(emptyList())
    /** PDF Mafia ad – shown whenever a download starts (download keeps running underneath). */
    var showAd by mutableStateOf(false)
    private var launchId = 0L
    private var dismissedClip: String? = null
    private var job: Job? = null

    fun checkClipboard(ctx: Context) {
        try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip ?: return
            if (clip.itemCount == 0) return
            val text = clip.getItemAt(0).coerceToText(ctx)?.toString() ?: return
            val link = extractUrl(text)
            // Any video link: YouTube goes to NewPipe, everything else to the universal engine.
            val isLink = Regex("^https?://[\\w.-]+\\.[a-z]{2,}/\\S+", RegexOption.IGNORE_CASE).containsMatchIn(link)
            if (isLink && link != url && link != dismissedClip && link != clipLink) {
                lastClip = link
                clipLink = link
                LinkCache.prefetch(link) // already loading before you tap
            }
        } catch (_: Throwable) {
        }
    }

    /** Home-screen "Paste & download" widget: use whatever link is on the clipboard right now. */
    fun pasteNow(ctx: Context): Boolean {
        try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = cm.primaryClip ?: return false
            if (clip.itemCount == 0) return false
            val text = clip.getItemAt(0)?.coerceToText(ctx)?.toString() ?: return false
            val link = extractUrl(text)
            val isLink = Regex("^https?://[\\w.-]+\\.[a-z]{2,}/\\S+", RegexOption.IGNORE_CASE).containsMatchIn(link)
            if (!isLink) return false
            clipLink = null
            page = 0
            url = link
            fetch()
            return true
        } catch (_: Throwable) {
            return false
        }
    }

    fun useClip() {
        val l = clipLink ?: return
        clipLink = null
        page = 0
        url = l
        fetch()
    }

    fun dismissClip() {
        dismissedClip = clipLink
        clipLink = null
    }

    fun removeLaunch(id: Long) {
        launches = launches.filterNot { it.id == id }
    }

    fun onSharedText(text: String) {
        url = extractUrl(text)
        page = 0
        fetch()
    }

    fun fetch() {
        val link = extractUrl(url).trim()
        if (link.isEmpty()) return
        url = link
        clipLink = null
        ambient = null
        if (com.raja.tubevault.core.PlaylistRepo.isPlaylistUrl(link)) {
            // whole playlist: pick the videos in a sheet
            com.raja.tubevault.core.PlaylistController.open(link)
            return
        }
        job?.cancel()
        job = viewModelScope.launch {
            state = FetchState.Loading
            state = try {
                val info = try {
                    LinkCache.get(link).await()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    LinkCache.drop(link)
                    throw e
                }
                queued = emptySet()
                formatTab = 0
                FetchState.Ready(info)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                FetchState.Error(Errors.friendly(e))
            }
        }
    }

    fun clear() {
        job?.cancel()
        url = ""
        ambient = null
        state = FetchState.Idle
    }

    /** Where the next download is saved (starts at the default from Settings). */
    var place by mutableStateOf(AppSettings.defaultPlace)

    private fun qKey(opt: FormatOption) = opt.key + "|" + place.name
    fun isQueued(opt: FormatOption) = qKey(opt) in queued

    fun download(info: MediaInfo, opt: FormatOption, origin: Offset = Offset.Zero) {
        if (isQueued(opt)) return
        Downloads.enqueue(info, opt, place)
        queued = queued + qKey(opt)
        showAd = !Premium.isPremium
        if (origin != Offset.Zero) launches = launches + Launch(launchId++, origin, opt.isAudio)
    }

    private fun extractUrl(text: String): String {
        val m = Regex("https?://[^\\s]+").find(text)
        return (m?.value ?: text).trim()
    }
}
