package com.raja.tubevault

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.raja.tubevault.core.Downloads
import com.raja.tubevault.ui.AuroraBackground
import com.raja.tubevault.ui.BottomBar
import com.raja.tubevault.ui.HomeScreen
import com.raja.tubevault.ui.LibraryScreen
import com.raja.tubevault.ui.MainViewModel
import com.raja.tubevault.ui.TubeTheme

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        requestPermissions()
        if (savedInstanceState == null) handleIntent(intent)
        setContent { TubeTheme { AppRoot(vm) } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND && i.type?.startsWith("text/") == true) {
            val t = i.getStringExtra(Intent.EXTRA_TEXT)
            if (!t.isNullOrBlank()) vm.onSharedText(t)
        }
    }

    private fun requestPermissions() {
        val need = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT <= 28 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (need.isNotEmpty()) permLauncher.launch(need.toTypedArray())
    }
}

@Composable
fun AppRoot(vm: MainViewModel) {
    val items by Downloads.items.collectAsState()
    val active = items.count { it.status in Downloads.ACTIVE }

    BackHandler(enabled = vm.page == 1) { vm.page = 0 }

    Box(Modifier.fillMaxSize()) {
        AuroraBackground()

        AnimatedContent(
            targetState = vm.page,
            transitionSpec = {
                val dir = if (targetState > initialState) 1 else -1
                (slideInHorizontally(tween(450, easing = FastOutSlowInEasing)) { it / 5 * dir } +
                    fadeIn(tween(450))) togetherWith
                    (slideOutHorizontally(tween(350, easing = FastOutSlowInEasing)) { -it / 5 * dir } +
                        fadeOut(tween(250)))
            },
            label = "page"
        ) { p ->
            if (p == 0) HomeScreen(vm) else LibraryScreen(items)
        }

        BottomBar(
            page = vm.page,
            activeCount = active,
            onSelect = { vm.page = it },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 14.dp)
        )
    }
}
