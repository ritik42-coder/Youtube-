package com.raja.tubevault

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.raja.tubevault.core.Downloads
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import com.raja.tubevault.core.Status
import com.raja.tubevault.ui.Banner
import com.raja.tubevault.ui.BannerHost
import com.raja.tubevault.ui.FlyOrb
import com.raja.tubevault.ui.IntroSplash
import com.raja.tubevault.ui.LiveBackground
import com.raja.tubevault.ui.SettingsPanel
import com.raja.tubevault.ui.rememberHaptics
import kotlinx.coroutines.delay
import com.raja.tubevault.ui.BottomBar
import com.raja.tubevault.ui.HomeScreen
import com.raja.tubevault.ui.LibraryScreen
import com.raja.tubevault.ui.MainViewModel
import com.raja.tubevault.ui.TubeTheme

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        requestPermissions()
        if (savedInstanceState == null) handleIntent(intent)
        setContent { TubeTheme { AppRoot(vm) } }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) vm.checkClipboard(applicationContext)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND && i.type?.startsWith("text/") == true) {
            val t = i.getStringExtra(Intent.EXTRA_TEXT)
            if (!t.isNullOrBlank()) vm.onSharedText(t)
        }
    }

    private fun requestPermissions() {
        val need = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT <= 28 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (need.isNotEmpty()) permLauncher.launch(need.toTypedArray())
    }
}

@Composable
fun AppRoot(vm: MainViewModel) {
    val items by Downloads.items.collectAsState()
    val active = items.count { it.status in Downloads.ACTIVE }
    val haptic = rememberHaptics()

    var reveal by rememberSaveable { mutableStateOf(false) }
    var splashGone by rememberSaveable { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }
    var libPos by remember { mutableStateOf(Offset.Zero) }
    var bump by remember { mutableIntStateOf(0) }
    var pulse by remember { mutableIntStateOf(0) }
    var bannerSeq by remember { mutableIntStateOf(0) }
    var banner by remember { mutableStateOf<Banner?>(null) }
    var bannerVisible by remember { mutableStateOf(false) }

    BackHandler(enabled = settingsOpen) { settingsOpen = false }
    BackHandler(enabled = vm.page == 1 && !settingsOpen) { vm.page = 0 }

    // Detect finished / failed downloads -> celebration banner + background shock-wave
    val prev = remember { HashMap<String, Status>() }
    LaunchedEffect(items) {
        for (d in items) {
            val old = prev[d.id]
            if (old != null && old in Downloads.ACTIVE) {
                if (d.status == Status.DONE) {
                    bannerSeq++
                    banner = Banner(bannerSeq.toLong(), d.title, true)
                    bannerVisible = true
                    pulse++
                    haptic(HapticFeedbackType.LongPress)
                } else if (d.status == Status.FAILED) {
                    bannerSeq++
                    banner = Banner(bannerSeq.toLong(), d.title, false)
                    bannerVisible = true
                    haptic(HapticFeedbackType.LongPress)
                }
            }
            prev[d.id] = d.status
        }
    }
    LaunchedEffect(banner) {
        if (banner != null) {
            delay(3400)
            bannerVisible = false
        }
    }

    Box(Modifier.fillMaxSize()) {
        LiveBackground(activity = if (active > 0) 1f else 0f, tint = vm.ambient, pulse = pulse)

        if (reveal || splashGone) {
            AnimatedContent(
                targetState = vm.page,
                transitionSpec = {
                    val dir = if (targetState > initialState) 1 else -1
                    (slideInHorizontally(tween(450, easing = FastOutSlowInEasing)) { it / 5 * dir } +
                        fadeIn(tween(450))) togetherWith
                        (slideOutHorizontally(tween(350, easing = FastOutSlowInEasing)) { -it / 5 * dir } +
                            fadeOut(tween(250)))
                },
                label = "page"
            ) { p ->
                if (p == 0) HomeScreen(vm) { settingsOpen = true } else LibraryScreen(items)
            }
        }

        AnimatedVisibility(
            visible = reveal || splashGone,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 14.dp),
            enter = slideInVertically(tween(700, easing = FastOutSlowInEasing)) { it * 2 } + fadeIn(tween(500))
        ) {
            BottomBar(
                page = vm.page,
                activeCount = active,
                bump = bump,
                onLibraryPos = { libPos = it },
                onSelect = { vm.page = it }
            )
        }

        // Download-start orbs flying into the Library tab
        for (l in vm.launches) {
            key(l.id) {
                val target = if (libPos == Offset.Zero) Offset(l.from.x, l.from.y + 600f) else libPos
                FlyOrb(
                    from = l.from, to = target, audio = l.audio,
                    onArrive = {
                        bump++
                        haptic(HapticFeedbackType.TextHandleMove)
                    },
                    onDone = { vm.removeLaunch(l.id) }
                )
            }
        }

        BannerHost(
            visible = bannerVisible,
            banner = banner,
            onClick = {
                bannerVisible = false
                vm.page = 1
            },
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 8.dp)
        )

        SettingsPanel(visible = settingsOpen, onClose = { settingsOpen = false })

        if (!splashGone) {
            IntroSplash(onReveal = { reveal = true }, onFinished = { splashGone = true })
        }
    }
}
