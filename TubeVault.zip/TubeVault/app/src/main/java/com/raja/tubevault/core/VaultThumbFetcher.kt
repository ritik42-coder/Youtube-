package com.raja.tubevault.core

import android.net.Uri
import coil.ImageLoader
import coil.decode.DataSource
import coil.decode.ImageSource
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.fetch.SourceResult
import coil.request.Options
import okio.Buffer
import java.io.IOException

/** Lets Coil show encrypted vault thumbnails ("tvthumb://name"): decrypted in memory only. */
class VaultThumbFetcher(private val name: String, private val options: Options) : Fetcher {
    override suspend fun fetch(): FetchResult {
        val bytes = Vault.thumbBytes(name) ?: throw IOException("No vault thumbnail")
        return SourceResult(
            source = ImageSource(Buffer().write(bytes), options.context),
            mimeType = "image/jpeg",
            dataSource = DataSource.DISK
        )
    }

    class Factory : Fetcher.Factory<Uri> {
        override fun create(data: Uri, options: Options, imageLoader: ImageLoader): Fetcher? =
            if (data.scheme == "tvthumb") VaultThumbFetcher(data.schemeSpecificPart.removePrefix("//"), options) else null
    }
}
