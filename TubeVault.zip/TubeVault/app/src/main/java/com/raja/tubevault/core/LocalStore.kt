package com.raja.tubevault.core

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.io.InputStream

/**
 * "Private" downloads: kept inside TubeVault's own storage. They play in the app but never
 * appear in the Gallery, Photos or music apps. (They are removed if the app is uninstalled.)
 */
object LocalStore {
    fun dir(ctx: Context) = File(ctx.filesDir, "library").apply { mkdirs() }

    private fun target(ctx: Context, name: String): File {
        val stem = name.substringBeforeLast('.')
        val ext = name.substringAfterLast('.', "")
        var f = File(dir(ctx), name)
        var i = 1
        while (f.exists()) {
            f = File(dir(ctx), "$stem ($i).$ext")
            i++
        }
        return f
    }

    /** Moves (or copies) [src] in and returns its file:// uri. */
    fun save(ctx: Context, src: File, name: String): String {
        val f = target(ctx, name)
        if (!src.renameTo(f)) {
            src.copyTo(f, overwrite = true)
            src.delete()
        }
        return Uri.fromFile(f).toString()
    }

    fun save(ctx: Context, input: InputStream, name: String): String {
        val f = target(ctx, name)
        try {
            f.outputStream().use { input.copyTo(it, 256 * 1024) }
        } catch (e: Throwable) {
            f.delete()
            throw e
        }
        return Uri.fromFile(f).toString()
    }

    fun fileOf(uri: String?): File? =
        if (uri != null && uri.startsWith("file://")) Uri.parse(uri).path?.let { File(it) } else null

    /** A content:// uri other apps can open (for Share / Open with). */
    fun shareUri(ctx: Context, uri: String): Uri {
        val f = fileOf(uri) ?: return Uri.parse(uri)
        return FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
    }

    fun mimeOf(name: String, audio: Boolean): String = when (name.substringAfterLast('.', "").lowercase()) {
        "mp4", "m4v" -> "video/mp4"
        "m4a" -> "audio/mp4"
        "webm" -> if (audio) "audio/webm" else "video/webm"
        "mkv" -> "video/x-matroska"
        "mp3" -> "audio/mpeg"
        "opus", "ogg" -> "audio/ogg"
        else -> if (audio) "audio/mp4" else "video/mp4"
    }
}
