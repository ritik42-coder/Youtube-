@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.raja.tubevault.ui

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Rational
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AspectRatio
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Replay
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.VolumeDown
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import com.raja.tubevault.core.Fx
import com.raja.tubevault.core.PlayerHub
import com.raja.tubevault.core.Playlists
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.raja.tubevault.core.DownloadItem
import com.raja.tubevault.core.Status
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

// ===================================================================== host

data class PlayRequest(val items: List<DownloadItem>, val startIndex: Int)

/** Global entry point: the Library calls [open]; AppRoot shows the player while [request] != null. */
object PlayerHost {
    var request by mutableStateOf<PlayRequest?>(null)
    var inPip by mutableStateOf(false)

    @Volatile
    var pipReady = false

    @Volatile
    var videoRatio = 16f / 9f

    fun open(list: List<DownloadItem>, id: String): Boolean {
        val tapped = list.firstOrNull { it.id == id } ?: return false
        val playable = list.filter { it.status == Status.DONE && it.uri != null && it.isAudio == tapped.isAudio }
        val idx = playable.indexOfFirst { it.id == id }
        if (idx < 0) return false
        request = PlayRequest(playable, idx)
        return true
    }

    fun close() {
        request = null
        pipReady = false
        inPip = false
    }
}

fun enterPip(activity: Activity) {
    if (Build.VERSION.SDK_INT < 26) return
    try {
        val r = PlayerHost.videoRatio.coerceIn(0.43f, 2.35f)
        val params = PictureInPictureParams.Builder()
            .setAspectRatio(Rational((r * 1000).toInt(), 1000))
            .build()
        activity.enterPictureInPictureMode(params)
    } catch (_: Throwable) {
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/** Remembers where you stopped in each file. */
private object PlayerPrefs {
    private fun sp(c: Context) = c.getSharedPreferences("tubevault_player", Context.MODE_PRIVATE)
    fun get(c: Context, uri: String): Long = sp(c).getLong("p_" + uri.hashCode(), 0L)
    fun put(c: Context, uri: String, ms: Long) {
        sp(c).edit().putLong("p_" + uri.hashCode(), ms).apply()
    }
}

private enum class Panel { NONE, SPEED, SOUND, MORE, FX, QUEUE }

private data class Ripple(val side: Int, val seconds: Int, val id: Long)

private val RESIZE_MODES = intArrayOf(
    AspectRatioFrameLayout.RESIZE_MODE_FIT,
    AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
    AspectRatioFrameLayout.RESIZE_MODE_FILL
)
private val RESIZE_LABELS = listOf("Fit", "Zoom", "Stretch")
private val SLEEP_OPTIONS = listOf(0, 5, 15, 30, 60, 90)

// ===================================================================== screen

@Composable
fun VideoPlayerScreen(req: PlayRequest) {
    val ctx = LocalContext.current
    val activity = remember { ctx.findActivity() }
    val haptic = rememberHaptics()
    val cfg = LocalConfiguration.current
    val landscape = cfg.orientation == Configuration.ORIENTATION_LANDSCAPE
    val inPip = PlayerHost.inPip
    val lifecycleOwner = LocalLifecycleOwner.current

    val lastIndex = req.items.lastIndex
    val player = remember { PlayerHub.player(ctx) }
    // Load the queue into the shared background player (skipped when re-opening what is already playing)
    val initialResume = remember(req) {
        val st = req.startIndex.coerceIn(0, lastIndex)
        val first = req.items[st]
        val same = PlayerHub.queueKey == req.items.joinToString(",") { it.id } && PlayerHub.current?.id == first.id
        if (same) 0L else {
            val saved = if (!first.isAudio && first.uri != null) PlayerPrefs.get(ctx, first.uri) else 0L
            val pos = if (saved > 4000L) saved else 0L
            PlayerHub.load(ctx, req.items, st, pos)
            pos
        }
    }
    val index = PlayerHub.index
    val item = req.items[index.coerceIn(0, lastIndex)]
    val isAudio = item.isAudio
    val viz = rememberViz(isAudio && PlayerHub.isPlaying)
    val pvRef = remember { arrayOfNulls<PlayerView>(1) }

    var isPlaying by remember { mutableStateOf(player.isPlaying) }
    var buffering by remember { mutableStateOf(player.playbackState == Player.STATE_BUFFERING) }
    var ended by remember { mutableStateOf(player.playbackState == Player.STATE_ENDED) }
    var addDialog by remember { mutableStateOf(false) }
    var lastResume by remember { mutableLongStateOf(0L) }
    var error by remember { mutableStateOf<String?>(null) }
    var pos by remember { mutableLongStateOf(0L) }
    var dur by remember { mutableLongStateOf(0L) }
    var buf by remember { mutableLongStateOf(0L) }

    var speed by remember { mutableFloatStateOf(player.playbackParameters.speed.coerceIn(0.1f, 8f)) }
    var pitchLock by remember { mutableStateOf(abs(player.playbackParameters.pitch - 1f) < 0.01f) }
    var holding by remember { mutableStateOf(false) }
    var volume by remember { mutableFloatStateOf(PlayerHub.volume) }
    var muted by remember { mutableStateOf(PlayerHub.muted) }
    var brightness by remember { mutableFloatStateOf(-1f) }
    var loop by remember { mutableStateOf(false) }
    var resize by remember { mutableIntStateOf(0) }
    var locked by remember { mutableStateOf(false) }
    var abA by remember { mutableLongStateOf(-1L) }
    var abB by remember { mutableLongStateOf(-1L) }

    var controls by remember { mutableStateOf(true) }
    var touchTick by remember { mutableIntStateOf(0) }
    var panel by remember { mutableStateOf(Panel.NONE) }
    var scrubbing by remember { mutableStateOf(false) }
    var scrubMs by remember { mutableLongStateOf(-1L) }

    var hud by remember { mutableStateOf<Hud?>(null) }
    var lastHud by remember { mutableStateOf<Hud?>(null) }
    var hudTick by remember { mutableIntStateOf(0) }
    var ripple by remember { mutableStateOf<Ripple?>(null) }
    var rippleId by remember { mutableLongStateOf(0L) }
    var lastTapAt by remember { mutableLongStateOf(0L) }
    var resumeNote by remember { mutableStateOf<Long?>(if (initialResume > 0L) initialResume else null) }

    val effSpeed = if (holding) max(2f, speed) else speed

    // ------------------------------------------------------------ helpers
    fun showHud(h: Hud) {
        hud = h
        lastHud = h
        hudTick++
    }

    fun saveProgress() {
        val u = item.uri ?: return
        if (isAudio) return
        if (dur > 0L) PlayerPrefs.put(ctx, u, if (ended || pos > dur - 5000L) 0L else pos)
    }

    val currentSave by rememberUpdatedState { saveProgress() }

    fun baseBrightness(): Float {
        val b = activity?.window?.attributes?.screenBrightness ?: -1f
        if (b >= 0f) return b
        return try {
            Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (_: Throwable) {
            0.5f
        }
    }

    fun togglePlay() {
        if (error != null) return
        if (player.playbackState == Player.STATE_ENDED) {
            player.seekTo(0, 0L)
            player.play()
        } else if (player.playWhenReady) {
            player.pause()
        } else {
            player.play()
        }
        haptic(HapticFeedbackType.TextHandleMove)
        touchTick++
    }

    fun seekBy(deltaMs: Long) {
        val limit = if (dur > 0L) dur else Long.MAX_VALUE
        val t = (player.currentPosition + deltaMs).coerceIn(0L, limit)
        player.seekTo(t)
        pos = t
    }

    fun tapSeek(side: Int) {
        val now = System.currentTimeMillis()
        val prev = ripple
        val acc = if (prev != null && prev.side == side && now - lastTapAt < 900L) prev.seconds + 10 else 10
        lastTapAt = now
        seekBy(side * 10_000L)
        rippleId++
        ripple = Ripple(side, acc, rippleId)
        haptic(HapticFeedbackType.TextHandleMove)
    }

    fun go(delta: Int) {
        saveProgress()
        if (delta > 0) PlayerHub.next(ctx) else PlayerHub.previous(ctx)
        haptic(HapticFeedbackType.TextHandleMove)
        touchTick++
    }

    fun close() {
        saveProgress()
        if (!isAudio) {
            // a video stops when you close it; music keeps playing in the island / background
            player.pause()
            PlayerHub.stop(ctx)
        }
        PlayerHost.close()
    }

    fun toggleOrientation() {
        activity?.requestedOrientation =
            if (landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        touchTick++
    }

    fun popOut() {
        if (isAudio) return
        controls = false
        panel = Panel.NONE
        activity?.let { enterPip(it) }
    }

    // ------------------------------------------------------------ effects
    BackHandler(enabled = true) {
        when {
            panel != Panel.NONE -> panel = Panel.NONE
            locked -> {
                controls = true
                showHud(Hud(3, 0f, "Screen is locked"))
            }
            else -> close()
        }
    }

    // immersive window while the player is open
    DisposableEffect(Unit) {
        val w = activity?.window
        val ctrl = w?.let { WindowCompat.getInsetsController(it, it.decorView) }
        ctrl?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ctrl?.hide(WindowInsetsCompat.Type.systemBars())
        if (w != null && Build.VERSION.SDK_INT >= 28) {
            val lp = w.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            w.attributes = lp
        }
        onDispose {
            ctrl?.show(WindowInsetsCompat.Type.systemBars())
            if (w != null) {
                val lp = w.attributes
                lp.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                if (Build.VERSION.SDK_INT >= 28) {
                    lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
                }
                w.attributes = lp
            }
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // pause when the app goes to the background (unless we are in the pop-out window)
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_STOP && !PlayerHost.inPip && PlayerHub.current?.isAudio != true) player.pause()
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }
    LaunchedEffect(inPip) {
        if (!inPip && PlayerHub.current?.isAudio != true && !lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) player.pause()
    }

    // player listener (UI state only; the hub owns the queue)
    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
                PlayerHost.pipReady = playing && PlayerHub.current?.isAudio != true
            }

            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                ended = state == Player.STATE_ENDED
                if (state == Player.STATE_ENDED) {
                    PlayerHub.current?.takeIf { !it.isAudio }?.uri?.let { PlayerPrefs.put(ctx, it, 0L) }
                }
            }

            override fun onPlayerError(e: PlaybackException) {
                buffering = false
                error = "This file can't be played here. It may have been moved or deleted."
            }

            override fun onVideoSizeChanged(v: VideoSize) {
                if (v.width > 0 && v.height > 0) {
                    PlayerHost.videoRatio = v.width * v.pixelWidthHeightRatio / v.height
                }
            }
        }
        player.addListener(l)
        onDispose {
            currentSave()
            player.removeListener(l)
            pvRef[0]?.player = null
            PlayerHost.pipReady = false
        }
    }

    // reset per-song UI state whenever the song changes
    LaunchedEffect(index) {
        error = null
        ended = false
        pos = 0L
        dur = 0L
        buf = 0L
        if (index != req.startIndex) resumeNote = null
        abA = -1L
        abB = -1L
    }

    LaunchedEffect(effSpeed, pitchLock) {
        player.playbackParameters = PlaybackParameters(effSpeed, if (pitchLock) 1f else effSpeed)
    }
    LaunchedEffect(volume, muted) {
        player.volume = if (muted) 0f else min(volume, 1f)
        Fx.boost = if (muted) 0f else (volume - 1f).coerceAtLeast(0f)
        Fx.touch()
        PlayerHub.volume = volume
        PlayerHub.muted = muted
    }
    LaunchedEffect(loop) {
        player.repeatMode = if (loop) Player.REPEAT_MODE_ONE else if (isAudio && PlayerHub.repeatAll) Player.REPEAT_MODE_ALL else Player.REPEAT_MODE_OFF
    }
    LaunchedEffect(brightness) {
        if (brightness >= 0f) {
            activity?.window?.let { w ->
                val lp = w.attributes
                lp.screenBrightness = brightness
                w.attributes = lp
            }
        }
    }
    LaunchedEffect(resumeNote) {
        resumeNote?.let { lastResume = it }
        if (resumeNote != null) {
            delay(4500)
            resumeNote = null
        }
    }
    LaunchedEffect(hudTick) {
        if (hudTick > 0) {
            delay(if (hud?.kind == 2) 700L else 900L)
            hud = null
        }
    }
    LaunchedEffect(ripple?.id) {
        if (ripple != null) {
            delay(750)
            ripple = null
        }
    }

    // position polling
    LaunchedEffect(player) {
        var tick = 0
        while (true) {
            pos = player.currentPosition
            buf = player.bufferedPosition
            val d = player.duration
            if (d > 0L) dur = d
            tick++
            if (abA >= 0L && abB > abA && pos >= abB) player.seekTo(abA)
            if (tick % 50 == 0) saveProgress()
            delay(if (isPlaying) 90L else 250L)
        }
    }

    // auto-hide controls
    LaunchedEffect(controls, isPlaying, panel, scrubbing, touchTick) {
        if (controls && isPlaying && panel == Panel.NONE && !scrubbing) {
            delay(3500)
            controls = false
        }
    }

    // ------------------------------------------------------------ UI
    val controlsShown = controls && !locked && !inPip
    val shownPos = if (scrubMs >= 0L) scrubMs else pos

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (isAudio) {
            AudioStage(item, isPlaying, effSpeed, viz)
        } else {
            AndroidView(
                factory = { c ->
                    val pv = PlayerView(c)
                    pv.useController = false
                    pv.setBackgroundColor(android.graphics.Color.BLACK)
                    pv.player = player
                    pvRef[0] = pv
                    pv
                },
                update = { it.resizeMode = RESIZE_MODES[resize.coerceIn(0, 2)] },
                modifier = Modifier.fillMaxSize()
            )
        }

        // ---- gesture layer: tap / double-tap / hold / swipe to seek / brightness + volume
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(locked) {
                    detectTapGestures(
                        onPress = {
                            tryAwaitRelease()
                            if (holding) holding = false
                        },
                        onLongPress = {
                            if (!locked && isPlaying && panel == Panel.NONE) {
                                holding = true
                                haptic(HapticFeedbackType.LongPress)
                            }
                        },
                        onDoubleTap = { o ->
                            if (!locked && panel == Panel.NONE) {
                                val f = o.x / size.width
                                when {
                                    f < 0.35f -> tapSeek(-1)
                                    f > 0.65f -> tapSeek(1)
                                    else -> togglePlay()
                                }
                            }
                        },
                        onTap = {
                            controls = !controls
                            touchTick++
                        }
                    )
                }
                .pointerInput(locked) {
                    if (!locked) {
                        var left = false
                        detectVerticalDragGestures(
                            onDragStart = { o ->
                                left = o.x < size.width / 2f
                                if (left && brightness < 0f) brightness = baseBrightness()
                            },
                            onVerticalDrag = { change, dy ->
                                change.consume()
                                val d = -dy / size.height * 1.4f
                                if (left) {
                                    brightness = (brightness + d).coerceIn(0.02f, 1f)
                                    showHud(Hud(0, brightness, "${(brightness * 100f).roundToInt()}%"))
                                } else {
                                    volume = (volume + d * 1.4f).coerceIn(0f, 2f)
                                    muted = false
                                    showHud(
                                        Hud(
                                            1, volume / 2f, "${(volume * 100f).roundToInt()}%",
                                            if (volume > 1.001f) "boost" else ""
                                        )
                                    )
                                }
                            }
                        )
                    }
                }
                .pointerInput(locked) {
                    if (!locked) {
                        var base = 0L
                        var acc = 0f
                        var tgt = 0L
                        detectHorizontalDragGestures(
                            onDragStart = {
                                base = player.currentPosition
                                tgt = base
                                acc = 0f
                                scrubbing = true
                            },
                            onDragEnd = {
                                scrubbing = false
                                if (dur > 0L) {
                                    player.seekTo(tgt)
                                    pos = tgt
                                }
                            },
                            onDragCancel = { scrubbing = false },
                            onHorizontalDrag = { change, dx ->
                                change.consume()
                                acc += dx
                                val span = min(max(dur, 1L), 240_000L).toFloat()
                                tgt = (base + acc / size.width * span).toLong().coerceIn(0L, max(dur, 0L))
                                val diff = ((tgt - base) / 1000L).toInt()
                                showHud(Hud(2, 0f, fmtTime(tgt), (if (diff >= 0) "+" else "") + diff + "s"))
                            }
                        )
                    }
                }
        )

        // ---- double-tap ripples
        val rp = ripple
        if (rp != null && !inPip) {
            SeekRipple(
                rp.side, rp.seconds, rp.id,
                Modifier
                    .align(if (rp.side < 0) Alignment.CenterStart else Alignment.CenterEnd)
                    .fillMaxHeight()
                    .fillMaxWidth(0.4f)
            )
        }

        // ---- hold = fast-forward pill
        AnimatedVisibility(
            visible = holding && !inPip,
            modifier = Modifier.align(Alignment.TopCenter).windowInsetsPadding(WindowInsets.safeDrawing).padding(top = 18.dp),
            enter = fadeIn(tween(150)) + slideInVertically(spring(dampingRatio = 0.6f, stiffness = 400f)) { -it },
            exit = fadeOut(tween(150)) + slideOutVertically(tween(150)) { -it }
        ) { HoldBoostPill(fmtSpeed(effSpeed)) }

        // ---- buffering ring
        val ringSize by animateDpAsState(if (controlsShown) 100.dp else 62.dp, spring(dampingRatio = 0.7f, stiffness = 300f), label = "ring")
        AnimatedVisibility(
            visible = buffering && !ended && error == null && !inPip,
            modifier = Modifier.align(Alignment.Center),
            enter = fadeIn(tween(200)),
            exit = fadeOut(tween(200))
        ) { RingProgress(-1f, Modifier.size(ringSize), stroke = 4.dp) }

        // ---- TOP BAR
        AnimatedVisibility(
            visible = controlsShown,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn(tween(220)) + slideInVertically(tween(320, easing = FastOutSlowInEasing)) { -it / 2 },
            exit = fadeOut(tween(180)) + slideOutVertically(tween(220)) { -it / 2 }
        ) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
            ) {
                Row(
                    Modifier
                        .windowInsetsPadding(WindowInsets.safeDrawing)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    PlayerIconButton(Icons.Rounded.KeyboardArrowDown, { close() })
                    Column(Modifier.weight(1f)) {
                        Text(
                            item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        val sub = listOfNotNull(
                            if (req.items.size > 1) "${index + 1} of ${req.items.size}" else null,
                            item.uploader.ifEmpty { null },
                            item.label.ifEmpty { null }
                        ).joinToString("  •  ")
                        if (sub.isNotEmpty()) {
                            Text(sub, color = Color(0xCCFFFFFF), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    if (!isAudio && Build.VERSION.SDK_INT >= 26) {
                        PlayerIconButton(Icons.Rounded.PictureInPictureAlt, { popOut() })
                    }
                    if (isAudio) {
                        val fav = Playlists.isFav(item.id)
                        PlayerIconButton(
                            if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                            { Playlists.toggleFav(item.id); haptic(HapticFeedbackType.LongPress) },
                            active = fav
                        )
                        PlayerIconButton(Icons.Rounded.PlaylistAdd, { addDialog = true })
                    }
                    PlayerIconButton(Icons.Rounded.MoreVert, { panel = Panel.MORE })
                }
            }
        }

        // ---- CENTRE TRANSPORT
        AnimatedVisibility(
            visible = controlsShown && error == null,
            modifier = Modifier.align(Alignment.Center),
            enter = fadeIn(tween(220)) + scaleIn(spring(dampingRatio = 0.6f, stiffness = 380f), 0.6f),
            exit = fadeOut(tween(150)) + scaleOut(tween(150), 0.8f)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PlayerIconButton(Icons.Rounded.SkipPrevious, { go(-1) }, size = 46.dp, enabled = index > 0 || pos > 3000L || (isAudio && lastIndex > 0))
                PlayerIconButton(Icons.Rounded.Replay10, { tapSeek(-1); touchTick++ }, size = 54.dp)
                PlayPauseButton(isPlaying, ended) { togglePlay() }
                PlayerIconButton(Icons.Rounded.Forward10, { tapSeek(1); touchTick++ }, size = 54.dp)
                PlayerIconButton(Icons.Rounded.SkipNext, { go(1) }, size = 46.dp, enabled = index < lastIndex || (isAudio && PlayerHub.repeatAll && lastIndex > 0))
            }
        }

        // ---- BOTTOM: seek bar + actions
        AnimatedVisibility(
            visible = controlsShown,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(tween(220)) + slideInVertically(tween(320, easing = FastOutSlowInEasing)) { it / 2 },
            exit = fadeOut(tween(180)) + slideOutVertically(tween(220)) { it / 2 }
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDD000000))))
                    .windowInsetsPadding(WindowInsets.safeDrawing)
                    .padding(horizontal = 10.dp)
                    .padding(top = 28.dp, bottom = 6.dp)
            ) {
                FancySeekBar(
                    positionMs = pos, durationMs = dur, bufferedMs = buf, playing = isPlaying,
                    onScrubStart = { scrubbing = true },
                    onScrub = { f -> scrubMs = (f * dur).toLong() },
                    onCommit = { f ->
                        scrubbing = false
                        scrubMs = -1L
                        if (dur > 0L) {
                            val t = (f * dur).toLong()
                            player.seekTo(t)
                            pos = t
                        }
                        touchTick++
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "${fmtTime(shownPos)} / ${fmtTime(dur)}",
                        color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 6.dp)
                    )
                    Spacer(Modifier.weight(1f))
                    SpeedPill(effSpeed) { panel = Panel.SPEED }
                    Spacer(Modifier.width(8.dp))
                    PlayerIconButton(
                        when {
                            muted || volume <= 0.001f -> Icons.Rounded.VolumeOff
                            volume < 0.5f -> Icons.Rounded.VolumeDown
                            else -> Icons.Rounded.VolumeUp
                        },
                        { panel = Panel.SOUND }, size = 40.dp, active = volume > 1.001f && !muted
                    )
                    Spacer(Modifier.width(8.dp))
                    PlayerIconButton(Icons.Rounded.Equalizer, { panel = Panel.FX }, size = 40.dp, active = !Fx.isNeutral())
                }
            }
        }

        // ---- unlock button
        AnimatedVisibility(
            visible = locked && controls && !inPip,
            modifier = Modifier.align(Alignment.CenterEnd).windowInsetsPadding(WindowInsets.safeDrawing).padding(end = 20.dp),
            enter = fadeIn(tween(200)) + scaleIn(spring(dampingRatio = 0.5f, stiffness = 400f), 0.5f),
            exit = fadeOut(tween(200)) + scaleOut(tween(200), 0.5f)
        ) {
            PlayerIconButton(Icons.Rounded.LockOpen, {
                locked = false
                controls = true
                haptic(HapticFeedbackType.LongPress)
                showHud(Hud(3, 0f, "Unlocked"))
            }, size = 56.dp, active = true)
        }

        // ---- "resumed" chip
        AnimatedVisibility(
            visible = resumeNote != null && !inPip,
            modifier = Modifier.align(Alignment.BottomCenter).windowInsetsPadding(WindowInsets.safeDrawing).padding(bottom = 138.dp),
            enter = fadeIn(tween(250)) + slideInVertically(spring(dampingRatio = 0.7f, stiffness = 350f)) { it },
            exit = fadeOut(tween(250)) + slideOutVertically(tween(250)) { it }
        ) {
            val rn = resumeNote ?: lastResume
            Row(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(Color(0xDD101018))
                    .border(BorderStroke(1.dp, GlassBorder), RoundedCornerShape(50))
                    .padding(start = 16.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Resumed at ${fmtTime(rn)}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.width(10.dp))
                Box(
                    Modifier
                        .pressable {
                            player.seekTo(0L)
                            pos = 0L
                            resumeNote = null
                        }
                        .clip(RoundedCornerShape(50))
                        .background(AccentBrush)
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                ) { Text("Start over", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            }
        }

        // ---- gesture HUD
        BoxScopeHud(hud, lastHud)

        // ---- error
        AnimatedVisibility(
            visible = error != null,
            modifier = Modifier.align(Alignment.Center),
            enter = fadeIn(tween(250)) + scaleIn(tween(250), 0.9f),
            exit = fadeOut(tween(150))
        ) {
            Column(
                Modifier.padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Icon(Icons.Rounded.ErrorOutline, null, tint = Pink, modifier = Modifier.size(54.dp))
                Text(error ?: "", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillButton(Icons.Rounded.PlayArrow, "Open in another app", true) { openFile(ctx, item) }
                    PillButton(Icons.Rounded.KeyboardArrowDown, "Close", false) { close() }
                }
            }
        }

        // ---- PANELS
        PlayerPanel(visible = panel == Panel.SPEED && !inPip, onDismiss = { panel = Panel.NONE }) {
            SpeedPanelContent(
                speed = speed, pitchLock = pitchLock,
                onSpeed = { speed = it.coerceIn(0.1f, 8f) },
                onPitchLock = { pitchLock = it }
            )
        }
        PlayerPanel(visible = panel == Panel.SOUND && !inPip, onDismiss = { panel = Panel.NONE }) {
            SoundPanelContent(
                volume = volume, muted = muted,
                brightness = if (brightness >= 0f) brightness else baseBrightness(),
                onVolume = { volume = it; muted = false },
                onMute = { muted = !muted; haptic(HapticFeedbackType.TextHandleMove) },
                onBrightness = { brightness = it }
            )
        }
        PlayerPanel(visible = panel == Panel.MORE && !inPip, onDismiss = { panel = Panel.NONE }) {
            Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("More", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PlayerTile(
                        if (loop) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                        if (loop) "Loop on" else "Loop", loop, Modifier.weight(1f)
                    ) {
                        loop = !loop
                        showHud(Hud(3, 0f, if (loop) "Looping this file" else "Loop off"))
                    }
                    PlayerTile(
                        Icons.Rounded.AspectRatio, RESIZE_LABELS[resize.coerceIn(0, 2)], resize != 0, Modifier.weight(1f)
                    ) {
                        resize = (resize + 1) % 3
                        showHud(Hud(3, 0f, "Screen: ${RESIZE_LABELS[resize]}"))
                    }
                    PlayerTile(
                        Icons.Rounded.Bedtime,
                        if (PlayerHub.sleepMin == 0) "Sleep" else fmtTime(PlayerHub.sleepLeftSec * 1000L),
                        PlayerHub.sleepMin != 0, Modifier.weight(1f)
                    ) {
                        val nx = SLEEP_OPTIONS[(SLEEP_OPTIONS.indexOf(PlayerHub.sleepMin).coerceAtLeast(0) + 1) % SLEEP_OPTIONS.size]
                        PlayerHub.setSleep(ctx, nx)
                        showHud(Hud(3, 0f, if (nx == 0) "Sleep timer off" else "Fades out in $nx min"))
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PlayerTile(Icons.Rounded.PictureInPictureAlt, "Pop-out", false, Modifier.weight(1f)) {
                        if (isAudio) showHud(Hud(3, 0f, "Pop-out is for videos")) else popOut()
                    }
                    PlayerTile(Icons.Rounded.Lock, "Lock", false, Modifier.weight(1f)) {
                        locked = true
                        controls = false
                        panel = Panel.NONE
                        showHud(Hud(3, 0f, "Locked. Tap the screen to show unlock"))
                    }
                    PlayerTile(
                        Icons.Rounded.ScreenRotation, if (landscape) "Portrait" else "Landscape", false, Modifier.weight(1f)
                    ) { toggleOrientation(); panel = Panel.NONE }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PlayerTile(Icons.Rounded.QueueMusic, "Queue", false, Modifier.weight(1f)) { panel = Panel.QUEUE }
                    PlayerTile(Icons.Rounded.Equalizer, "Sound Lab", !Fx.isNeutral(), Modifier.weight(1f)) { panel = Panel.FX }
                    PlayerTile(
                        Icons.Rounded.Shuffle, if (PlayerHub.shuffle) "Shuffle on" else "Shuffle", PlayerHub.shuffle, Modifier.weight(1f)
                    ) {
                        PlayerHub.setShuffle(ctx, !PlayerHub.shuffle)
                        showHud(Hud(3, 0f, if (PlayerHub.shuffle) "Shuffle on" else "Shuffle off"))
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PlayerTile(
                        Icons.Rounded.Repeat,
                        when {
                            abA < 0L -> "A-B repeat"
                            abB < 0L -> "A set"
                            else -> "A-B on"
                        },
                        abA >= 0L, Modifier.weight(1f)
                    ) {
                        when {
                            abA < 0L -> { abA = player.currentPosition; showHud(Hud(3, 0f, "Point A set")) }
                            abB < 0L -> {
                                if (player.currentPosition > abA + 500L) {
                                    abB = player.currentPosition
                                    player.seekTo(abA)
                                    showHud(Hud(3, 0f, "Looping A to B"))
                                } else showHud(Hud(3, 0f, "Play a bit further, then tap again"))
                            }
                            else -> { abA = -1L; abB = -1L; showHud(Hud(3, 0f, "A-B repeat off")) }
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    Spacer(Modifier.weight(1f))
                }
                if (isAudio) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        PlayerTile(
                            Icons.Rounded.GraphicEq,
                            listOf("Visual: Bars", "Visual: Ring", "Visual: Wave")[PlayerHub.vizStyle.coerceIn(0, 2)],
                            false, Modifier.weight(1f)
                        ) {
                            PlayerHub.vizStyle = (PlayerHub.vizStyle + 1) % 3
                            haptic(HapticFeedbackType.TextHandleMove)
                        }
                        PlayerTile(
                            if (PlayerHub.repeatAll) Icons.Rounded.Repeat else Icons.Rounded.RepeatOne,
                            if (PlayerHub.repeatAll) "Repeat all" else "No repeat", PlayerHub.repeatAll, Modifier.weight(1f)
                        ) {
                            PlayerHub.setRepeatAll(ctx, !PlayerHub.repeatAll)
                        }
                        Spacer(Modifier.weight(1f))
                    }
                }
                Spacer(Modifier.height(14.dp))
            }
        }
        PlayerPanel(visible = panel == Panel.FX && !inPip, onDismiss = { panel = Panel.NONE }) {
            SoundLabContent(onSpeed = { sp, keep -> speed = sp; pitchLock = keep })
        }
        PlayerPanel(visible = panel == Panel.QUEUE && !inPip, onDismiss = { panel = Panel.NONE }) {
            Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Up next", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                    if (isAudio && req.items.size > 1) {
                        Box(
                            Modifier
                                .pressable {
                                    Playlists.create("Queue " + req.items.size, req.items.map { it.id })
                                    showHud(Hud(3, 0f, "Saved as a playlist"))
                                    panel = Panel.NONE
                                }
                                .clip(RoundedCornerShape(50))
                                .background(AccentBrush)
                                .padding(horizontal = 14.dp, vertical = 7.dp)
                        ) { Text("Save as playlist", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                    }
                }
                req.items.forEachIndexed { i, q ->
                    val cur = i == index
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .pressable { PlayerHub.jumpTo(ctx, i); haptic(HapticFeedbackType.TextHandleMove) }
                            .clip(RoundedCornerShape(16.dp))
                            .then(if (cur) Modifier.background(AccentBrush) else Modifier.background(Glass))
                            .padding(horizontal = 14.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("${i + 1}", color = if (cur) Color.White else TextLo, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(
                            q.title, color = Color.White, fontSize = 14.sp, fontWeight = if (cur) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                        )
                        if (cur && isPlaying) Icon(Icons.Rounded.GraphicEq, null, tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                }
                Spacer(Modifier.height(14.dp))
            }
        }
        if (addDialog) AddToPlaylistDialog(item.id) { addDialog = false }
    }
}

// ===================================================================== bits

@Composable
private fun PlayPauseButton(playing: Boolean, ended: Boolean, onClick: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "pp")
    val pulse by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1600, easing = LinearEasing)), label = "ppp")
    val state = if (ended) 2 else if (playing) 1 else 0
    Box(Modifier.size(96.dp).pressable(onClick), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(
                Brush.radialGradient(listOf(Pink.copy(alpha = 0.45f), Color.Transparent), center = center, radius = 48.dp.toPx()),
                48.dp.toPx(), center
            )
            if (!playing) {
                drawCircle(
                    Pink.copy(alpha = (1f - pulse) * 0.45f),
                    (38f + 10f * pulse).dp.toPx(), center
                )
            }
        }
        Box(
            Modifier.size(76.dp).clip(CircleShape).background(AccentBrush2),
            contentAlignment = Alignment.Center
        ) {
            AnimatedContent(
                targetState = state,
                transitionSpec = {
                    (scaleIn(spring(dampingRatio = 0.55f, stiffness = 500f), 0.3f) + fadeIn(tween(160))) togetherWith
                        (scaleOut(tween(120), 0.3f) + fadeOut(tween(100)))
                },
                label = "ppicon"
            ) { s ->
                Icon(
                    when (s) {
                        1 -> Icons.Rounded.Pause
                        2 -> Icons.Rounded.Replay
                        else -> Icons.Rounded.PlayArrow
                    },
                    null, tint = Color.White, modifier = Modifier.size(42.dp)
                )
            }
        }
    }
}

@Composable
private fun SpeedPill(speed: Float, onClick: () -> Unit) {
    val changed = abs(speed - 1f) > 0.001f
    val shape = RoundedCornerShape(50)
    Row(
        Modifier
            .pressable(onClick)
            .clip(shape)
            .then(if (changed) Modifier.background(AccentBrush) else Modifier.background(Color(0x33FFFFFF)))
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(Icons.Rounded.Speed, null, tint = Color.White, modifier = Modifier.size(16.dp))
        AnimatedContent(
            targetState = fmtSpeed(speed),
            transitionSpec = {
                (slideInVertically(tween(200)) { it } + fadeIn(tween(200))) togetherWith
                    (slideOutVertically(tween(200)) { -it } + fadeOut(tween(150)))
            },
            label = "speedpill"
        ) { s -> Text(s, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
    }
}
