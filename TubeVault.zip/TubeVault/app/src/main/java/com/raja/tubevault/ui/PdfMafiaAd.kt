package com.raja.tubevault.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.speech.tts.TextToSpeech
import android.view.TextureView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.delay
import java.util.Locale

private val SCENE_T = floatArrayOf(0f, 3f, 6f, 9f, 12.5f, 16f, 19.5f, 22.5f, 26f)
private val SCENE_V = arrayOf(
    "Paywalls. Watermarks. Limits. Enough.",
    "Ten apps. One job.",
    "Meet... PDF Mafia.",
    "Merge unlimited PDFs into one. In seconds.",
    "Turn black pages white. Save ink. Print ready.",
    "Compress giant files. Without losing quality.",
    "Scan, and extract text with O C R.",
    "Edit. Crop. Convert. All in one place.",
    "A hundred percent free. Download PDF Mafia, now."
)
private const val AD_URL = "https://pdf-mafia.netlify.app/"
private val Red = Color(0xFFE11D2E)

/** Voice-over via the phone's TTS. Never blocks the ad: lines are queued until ready, failures ignored. */
private class Voice(ctx: Context) {
    @Volatile private var ok = false
    @Volatile private var pending: String? = null
    private var tts: TextToSpeech? = null

    init {
        runCatching {
            tts = TextToSpeech(ctx.applicationContext) { st ->
                if (st == TextToSpeech.SUCCESS) {
                    runCatching {
                        tts?.language = Locale.US
                        tts?.setPitch(0.65f)
                        tts?.setSpeechRate(1.0f)
                    }
                    ok = true
                    pending?.let { say(it) }
                }
            }
        }
    }

    fun say(t: String) {
        if (!ok) { pending = t; return }
        runCatching { tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "pdfmafia") }
    }

    fun release() { runCatching { tts?.stop(); tts?.shutdown() } }
}

/**
 * Full-screen PDF Mafia video ad (pre-rendered MP4 + voice-over).
 * Plays with ExoPlayer on a TextureView, so it never depends on WebView rendering.
 */
@Composable
fun PdfMafiaAd(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val voice = remember { Voice(ctx) }
    val player = remember {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri("asset:///pdfmafia_ad.mp4"))
            volume = 1f
            prepare()
            playWhenReady = true
        }
    }
    var posMs by remember { mutableLongStateOf(0L) }
    var ended by remember { mutableStateOf(false) }

    BackHandler(true) {}
    DisposableEffect(Unit) {
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) ended = true
            }
            override fun onPlayerError(error: PlaybackException) { onClose() }
        }
        player.addListener(l)
        onDispose {
            player.removeListener(l)
            player.release()
            voice.release()
        }
    }
    // narration timed to the video + safety net so the ad can never trap the user
    LaunchedEffect(Unit) {
        var spoken = -1
        while (true) {
            posMs = player.currentPosition
            val sec = posMs / 1000f
            val i = SCENE_T.indexOfLast { sec >= it }
            if (i >= 0 && i != spoken && player.isPlaying) {
                spoken = i
                voice.say(SCENE_V[i])
            }
            delay(100)
        }
    }
    LaunchedEffect(Unit) { delay(50_000); onClose() }

    val sec = posMs / 1000f
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Box(Modifier.align(Alignment.Center).aspectRatio(9f / 16f)) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c -> TextureView(c).also { player.setVideoTextureView(it) } }
            )
        }
        // progress bar
        Box(
            Modifier.align(Alignment.TopStart).fillMaxWidth(((sec / 30f).coerceIn(0f, 1f)))
                .height(3.dp).background(Red)
        )
        // AD badge + countdown
        Box(Modifier.align(Alignment.TopStart).statusBarsPadding().padding(12.dp)) {
            val left = (30 - sec.toInt()).coerceAtLeast(0)
            Text(
                "AD  0:" + left.toString().padStart(2, '0'),
                color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.background(Color(0xFFFFC83D), RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            )
        }
        if (ended || sec >= 29.5f) {
            Text(
                "✕ Close", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(12.dp)
                    .background(Color(0xB3000000), RoundedCornerShape(6.dp))
                    .clickable { onClose() }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            )
        }
        Text(
            "👑 Remove Ads", color = Color.Black, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.align(Alignment.BottomStart).navigationBarsPadding().padding(16.dp)
                .background(Color(0xFFFFC83D), RoundedCornerShape(50))
                .clickable { Premium.openRequest = true; onClose() }
                .padding(horizontal = 16.dp, vertical = 10.dp)
        )
        if (sec >= 25f && !ended) {
            Text(
                "Skip Ad ›", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(16.dp)
                    .background(Color(0xB3000000), RoundedCornerShape(6.dp))
                    .clickable { onClose() }
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            )
        }
        if (sec >= 26f || ended) {
            Text(
                "⬇  DOWNLOAD NOW", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black,
                modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 96.dp)
                    .background(Red, RoundedCornerShape(50))
                    .clickable {
                        runCatching {
                            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(AD_URL)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }
                    }
                    .padding(horizontal = 36.dp, vertical = 16.dp)
            )
        }
    }
}
