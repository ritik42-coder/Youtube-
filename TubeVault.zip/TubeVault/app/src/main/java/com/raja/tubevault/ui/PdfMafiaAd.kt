package com.raja.tubevault.ui

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import java.util.Locale

private class AdBridge(
    private val ctx: Context,
    private val tts: TextToSpeech,
    private val onClose: () -> Unit
) {
    @JavascriptInterface fun speak(t: String) {
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "pdfmafia")
    }
    @JavascriptInterface fun close() {
        Handler(Looper.getMainLooper()).post { onClose() }
    }
    @JavascriptInterface fun openUrl(u: String) {
        runCatching {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}

/** Full-screen PDF Mafia video ad (with voice-over). Shown while a download runs in the background. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PdfMafiaAd(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var ready by remember { mutableStateOf(false) }
    val ttsRef = remember { arrayOfNulls<TextToSpeech>(1) }
    val tts = remember {
        TextToSpeech(ctx.applicationContext) { st ->
            if (st == TextToSpeech.SUCCESS) {
                ttsRef[0]?.apply {
                    language = Locale.US
                    setPitch(0.65f)
                    setSpeechRate(1.0f)
                }
            }
            ready = true
        }.also { ttsRef[0] = it }
    }
    // Ad can only be closed from its own Skip / Close buttons
    BackHandler(true) {}
    DisposableEffect(Unit) {
        onDispose { tts.stop(); tts.shutdown() }
    }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (ready) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c ->
                    WebView(c).apply {
                        setBackgroundColor(android.graphics.Color.BLACK)
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        addJavascriptInterface(AdBridge(c, tts, onClose), "TV")
                        loadUrl("file:///android_asset/pdfmafia_ad.html?app=1")
                    }
                },
                onRelease = { it.destroy() }
            )
        }
    }
}
