package com.raja.tubevault.ui

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import java.util.Locale

/** Text-to-speech that never blocks the ad: lines spoken before init are queued, failures are ignored. */
private class Voice(ctx: Context) {
    @Volatile private var ok = false
    @Volatile private var pending: String? = null
    private var tts: TextToSpeech? = null

    init {
        runCatching {
            tts = TextToSpeech(ctx.applicationContext) { st ->
                if (st == TextToSpeech.SUCCESS) {
                    runCatching {
                        tts?.language = Locale.US
                        tts?.setPitch(0.65f)
                        tts?.setSpeechRate(1.0f)
                    }
                    ok = true
                    pending?.let { say(it) }
                }
            }
        }
    }

    fun say(t: String) {
        if (!ok) { pending = t; return }
        runCatching { tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "pdfmafia") }
    }

    fun release() = runCatching { tts?.stop(); tts?.shutdown() }
}

private class AdBridge(
    private val ctx: Context,
    private val voice: Voice,
    private val onClose: () -> Unit
) {
    @JavascriptInterface fun speak(t: String) = voice.say(t)
    @JavascriptInterface fun close() {
        Handler(Looper.getMainLooper()).post { onClose() }
    }
    @JavascriptInterface fun openUrl(u: String) {
        runCatching {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}

/** Full-screen PDF Mafia video ad (with voice-over). Shown while a download runs in the background. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PdfMafiaAd(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val voice = remember { Voice(ctx) }

    BackHandler(true) {}
    DisposableEffect(Unit) { onDispose { voice.release() } }
    // Safety net: the ad can never trap the user (30s ad + margin)
    LaunchedEffect(Unit) { delay(36_000); onClose() }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                WebView(c).apply {
                    setBackgroundColor(android.graphics.Color.BLACK)
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.allowFileAccess = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    webViewClient = object : WebViewClient() {
                        override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
                            if (r.isForMainFrame) onClose()
                        }
                    }
                    addJavascriptInterface(AdBridge(c, voice, onClose), "TV")
                    loadUrl("file:///android_asset/pdfmafia_ad.html?app=1")
                }
            },
            onRelease = { it.destroy() }
        )
    }
}
