package com.raja.tubevault.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.raja.tubevault.core.DownloadItem
import com.raja.tubevault.core.Downloads
import com.raja.tubevault.core.FormatOption
import com.raja.tubevault.core.MediaInfo
import com.raja.tubevault.core.Status
import com.raja.tubevault.core.formatBytes
import com.raja.tubevault.core.formatDuration

// ======================================================================= HOME

@Composable
fun HomeScreen(vm: MainViewModel) {
    val clipboard = LocalClipboardManager.current
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(top = 18.dp, bottom = 130.dp)
    ) {
        Staggered(0) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppLogo()
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(
                        "TubeVault",
                        style = TextStyle(brush = AccentBrush, fontSize = 30.sp, fontWeight = FontWeight.Black)
                    )
                    Text("Save any video. Keep it forever.", color = TextLo, fontSize = 14.sp)
                }
            }
        }

        Spacer(Modifier.height(26.dp))

        Staggered(1) {
            GlassCard(Modifier.fillMaxWidth()) {
                Row(
                    Modifier.padding(start = 18.dp, end = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Link, null, tint = TextLo)
                    Spacer(Modifier.width(12.dp))
                    BasicTextField(
                        value = vm.url,
                        onValueChange = { vm.url = it },
                        singleLine = true,
                        textStyle = TextStyle(color = TextHi, fontSize = 16.sp),
                        cursorBrush = SolidColor(Pink),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = { vm.fetch() }),
                        modifier = Modifier
                            .weight(1f)
                            .padding(vertical = 18.dp),
                        decorationBox = { inner ->
                            Box {
                                if (vm.url.isEmpty()) {
                                    Text("Paste a YouTube link", color = TextLo, fontSize = 16.sp)
                                }
                                inner()
                            }
                        }
                    )
                    Crossfade(vm.url.isEmpty(), label = "pasteclear") { empty ->
                        if (empty) {
                            IconCircle(Icons.Rounded.ContentPaste) {
                                val text = clipboard.getText()?.text
                                if (!text.isNullOrBlank()) {
                                    vm.url = text
                                    vm.fetch()
                                }
                            }
                        } else {
                            IconCircle(Icons.Rounded.Close) { vm.clear() }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        Staggered(2) {
            GradientButton(
                text = "Get download options",
                loading = vm.state is FetchState.Loading
            ) { vm.fetch() }
        }

        Spacer(Modifier.height(22.dp))

        AnimatedContent(
            targetState = vm.state,
            transitionSpec = {
                (fadeIn(tween(350)) + slideInVertically(tween(450)) { it / 8 }) togetherWith fadeOut(tween(200))
            },
            contentKey = { it::class },
            label = "result"
        ) { st ->
            when (st) {
                is FetchState.Idle -> HintCard()
                is FetchState.Loading -> SkeletonCard()
                is FetchState.Error -> ErrorCard(st.message)
                is FetchState.Ready -> ResultCard(st.info, vm)
            }
        }
    }
}

@Composable
private fun IconCircle(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .pressable(onClick)
            .clip(CircleShape)
            .background(Glass),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = TextHi, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun HintCard() {
    GlassCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("How it works", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text("1.  Copy a video link in YouTube (or tap Share → TubeVault)", color = TextLo, fontSize = 14.sp)
            Text("2.  Paste it here and pick a quality or audio only", color = TextLo, fontSize = 14.sp)
            Text("3.  Find it in Library and in your Gallery → Movies/TubeVault", color = TextLo, fontSize = 14.sp)
            Text(
                "Please only download videos you own or have permission to save.",
                color = TextLo.copy(alpha = 0.7f), fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun ErrorCard(message: String) {
    GlassCard(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.ErrorOutline, null, tint = Pink, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(14.dp))
            Column {
                Text("Couldn't load this video", color = TextHi, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(message, color = TextLo, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun SkeletonCard() {
    val brush = shimmerBrush()
    GlassCard(Modifier.fillMaxWidth()) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(16 / 9f)
                .background(brush)
        )
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.fillMaxWidth(0.9f).height(18.dp).clip(RoundedCornerShape(8.dp)).background(brush))
            Box(Modifier.fillMaxWidth(0.5f).height(14.dp).clip(RoundedCornerShape(8.dp)).background(brush))
            repeat(3) {
                Box(Modifier.fillMaxWidth().height(58.dp).clip(RoundedCornerShape(18.dp)).background(brush))
            }
        }
    }
}

@Composable
private fun ResultCard(info: MediaInfo, vm: MainViewModel) {
    val ctx = LocalContext.current
    GlassCard(Modifier.fillMaxWidth()) {
        Box {
            AsyncImage(
                model = ImageRequest.Builder(ctx).data(info.thumbnail).crossfade(true).build(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16 / 9f)
                    .background(Color(0xFF1A1A26))
            )
            val dur = formatDuration(info.durationSec)
            if (dur.isNotEmpty()) {
                Text(
                    dur,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(10.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xCC000000))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }
        Column(Modifier.padding(18.dp)) {
            Text(
                info.title,
                color = TextHi,
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            if (info.uploader.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text(info.uploader, color = TextLo, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(16.dp))
            Segmented(listOf("Video", "Audio"), vm.formatTab) { vm.formatTab = it }
            Spacer(Modifier.height(14.dp))

            Crossfade(vm.formatTab, label = "formats") { tab ->
                val list = if (tab == 0) info.videoFormats else info.audioFormats
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (list.isEmpty()) {
                        Text("Nothing available in this category.", color = TextLo, fontSize = 14.sp)
                    }
                    list.forEachIndexed { i, opt ->
                        Staggered(i) {
                            FormatRow(opt, opt.key in vm.queued) { vm.download(info, opt) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FormatRow(opt: FormatOption, queued: Boolean, onDownload: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .pressable { if (!queued) onDownload() }
            .clip(shape)
            .background(Color(0x0DFFFFFF))
            .border(BorderStroke(1.dp, GlassBorder), shape)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(if (opt.isAudio) Violet.copy(alpha = 0.25f) else Pink.copy(alpha = 0.22f))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Text(opt.label, color = TextHi, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
        Spacer(Modifier.width(14.dp))
        Text(opt.detail, color = TextLo, fontSize = 13.sp, modifier = Modifier.weight(1f))
        AnimatedContent(
            targetState = queued,
            transitionSpec = { (scaleIn(spring(0.5f, Spring.StiffnessMedium)) + fadeIn()) togetherWith (scaleOut() + fadeOut()) },
            label = "dlbtn"
        ) { q ->
            Box(
                Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(if (q) Color(0x3334D399) else Pink.copy(alpha = 0.9f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (q) Icons.Rounded.CheckCircle else Icons.Rounded.Download,
                    null,
                    tint = if (q) Green else Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}

// ======================================================================= LIBRARY

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LibraryScreen(list: List<DownloadItem>) {
    var confirm by remember { mutableStateOf<DownloadItem?>(null) }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
            .padding(top = 18.dp)
    ) {
        Staggered(0) {
            Column {
                Text(
                    "Library",
                    style = TextStyle(brush = AccentBrush, fontSize = 30.sp, fontWeight = FontWeight.Black)
                )
                Text(
                    if (list.isEmpty()) "Your downloads will appear here"
                    else "${list.size} item${if (list.size == 1) "" else "s"} • saved in Movies/TubeVault",
                    color = TextLo, fontSize = 14.sp
                )
            }
        }
        Spacer(Modifier.height(18.dp))

        if (list.isEmpty()) {
            EmptyState()
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 130.dp)
            ) {
                items(list, key = { it.id }) { item ->
                    DownloadCard(item, Modifier.animateItemPlacement(tween(350)), onDelete = { confirm = item })
                }
            }
        }
    }

    val c = confirm
    if (c != null) {
        AlertDialog(
            onDismissRequest = { confirm = null },
            containerColor = SurfaceDark,
            titleContentColor = TextHi,
            textContentColor = TextLo,
            title = { Text("Remove download?") },
            text = { Text("Delete the file from your phone too, or just remove it from this list?") },
            confirmButton = {
                TextButton(onClick = {
                    Downloads.remove(c.id, true)
                    confirm = null
                }) { Text("Delete file", color = Pink) }
            },
            dismissButton = {
                TextButton(onClick = {
                    Downloads.remove(c.id, false)
                    confirm = null
                }) { Text("Only remove", color = TextHi) }
            }
        )
    }
}

@Composable
private fun EmptyState() {
    Box(Modifier.fillMaxSize().padding(bottom = 120.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            AppLogo(72.dp)
            Spacer(Modifier.height(24.dp))
            Text("Nothing here yet", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(6.dp))
            Text("Paste a link on the Home tab to start", color = TextLo, fontSize = 14.sp)
        }
    }
}

@Composable
private fun DownloadCard(item: DownloadItem, modifier: Modifier, onDelete: () -> Unit) {
    val ctx = LocalContext.current
    GlassCard(modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp)) {
            Box(
                Modifier
                    .width(112.dp)
                    .aspectRatio(16 / 9f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF1A1A26))
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(ctx).data(item.thumbnail).crossfade(true).build(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(Color(0xAA000000)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        if (item.isAudio) Icons.Rounded.MusicNote else Icons.Rounded.Videocam,
                        null, tint = Color.White, modifier = Modifier.size(13.dp)
                    )
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    item.title, color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                    maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    listOf(item.label, item.uploader).filter { it.isNotEmpty() }.joinToString(" • "),
                    color = TextLo, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            if (item.status in Downloads.ACTIVE) {
                Spacer(Modifier.width(6.dp))
                Box(
                    Modifier
                        .size(34.dp)
                        .pressable { Downloads.cancel(item.id) }
                        .clip(CircleShape)
                        .background(Glass),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Close, null, tint = TextHi, modifier = Modifier.size(18.dp)) }
            }
        }

        Column(Modifier.padding(start = 14.dp, end = 14.dp, bottom = 14.dp)) {
            when (item.status) {
                Status.QUEUED -> {
                    GradientProgress(-1f)
                    Spacer(Modifier.height(8.dp))
                    Text("Waiting in queue…", color = TextLo, fontSize = 12.sp)
                }
                Status.DOWNLOADING -> {
                    GradientProgress(item.progress)
                    Spacer(Modifier.height(8.dp))
                    val pct = if (item.progress >= 0f) "${(item.progress * 100).toInt()}% • " else ""
                    val speed = if (item.speed > 0) "${formatBytes(item.speed)}/s • " else ""
                    val size = if (item.totalBytes > 0) "${formatBytes(item.doneBytes)} / ${formatBytes(item.totalBytes)}"
                    else formatBytes(item.doneBytes)
                    Text("$pct$speed$size", color = TextLo, fontSize = 12.sp)
                }
                Status.MERGING -> {
                    GradientProgress(-1f)
                    Spacer(Modifier.height(8.dp))
                    Text(if (item.isAudio) "Finishing audio…" else "Merging video + audio…", color = TextLo, fontSize = 12.sp)
                }
                Status.SAVING -> {
                    GradientProgress(-1f)
                    Spacer(Modifier.height(8.dp))
                    Text("Saving to your phone…", color = TextLo, fontSize = 12.sp)
                }
                Status.DONE -> {
                    Text(formatBytes(item.totalBytes), color = Green, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PillButton(Icons.Rounded.PlayArrow, "Play", true) { openFile(ctx, item) }
                        PillButton(Icons.Rounded.Share, "Share", false) { shareFile(ctx, item) }
                        PillButton(Icons.Rounded.DeleteOutline, "Delete", false, onDelete)
                    }
                }
                Status.FAILED -> {
                    Text(item.error ?: "Failed", color = Pink, fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PillButton(Icons.Rounded.Refresh, "Retry", true) { Downloads.retry(item.id) }
                        PillButton(Icons.Rounded.Close, "Remove", false) { Downloads.remove(item.id, false) }
                    }
                }
            }
        }
    }
}

private fun openFile(ctx: Context, item: DownloadItem) {
    val uri = item.uri ?: return
    try {
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(Uri.parse(uri), if (item.isAudio) "audio/mp4" else "video/mp4")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "No app found to play this file", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(ctx, "The file was moved or deleted", Toast.LENGTH_SHORT).show()
    }
}

private fun shareFile(ctx: Context, item: DownloadItem) {
    val uri = item.uri ?: return
    try {
        val send = Intent(Intent.ACTION_SEND)
            .setType(if (item.isAudio) "audio/mp4" else "video/mp4")
            .putExtra(Intent.EXTRA_STREAM, Uri.parse(uri))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Couldn't share this file", Toast.LENGTH_SHORT).show()
    }
}
