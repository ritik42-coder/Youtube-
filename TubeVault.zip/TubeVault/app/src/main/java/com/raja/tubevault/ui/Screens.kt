package com.raja.tubevault.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.core.graphics.drawable.toBitmap
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.raja.tubevault.core.DownloadItem
import com.raja.tubevault.core.Downloads
import com.raja.tubevault.core.FormatOption
import com.raja.tubevault.core.MediaInfo
import com.raja.tubevault.core.Status
import com.raja.tubevault.core.formatBytes
import com.raja.tubevault.core.formatDuration
import com.raja.tubevault.core.LocalStore
import com.raja.tubevault.core.Place
import com.raja.tubevault.core.Vault
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import kotlinx.coroutines.delay

// ======================================================================= shared helpers

/** Checks Wi-Fi-only mode, then queues the download, launches the flying orb and buzzes. */
private fun startDownload(
    ctx: Context,
    vm: MainViewModel,
    info: MediaInfo,
    opt: FormatOption,
    origin: Offset,
    haptic: (HapticFeedbackType) -> Unit
) {
    if (AppSettings.wifiOnly) {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        if (cm != null && cm.isActiveNetworkMetered) {
            Toast.makeText(ctx, "Wi-Fi only is on. Connect to Wi-Fi or turn it off in Settings.", Toast.LENGTH_LONG).show()
            return
        }
    }
    haptic(HapticFeedbackType.LongPress)
    vm.download(info, opt, origin)
}

/** Dominant, vivid colour of a thumbnail – used to tint the live background. */
private fun dominantColor(d: android.graphics.drawable.Drawable): Color? = try {
    val n = 24
    val bmp = d.toBitmap(n, n)
    val px = IntArray(n * n)
    bmp.getPixels(px, 0, n, 0, 0, n, n)
    var r = 0f
    var g = 0f
    var b = 0f
    var wsum = 0f
    val hsv = FloatArray(3)
    for (c in px) {
        android.graphics.Color.colorToHSV(c, hsv)
        val wgt = hsv[1] * hsv[2] + 0.05f
        r += ((c shr 16) and 0xFF) * wgt
        g += ((c shr 8) and 0xFF) * wgt
        b += (c and 0xFF) * wgt
        wsum += wgt
    }
    val avg = android.graphics.Color.rgb((r / wsum).toInt(), (g / wsum).toInt(), (b / wsum).toInt())
    android.graphics.Color.colorToHSV(avg, hsv)
    hsv[1] = hsv[1].coerceAtLeast(0.55f)
    hsv[2] = hsv[2].coerceAtLeast(0.8f)
    Color(android.graphics.Color.HSVToColor(hsv))
} catch (e: Throwable) {
    null
}

// ======================================================================= HOME

@Composable
fun HomeScreen(vm: MainViewModel, onOpenSettings: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    var focused by remember { mutableStateOf(false) }
    val borderC by animateColorAsState(if (focused) Pink.copy(alpha = 0.9f) else GlassBorder, tween(300), label = "fb")
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(top = 18.dp, bottom = 130.dp)
    ) {
        Staggered(0) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppLogo()
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    ShimmerTitle("TubeVault")
                    Text("Save any video. Keep it forever.", color = TextLo, fontSize = 14.sp)
                }
                IconCircle(Icons.Rounded.Settings, onOpenSettings)
            }
        }

        Spacer(Modifier.height(22.dp))

        AnimatedVisibility(
            visible = vm.clipLink != null,
            enter = expandVertically(spring(dampingRatio = 0.75f, stiffness = 300f)) + fadeIn() + scaleIn(initialScale = 0.9f),
            exit = shrinkVertically(tween(250)) + fadeOut(tween(200))
        ) {
            ClipChip(vm.lastClip, onUse = { vm.useClip() }, onDismiss = { vm.dismissClip() })
        }

        Staggered(1) {
            GlassCard(
                Modifier.fillMaxWidth(),
                borderColor = borderC,
                borderWidth = if (focused) 1.5.dp else 1.dp
            ) {
                Row(
                    Modifier.padding(start = 18.dp, end = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Link, null, tint = if (focused) Pink else TextLo)
                    Spacer(Modifier.width(12.dp))
                    BasicTextField(
                        value = vm.url,
                        onValueChange = { vm.url = it },
                        singleLine = true,
                        textStyle = TextStyle(color = TextHi, fontSize = 16.sp),
                        cursorBrush = SolidColor(Pink),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = { vm.fetch() }),
                        modifier = Modifier
                            .weight(1f)
                            .padding(vertical = 18.dp)
                            .onFocusChanged { focused = it.isFocused },
                        decorationBox = { inner ->
                            Box {
                                if (vm.url.isEmpty()) {
                                    Text("Paste a video link", color = TextLo, fontSize = 16.sp)
                                }
                                inner()
                            }
                        }
                    )
                    Crossfade(vm.url.isEmpty(), label = "pasteclear") { empty ->
                        if (empty) {
                            IconCircle(Icons.Rounded.ContentPaste) {
                                val text = clipboard.getText()?.text
                                if (!text.isNullOrBlank()) {
                                    vm.url = text
                                    vm.fetch()
                                }
                            }
                        } else {
                            IconCircle(Icons.Rounded.Close) { vm.clear() }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        Staggered(2) {
            GradientButton(
                text = "Get download options",
                loading = vm.state is FetchState.Loading
            ) { vm.fetch() }
        }

        Spacer(Modifier.height(22.dp))

        AnimatedContent(
            targetState = vm.state,
            transitionSpec = {
                (fadeIn(tween(350)) + slideInVertically(tween(450)) { it / 8 } + scaleIn(tween(450), 0.97f)) togetherWith
                    fadeOut(tween(200))
            },
            contentKey = { it::class },
            label = "result"
        ) { st ->
            when (st) {
                is FetchState.Idle -> HintCard()
                is FetchState.Loading -> SkeletonCard()
                is FetchState.Error -> ErrorCard(st.message)
                is FetchState.Ready -> ResultCard(st.info, vm)
            }
        }
    }
}

@Composable
private fun IconCircle(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .pressable(onClick)
            .clip(CircleShape)
            .background(Glass),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = TextHi, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun HintCard() {
    GlassCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("How it works", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text("1.  Copy a video link from YouTube or 1,800+ other sites (or tap Share → TubeVault)", color = TextLo, fontSize = 14.sp)
            Text("2.  Paste it here and pick a quality or audio only", color = TextLo, fontSize = 14.sp)
            Text("3.  Find it in Library and in your Gallery → Movies/TubeVault", color = TextLo, fontSize = 14.sp)
            Text(
                "Please only download videos you own or have permission to save.",
                color = TextLo.copy(alpha = 0.7f), fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun ErrorCard(message: String) {
    val s = remember { Animatable(0f) }
    LaunchedEffect(Unit) { s.animateTo(1f, spring(dampingRatio = 0.3f, stiffness = 200f)) }
    GlassCard(Modifier.fillMaxWidth(), borderColor = Pink.copy(alpha = 0.5f)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Rounded.ErrorOutline, null, tint = Pink,
                modifier = Modifier
                    .size(28.dp)
                    .graphicsLayer {
                        scaleX = s.value
                        scaleY = s.value
                    }
            )
            Spacer(Modifier.width(14.dp))
            Column {
                Text("Couldn't load this video", color = TextHi, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(message, color = TextLo, fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun SkeletonCard() {
    val brush = shimmerBrush()
    GlassCard(Modifier.fillMaxWidth()) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(16 / 9f)
                .background(brush)
        )
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.fillMaxWidth(0.9f).height(18.dp).clip(RoundedCornerShape(8.dp)).background(brush))
            Box(Modifier.fillMaxWidth(0.5f).height(14.dp).clip(RoundedCornerShape(8.dp)).background(brush))
            repeat(3) {
                Box(Modifier.fillMaxWidth().height(58.dp).clip(RoundedCornerShape(18.dp)).background(brush))
            }
        }
    }
}

@Composable
private fun ResultCard(info: MediaInfo, vm: MainViewModel) {
    val ctx = LocalContext.current
    val haptic = rememberHaptics()
    val start: (FormatOption, Offset) -> Unit = { opt, origin -> startDownload(ctx, vm, info, opt, origin, haptic) }
    GlassCard(Modifier.fillMaxWidth()) {
        Box {
            AsyncImage(
                model = ImageRequest.Builder(ctx)
                    .data(info.thumbnail)
                    .crossfade(true)
                    .allowHardware(false)
                    .listener(onSuccess = { _, result -> vm.ambient = dominantColor(result.drawable) })
                    .build(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16 / 9f)
                    .background(Color(0xFF1A1A26))
            )
            val dur = formatDuration(info.durationSec)
            if (dur.isNotEmpty()) {
                Text(
                    dur,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(10.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xCC000000))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }
        Column(Modifier.padding(18.dp)) {
            Text(
                info.title,
                color = TextHi,
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            if (info.uploader.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text(info.uploader, color = TextLo, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(16.dp))

            // Where to save: Private (default, hidden from Gallery) / Gallery / Vault
            Text("Save to", color = TextLo, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            SaveToSelector(vm.place) { vm.place = it }
            Spacer(Modifier.height(16.dp))

            // One-tap smart buttons
            val bestV = info.videoFormats.firstOrNull()
            val bestA = info.audioFormats.firstOrNull()
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (bestV != null) {
                    QuickButton(
                        Modifier.weight(1f), Icons.Rounded.Bolt, "Best video", bestV.label,
                        Brush.linearGradient(listOf(Violet, Pink, Orange)), vm.isQueued(bestV)
                    ) { start(bestV, it) }
                }
                if (bestA != null) {
                    QuickButton(
                        Modifier.weight(1f), Icons.Rounded.MusicNote, "Best audio",
                        bestA.detail.removePrefix("AAC • ").substringBefore(" •"),
                        Brush.linearGradient(listOf(Violet, Cyan)), vm.isQueued(bestA)
                    ) { start(bestA, it) }
                }
            }
            Spacer(Modifier.height(16.dp))

            Segmented(listOf("Video", "Audio"), vm.formatTab) { vm.formatTab = it }
            Spacer(Modifier.height(14.dp))

            Crossfade(vm.formatTab, label = "formats") { tab ->
                val list = if (tab == 0) info.videoFormats else info.audioFormats
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (list.isEmpty()) {
                        Text("Nothing available in this category.", color = TextLo, fontSize = 14.sp)
                    }
                    list.forEachIndexed { i, opt ->
                        Staggered(i) {
                            FormatRow(opt, vm.isQueued(opt)) { origin -> start(opt, origin) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickButton(
    modifier: Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    sub: String,
    brush: Brush,
    done: Boolean,
    onClick: (Offset) -> Unit
) {
    val pos = remember { OffsetRef() }
    Row(
        modifier
            .trackCenter(pos)
            .pressable { if (!done) onClick(pos.value) }
            .clip(RoundedCornerShape(18.dp))
            .background(brush)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(28.dp), contentAlignment = Alignment.Center) {
            if (done) AnimatedCheck(Color.White, Modifier.size(24.dp))
            else Icon(icon, null, tint = Color.White, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.width(8.dp))
        Column {
            Text(if (done) "Queued" else title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(sub, color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp, maxLines = 1)
        }
    }
}

@Composable
private fun FormatRow(opt: FormatOption, queued: Boolean, onDownload: (Offset) -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    val pos = remember { OffsetRef() }
    val sweep = remember { Animatable(0f) }
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(queued) {
        if (first) {
            first = false
        } else if (queued) {
            sweep.snapTo(0f)
            sweep.animateTo(1f, tween(800))
        }
    }
    Row(
        Modifier
            .fillMaxWidth()
            .pressable { if (!queued) onDownload(pos.value) }
            .clip(shape)
            .background(Color(0x0DFFFFFF))
            .drawBehind {
                val s = sweep.value
                if (s > 0f && s < 1f) {
                    val x = (s * 1.6f - 0.3f) * size.width
                    drawRect(
                        Brush.horizontalGradient(
                            listOf(Color.Transparent, Green.copy(alpha = 0.28f), Color.Transparent),
                            startX = x - 120f, endX = x + 120f
                        )
                    )
                }
            }
            .border(BorderStroke(1.dp, GlassBorder), shape)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(if (opt.isAudio) Violet.copy(alpha = 0.25f) else Pink.copy(alpha = 0.22f))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Text(opt.label, color = TextHi, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
        Spacer(Modifier.width(14.dp))
        Text(opt.detail, color = TextLo, fontSize = 13.sp, modifier = Modifier.weight(1f))
        AnimatedContent(
            targetState = queued,
            transitionSpec = { (scaleIn(spring(0.5f, Spring.StiffnessMedium)) + fadeIn()) togetherWith (scaleOut() + fadeOut()) },
            label = "dlbtn"
        ) { q ->
            Box(
                Modifier
                    .size(40.dp)
                    .trackCenter(pos)
                    .clip(CircleShape)
                    .background(if (q) Color(0x3334D399) else Pink.copy(alpha = 0.9f)),
                contentAlignment = Alignment.Center
            ) {
                if (q) {
                    AnimatedCheck(Green, Modifier.size(24.dp))
                } else {
                    Icon(Icons.Rounded.Download, null, tint = Color.White, modifier = Modifier.size(22.dp))
                }
            }
        }
    }
}

// ======================================================================= LIBRARY

/** Ids whose entrance animation already played, so scrolling doesn't replay it. */
private val seenIds = HashSet<String>()

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LibraryScreen(list: List<DownloadItem>) {
    var confirm by remember { mutableStateOf<DownloadItem?>(null) }
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableIntStateOf(0) }

    val shown = list.filter {
        (filter == 0 || (filter == 1 && !it.isAudio) || (filter == 2 && it.isAudio) || filter == 3) &&
            (query.isBlank() || it.title.contains(query, true) || it.uploader.contains(query, true))
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
            .padding(top = 18.dp)
    ) {
        Staggered(0) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // long-press the title also opens the Vault (handy when the button is hidden)
                Column(
                    Modifier
                        .weight(1f)
                        .pointerInput(Unit) { detectTapGestures(onLongPress = { Vault.open = true }) }
                ) {
                    ShimmerTitle("Library")
                    val priv = list.count { it.place == Place.PRIVATE && it.status == Status.DONE }
                    val gal = list.count { it.place == Place.GALLERY && it.status == Status.DONE }
                    Text(
                        if (list.isEmpty()) "Your downloads will appear here"
                        else "${list.size} item${if (list.size == 1) "" else "s"} • $priv private • $gal in Gallery",
                        color = TextLo, fontSize = 14.sp
                    )
                }
                if (!AppSettings.hideVaultButton) {
                    Spacer(Modifier.width(10.dp))
                    VaultEntryButton { Vault.open = true }
                }
            }
        }
        Spacer(Modifier.height(18.dp))

        if (list.isEmpty()) {
            EmptyState()
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 130.dp)
            ) {
                item(key = "stats") { VaultStats(list) }
                item(key = "search") {
                    Column {
                        SearchField(query) { query = it }
                        Spacer(Modifier.height(10.dp))
                        Segmented(listOf("All", "Video", "Audio", "Lists"), filter) { filter = it }
                    }
                }
                if (filter == 3) {
                    item(key = "playlists") { PlaylistsTab(list) }
                } else if (filter == 2 && shown.any { it.status == Status.DONE }) {
                    item(key = "audioactions") { AudioActions(shown.filter { it.status == Status.DONE && it.uri != null }) }
                }
                if (filter != 3 && shown.isEmpty()) {
                    item(key = "nomatch") {
                        Text(
                            "No matches. Try another search or filter.",
                            color = TextLo, fontSize = 14.sp,
                            modifier = Modifier.padding(vertical = 24.dp)
                        )
                    }
                }
                items(if (filter == 3) emptyList() else shown, key = { it.id }) { item ->
                    val vs = remember(item.id) {
                        val s = MutableTransitionState(seenIds.contains(item.id))
                        seenIds.add(item.id)
                        s.targetState = true
                        s
                    }
                    AnimatedVisibility(
                        visibleState = vs,
                        modifier = Modifier.animateItemPlacement(tween(350)),
                        enter = fadeIn(tween(400)) + expandVertically(spring(dampingRatio = 0.75f, stiffness = 300f)) +
                            scaleIn(spring(dampingRatio = 0.7f, stiffness = 300f), 0.9f)
                    ) {
                        DownloadCard(item, Modifier, onDelete = { confirm = item })
                    }
                }
            }
        }
    }

    val c = confirm
    if (c != null) {
        AlertDialog(
            onDismissRequest = { confirm = null },
            containerColor = SurfaceDark,
            titleContentColor = TextHi,
            textContentColor = TextLo,
            title = { Text("Remove download?") },
            text = { Text("Delete the file from your phone too, or just remove it from this list?") },
            confirmButton = {
                TextButton(onClick = {
                    Downloads.remove(c.id, true)
                    confirm = null
                }) { Text("Delete file", color = Pink) }
            },
            dismissButton = {
                TextButton(onClick = {
                    Downloads.remove(c.id, false)
                    confirm = null
                }) { Text("Only remove", color = TextHi) }
            }
        )
    }
}

@Composable
private fun SearchField(query: String, onChange: (String) -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val bc by animateColorAsState(if (focused) Pink.copy(alpha = 0.9f) else GlassBorder, tween(300), label = "sb")
    GlassCard(Modifier.fillMaxWidth(), corner = 20.dp, borderColor = bc) {
        Row(Modifier.padding(start = 16.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Search, null, tint = if (focused) Pink else TextLo)
            Spacer(Modifier.width(10.dp))
            BasicTextField(
                value = query,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(color = TextHi, fontSize = 15.sp),
                cursorBrush = SolidColor(Pink),
                modifier = Modifier
                    .weight(1f)
                    .padding(vertical = 14.dp)
                    .onFocusChanged { focused = it.isFocused },
                decorationBox = { inner ->
                    Box {
                        if (query.isEmpty()) Text("Search your vault", color = TextLo, fontSize = 15.sp)
                        inner()
                    }
                }
            )
            AnimatedVisibility(query.isNotEmpty(), enter = scaleIn() + fadeIn(), exit = scaleOut() + fadeOut()) {
                Box(
                    Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                            onChange("")
                        },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Close, null, tint = TextLo, modifier = Modifier.size(18.dp)) }
            }
        }
    }
}

@Composable
private fun EmptyState() {
    val t = rememberInfiniteTransition(label = "float")
    val y by t.animateFloat(
        -8f, 8f, infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "fy"
    )
    Box(Modifier.fillMaxSize().padding(bottom = 120.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.graphicsLayer { translationY = y * density }) { AppLogo(72.dp) }
            Spacer(Modifier.height(24.dp))
            Text("Nothing here yet", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(6.dp))
            Text("Paste a link on the Home tab to start", color = TextLo, fontSize = 14.sp)
        }
    }
}

@Composable
private fun DownloadCard(item: DownloadItem, modifier: Modifier, onDelete: () -> Unit) {
    val ctx = LocalContext.current
    val active = item.status in Downloads.ACTIVE
    val wasActive = remember { mutableStateOf(active) }
    var celebrate by remember { mutableStateOf(false) }
    LaunchedEffect(item.status) {
        if (item.status in Downloads.ACTIVE) {
            wasActive.value = true
        } else if (item.status == Status.DONE && wasActive.value) {
            wasActive.value = false
            celebrate = true
            delay(1900)
            celebrate = false
        }
    }
    val glow by animateFloatAsState(if (celebrate) 1f else 0f, tween(500), label = "glow")
    val hist = remember(item.id) { mutableStateListOf<Float>() }
    LaunchedEffect(item.speed) {
        if (item.status == Status.DOWNLOADING && item.speed > 0) {
            hist.add(item.speed.toFloat())
            if (hist.size > 36) hist.removeAt(0)
        }
    }

    Box(modifier.fillMaxWidth()) {
        GlassCard(
            Modifier
                .fillMaxWidth()
                .drawBehind {
                    if (glow > 0f) {
                        drawRoundRect(Green.copy(alpha = 0.16f * glow), cornerRadius = CornerRadius(24.dp.toPx()))
                    }
                },
            borderColor = lerp(GlassBorder, Green.copy(alpha = 0.9f), glow),
            borderWidth = if (glow > 0.01f) 1.5.dp else 1.dp
        ) {
            Row(Modifier.padding(12.dp)) {
                Box(
                    Modifier
                        .width(112.dp)
                        .aspectRatio(16 / 9f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF1A1A26))
                        .then(
                            if (item.status == Status.DONE) Modifier.pressable {
                                if (!PlayerHost.open(Downloads.items.value, item.id)) openFile(ctx, item)
                            } else Modifier
                        )
                ) {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(
                                Brush.linearGradient(
                                    if (item.isAudio) listOf(Color(0xFF3B1F5C), Color(0xFF1A1A26))
                                    else listOf(Color(0xFF3A1626), Color(0xFF1A1A26))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            if (item.place == Place.VAULT) Icons.Rounded.Lock
                            else if (item.isAudio) Icons.Rounded.MusicNote else Icons.Rounded.Videocam,
                            null, tint = Color(0x66FFFFFF), modifier = Modifier.size(30.dp)
                        )
                    }
                    AsyncImage(
                        model = ImageRequest.Builder(ctx).data(item.thumbnail).crossfade(true).build(),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        Modifier
                            .align(Alignment.TopStart)
                            .padding(6.dp)
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(Color(0xAA000000)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            if (item.isAudio) Icons.Rounded.MusicNote else Icons.Rounded.Videocam,
                            null, tint = Color.White, modifier = Modifier.size(13.dp)
                        )
                    }
                    if (item.status == Status.DONE || item.place == Place.VAULT) {
                        PlaceBadge(item.place, Modifier.align(Alignment.TopEnd).padding(6.dp))
                    }
                    if (item.status == Status.DONE && item.uri != null) {
                        Box(
                            Modifier
                                .align(Alignment.Center)
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(Color(0x88000000))
                                .border(1.dp, Color(0x66FFFFFF), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Rounded.PlayArrow, null, tint = Color.White, modifier = Modifier.size(22.dp))
                        }
                    }
                    val overlayA by animateFloatAsState(if (active) 1f else 0f, tween(300), label = "ovl")
                    if (overlayA > 0.01f) {
                        Box(
                            Modifier
                                .fillMaxSize()
                                .graphicsLayer { alpha = overlayA }
                                .background(Color(0x99000000)),
                            contentAlignment = Alignment.Center
                        ) {
                            val determinate = item.status == Status.DOWNLOADING && item.progress >= 0f
                            RingProgress(if (determinate) item.progress else -1f, Modifier.size(46.dp), stroke = 4.dp) {
                                if (determinate) {
                                    Text(
                                        "${(item.progress * 100).toInt()}%",
                                        color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp
                                    )
                                } else {
                                    Icon(Icons.Rounded.Download, null, tint = Color.White, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                    if (celebrate) {
                        Box(
                            Modifier
                                .fillMaxSize()
                                .background(Color(0xAA10B981)),
                            contentAlignment = Alignment.Center
                        ) { AnimatedCheck(Color.White, Modifier.size(34.dp)) }
                    }
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        item.title, color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                        maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        listOf(item.label, item.uploader).filter { it.isNotEmpty() }.joinToString(" • "),
                        color = TextLo, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
                if (active) {
                    Spacer(Modifier.width(6.dp))
                    Box(
                        Modifier
                            .size(34.dp)
                            .pressable { Downloads.cancel(item.id) }
                            .clip(CircleShape)
                            .background(Glass),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Rounded.Close, null, tint = TextHi, modifier = Modifier.size(18.dp)) }
                }
            }

            AnimatedContent(
                targetState = item.status,
                transitionSpec = {
                    (fadeIn(tween(300)) + slideInVertically(tween(300)) { it / 4 }) togetherWith fadeOut(tween(150))
                },
                label = "cardstate"
            ) { st ->
                Column(Modifier.padding(start = 14.dp, end = 14.dp, bottom = 14.dp)) {
                    when (st) {
                        Status.QUEUED -> {
                            StageTracker(0, item.isAudio)
                            Spacer(Modifier.height(10.dp))
                            GradientProgress(-1f)
                            Spacer(Modifier.height(8.dp))
                            Text("Waiting in queue…", color = TextLo, fontSize = 12.sp)
                        }
                        Status.DOWNLOADING -> {
                            StageTracker(1, item.isAudio)
                            Spacer(Modifier.height(10.dp))
                            GradientProgress(item.progress)
                            Spacer(Modifier.height(8.dp))
                            val size = if (item.totalBytes > 0) "${formatBytes(item.doneBytes)} / ${formatBytes(item.totalBytes)}"
                            else formatBytes(item.doneBytes)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(size, color = TextLo, fontSize = 12.sp, modifier = Modifier.weight(1f))
                                if (item.speed > 0) {
                                    Icon(Icons.Rounded.Bolt, null, tint = Orange, modifier = Modifier.size(14.dp))
                                    val left = item.totalBytes - item.doneBytes
                                    val eta = if (item.totalBytes > 0 && left > 0) " • ${formatEta(left / item.speed)} left" else ""
                                    Text(
                                        "${formatBytes(item.speed)}/s$eta",
                                        color = TextHi, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                            AnimatedVisibility(hist.size >= 2) {
                                Sparkline(hist, Modifier.fillMaxWidth().padding(top = 8.dp).height(36.dp))
                            }
                        }
                        Status.MERGING -> {
                            StageTracker(2, item.isAudio)
                            Spacer(Modifier.height(10.dp))
                            GradientProgress(-1f)
                            Spacer(Modifier.height(8.dp))
                            Text(if (item.isAudio) "Finishing audio…" else "Merging video + audio…", color = TextLo, fontSize = 12.sp)
                        }
                        Status.SAVING -> {
                            StageTracker(3, item.isAudio)
                            Spacer(Modifier.height(10.dp))
                            GradientProgress(-1f)
                            Spacer(Modifier.height(8.dp))
                            Text("Saving to your phone…", color = TextLo, fontSize = 12.sp)
                        }
                        Status.DONE -> {
                            if (item.place == Place.VAULT && item.uri == null) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.Lock, null, tint = Orange, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        "Encrypted & locked in your Vault",
                                        color = Orange, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Spacer(Modifier.height(10.dp))
                                PillButton(Icons.Rounded.Lock, "Open Vault", true) { Vault.open = true }
                            } else {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.CheckCircle, null, tint = Green, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    val where = when (item.place) {
                                        Place.PRIVATE -> "Saved privately"
                                        Place.GALLERY -> "In Gallery"
                                        Place.VAULT -> "In Vault"
                                    }
                                    Text(
                                        "$where • ${formatBytes(item.totalBytes)}",
                                        color = Green, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Spacer(Modifier.height(10.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    PillButton(Icons.Rounded.PlayArrow, "Play", true) {
                                        if (!PlayerHost.open(Downloads.items.value, item.id)) openFile(ctx, item)
                                    }
                                    PlayerIconButton(Icons.Rounded.Share, { shareFile(ctx, item) }, size = 38.dp)
                                    PlayerIconButton(Icons.Rounded.DeleteOutline, onDelete, size = 38.dp)
                                    if (item.isAudio) PlaylistAddButton(item)
                                    MoveMenuButton(item)
                                }
                            }
                        }
                        Status.FAILED -> {
                            Text(item.error ?: "Failed", color = Pink, fontSize = 12.sp)
                            Spacer(Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                PillButton(Icons.Rounded.Refresh, "Retry", true) { Downloads.retry(item.id) }
                                PillButton(Icons.Rounded.Close, "Remove", false) { Downloads.remove(item.id, false) }
                            }
                        }
                    }
                }
            }
        }
        if (celebrate) {
            ConfettiBurst(Modifier.matchParentSize(), originX = 0.2f, originY = 0.35f, count = 36)
        }
    }
}

/** Four-step tracker: Queue → Download → Merge → Save. */
@Composable
private fun StageTracker(stage: Int, audio: Boolean) {
    val pulse = rememberInfiniteTransition(label = "stagepulse")
    val sc by pulse.animateFloat(
        1f, 1.4f, infiniteRepeatable(tween(700, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "sc"
    )
    val names = listOf("Queue", "Download", if (audio) "Finish" else "Merge", "Save")
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        for (i in 0 until 4) {
            val dotMod = Modifier
                .size(12.dp)
                .graphicsLayer {
                    val s = if (i == stage) sc else 1f
                    scaleX = s
                    scaleY = s
                }
                .clip(CircleShape)
            Box(
                when {
                    i < stage -> dotMod.background(Green)
                    i == stage -> dotMod.background(AccentBrush2)
                    else -> dotMod.background(Color(0x33FFFFFF))
                }
            )
            if (i < 3) {
                val fill by animateFloatAsState(if (stage > i) 1f else 0f, tween(500), label = "line")
                Box(
                    Modifier
                        .weight(1f)
                        .padding(horizontal = 4.dp)
                        .height(3.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(Color(0x22FFFFFF))
                ) {
                    Box(
                        Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(fill)
                            .background(Green)
                    )
                }
            }
        }
    }
    Spacer(Modifier.height(4.dp))
    Text(names[stage.coerceIn(0, 3)], color = TextLo, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
}

internal fun openFile(ctx: Context, item: DownloadItem) {
    val uri = item.uri ?: return
    try {
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(LocalStore.shareUri(ctx, uri), mimeFor(item))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "No app found to play this file", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(ctx, "The file was moved or deleted", Toast.LENGTH_SHORT).show()
    }
}

private fun shareFile(ctx: Context, item: DownloadItem) {
    val uri = item.uri ?: return
    try {
        val send = Intent(Intent.ACTION_SEND)
            .setType(mimeFor(item))
            .putExtra(Intent.EXTRA_STREAM, LocalStore.shareUri(ctx, uri))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Couldn't share this file", Toast.LENGTH_SHORT).show()
    }
}

private fun mimeFor(item: DownloadItem): String {
    val f = LocalStore.fileOf(item.uri)
    return if (f != null) LocalStore.mimeOf(f.name, item.isAudio) else if (item.isAudio) "audio/mp4" else "video/mp4"
}
