package com.raja.tubevault.ui

import android.os.Environment
import android.os.StatFs
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raja.tubevault.core.DownloadItem
import com.raja.tubevault.core.Status
import com.raja.tubevault.core.formatBytes

// ============================================================ settings

@Composable
fun SettingsPanel(visible: Boolean, onClose: () -> Unit) {
    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(visible, enter = fadeIn(tween(250)), exit = fadeOut(tween(250))) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color(0xAA000000))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                        onClose()
                    }
            )
        }
        AnimatedVisibility(
            visible,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(spring(dampingRatio = 0.8f, stiffness = 320f)) { it } + fadeIn(tween(200)),
            exit = slideOutVertically(tween(260)) { it } + fadeOut(tween(200))
        ) {
            SettingsSheet()
        }
    }
}

@Composable
private fun SettingsSheet() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Color(0xF4101018))
            .border(BorderStroke(1.dp, GlassBorder), shape)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
            .heightIn(max = 720.dp)
            .verticalScroll(rememberScrollState())
            .navigationBarsPadding()
            .padding(horizontal = 22.dp)
            .padding(top = 12.dp, bottom = 22.dp)
    ) {
        Box(
            Modifier
                .align(Alignment.CenterHorizontally)
                .width(42.dp)
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(Color(0x33FFFFFF))
        )
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Settings, null, tint = Pink)
            Spacer(Modifier.width(10.dp))
            Text("Settings", color = TextHi, fontWeight = FontWeight.Black, fontSize = 22.sp)
        }
        Spacer(Modifier.height(18.dp))
        if (!Premium.isPremium) {
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                    .background(androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(Color(0xFFFFD66B), Color(0xFFFF9A1F))))
                    .clickable { Premium.openRequest = true }.padding(16.dp)
            ) { Text("👑  Go Premium · Remove all ads", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 16.sp) }
        } else {
            Text("👑  Premium active · No ads", color = Color(0xFFFFC83D), fontWeight = FontWeight.Black, fontSize = 16.sp)
        }
        Spacer(Modifier.height(16.dp))
        // Default save location (each download can still choose its own)
        Text("Save new downloads to", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        SaveToSelector(AppSettings.defaultPlace) { AppSettings.changeDefaultPlace(it) }
        Spacer(Modifier.height(6.dp))
        SettingRow(
            Icons.Rounded.Lock, "Hide Vault button",
            "Hide the lock button in the Library. Open the Vault by long-pressing the \"Library\" title instead.",
            AppSettings.hideVaultButton
        ) { AppSettings.changeHideVaultButton(it) }
        SettingRow(
            Icons.Rounded.Wifi, "Wi-Fi only",
            "Never spend mobile data. Downloads are blocked on metered networks.",
            AppSettings.wifiOnly
        ) { AppSettings.changeWifiOnly(it) }
        SettingRow(
            Icons.Rounded.AutoAwesome, "Live background",
            "Animated streams and tilt parallax. Turn off to save battery.",
            AppSettings.liveBg
        ) { AppSettings.changeLiveBg(it) }
        SettingRow(
            Icons.Rounded.Vibration, "Haptic feedback",
            "Feel every download start and finish.",
            AppSettings.haptics
        ) { AppSettings.changeHaptics(it) }
        SettingRow(
            Icons.Rounded.MusicNote, "Island over other apps",
            "Floating music island on top of other apps and your home screen while music plays. Needs \"display over other apps\" permission.",
            AppSettings.islandOverlay
        ) {
            AppSettings.changeIslandOverlay(it)
            if (it && !com.raja.tubevault.core.IslandController.canDraw(ctx)) {
                try {
                    ctx.startActivity(
                        android.content.Intent(
                            android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            android.net.Uri.parse("package:" + ctx.packageName)
                        ).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (_: Throwable) {
                }
            }
        }
        SettingRow(
            Icons.Rounded.GraphicEq, "Island inside TubeVault",
            "Show the mini player pill at the top of the app while music plays.",
            AppSettings.islandInApp
        ) { AppSettings.changeIslandInApp(it) }
        Spacer(Modifier.height(10.dp))
        UpdateSettingsCard()
        SettingRow(
            Icons.Rounded.Sync, "Auto-check for updates",
            "Look for a new TubeVault version whenever you open the app.",
            AppSettings.autoUpdate
        ) { AppSettings.changeAutoUpdate(it) }
        SettingRow(
            Icons.Rounded.CloudDownload, "Download updates on Wi-Fi",
            "Fetch a found update in the background, only on Wi-Fi. You still tap Install.",
            AppSettings.autoDownloadUpdate
        ) { AppSettings.changeAutoDownloadUpdate(it) }
        Spacer(Modifier.height(6.dp))
        Text("TubeVault " + com.raja.tubevault.BuildConfig.VERSION_NAME + " • Only save videos you have permission to download.", color = TextLo.copy(alpha = 0.7f), fontSize = 11.sp)
    }
}

@Composable
private fun SettingRow(icon: ImageVector, title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Glass),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = if (checked) Pink else TextLo) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = TextHi, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(2.dp))
            Text(desc, color = TextLo, fontSize = 12.sp)
        }
        Spacer(Modifier.width(12.dp))
        PremiumSwitch(checked, onChange)
    }
}

@Composable
fun PremiumSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val x by animateDpAsState(if (checked) 24.dp else 4.dp, spring(dampingRatio = 0.55f, stiffness = 500f), label = "sw")
    val on by animateFloatAsState(if (checked) 1f else 0f, tween(250), label = "swon")
    Box(
        Modifier
            .width(54.dp)
            .height(32.dp)
            .clip(CircleShape)
            .background(Color(0x22FFFFFF))
            .background(AccentBrush, CircleShape, on)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                onChange(!checked)
            }
    ) {
        Box(
            Modifier
                .offset(x = x, y = 4.dp)
                .size(24.dp)
                .clip(CircleShape)
                .background(Color.White)
        )
    }
}

// ============================================================ clipboard chip

@Composable
fun ClipChip(link: String, onUse: () -> Unit, onDismiss: () -> Unit) {
    val t = rememberInfiniteTransition(label = "clip")
    val glow by t.animateFloat(
        0.25f, 0.9f, infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "g"
    )
    val shape = RoundedCornerShape(20.dp)
    val short = link.removePrefix("https://").removePrefix("http://").removePrefix("www.")
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp)
            .pressable(onUse)
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(Pink.copy(alpha = 0.18f), Violet.copy(alpha = 0.18f))))
            .border(BorderStroke(1.dp, Pink.copy(alpha = glow)), shape)
            .padding(start = 12.dp, top = 10.dp, bottom = 10.dp, end = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(AccentBrush2),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(20.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("Video link found • tap to fetch", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(short, color = TextLo, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(
            Modifier
                .size(34.dp)
                .clip(CircleShape)
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onDismiss() },
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.Close, null, tint = TextLo, modifier = Modifier.size(18.dp)) }
    }
}

// ============================================================ completion banner

data class Banner(val id: Long, val title: String, val ok: Boolean)

@Composable
fun BannerHost(visible: Boolean, banner: Banner?, onClick: () -> Unit, modifier: Modifier = Modifier) {
    AnimatedVisibility(
        visible,
        modifier = modifier,
        enter = slideInVertically(spring(dampingRatio = 0.65f, stiffness = 380f)) { -it * 2 } +
            fadeIn(tween(200)) + scaleIn(initialScale = 0.85f),
        exit = slideOutVertically(tween(320)) { -it * 2 } + fadeOut(tween(250))
    ) {
        if (banner != null) key(banner.id) { BannerCard(banner, onClick) }
    }
}

@Composable
private fun BannerCard(b: Banner, onClick: () -> Unit) {
    val accent = if (b.ok) Green else Pink
    val shape = RoundedCornerShape(22.dp)
    Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        if (b.ok) {
            ConfettiBurst(Modifier.fillMaxWidth().height(170.dp), originX = 0.13f, originY = 0.3f, count = 46)
        }
        Row(
            Modifier
                .fillMaxWidth()
                .pressable(onClick)
                .clip(shape)
                .background(Color(0xF2141420))
                .border(BorderStroke(1.dp, accent.copy(alpha = 0.6f)), shape)
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val s = remember { Animatable(0f) }
            LaunchedEffect(Unit) { s.animateTo(1f, tween(750)) }
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(accent.copy(alpha = 0.22f)),
                contentAlignment = Alignment.Center
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val v = s.value
                    drawCircle(
                        accent.copy(alpha = (1f - v) * 0.7f),
                        radius = size.minDimension / 2f * (0.6f + 0.4f * v),
                        style = Stroke(2.dp.toPx())
                    )
                }
                if (b.ok) AnimatedCheck(accent, Modifier.size(26.dp))
                else Icon(Icons.Rounded.ErrorOutline, null, tint = accent, modifier = Modifier.size(26.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    if (b.ok) "Download complete" else "Download failed",
                    color = TextHi, fontWeight = FontWeight.Bold, fontSize = 14.sp
                )
                Text(b.title, color = TextLo, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.width(8.dp))
            Text(
                "View",
                color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(AccentBrush)
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }
    }
}

// ============================================================ vault stats

private val ranks = listOf(
    "Rookie" to 0, "Collector" to 3, "Hoarder" to 10, "Curator" to 25, "Archivist" to 50, "Legend" to 100
)

private fun freeBytes(): Long = try {
    StatFs(Environment.getExternalStorageDirectory().path).availableBytes
} catch (e: Exception) {
    0L
}

@Composable
fun VaultStats(list: List<DownloadItem>) {
    val done = list.filter { it.status == Status.DONE }
    val count = done.size
    val bytes = done.sumOf { it.totalBytes }
    val videos = done.count { !it.isAudio }
    val audios = count - videos
    val idx = ranks.indexOfLast { count >= it.second }.coerceAtLeast(0)
    val cur = ranks[idx]
    val next = ranks.getOrNull(idx + 1)
    val prog = if (next == null) 1f else (count - cur.second).toFloat() / (next.second - cur.second)
    val free = remember { freeBytes() }

    var tProg by remember { mutableFloatStateOf(0f) }
    var tBytes by remember { mutableFloatStateOf(0f) }
    var tCount by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(prog, bytes, count) {
        tProg = prog
        tBytes = bytes.toFloat()
        tCount = count.toFloat()
    }
    val shownBytes by animateFloatAsState(tBytes, tween(1400, easing = FastOutSlowInEasing), label = "vb")
    val shownCount by animateFloatAsState(tCount, tween(1100, easing = FastOutSlowInEasing), label = "vc")

    GlassCard(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            RingProgress(tProg, Modifier.size(84.dp), stroke = 6.dp) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${shownCount.toInt()}", color = TextHi, fontWeight = FontWeight.Black, fontSize = 24.sp)
                    Text("saved", color = TextLo, fontSize = 10.sp)
                }
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.EmojiEvents, null, tint = Orange, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        cur.first,
                        style = TextStyle(brush = AccentBrush, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    )
                }
                Text(
                    if (next == null) "Max rank reached" else "${next.second - count} more to ${next.first}",
                    color = TextLo, fontSize = 12.sp
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    Column {
                        Text(formatBytes(shownBytes.toLong()), color = TextHi, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("$videos video • $audios audio", color = TextLo, fontSize = 11.sp)
                    }
                    if (free > 0) {
                        Column {
                            Text(formatBytes(free), color = Green, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("free on phone", color = TextLo, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}
