package com.raja.tubevault.core

import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.schabi.newpipe.extractor.services.youtube.YoutubeParsingHelper
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

class HttpStatusException(val code: Int) : IOException("HTTP $code")

object Net {
    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(40, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    private const val CHUNK = 10L * 1024 * 1024
    private val POST_BODY = byteArrayOf(0x78, 0)

    fun userAgent(url: String): String =
        if (YoutubeParsingHelper.isVisionOsStreamingUrl(url)) {
            YoutubeParsingHelper.getVisionOsUserAgent(null)
        } else NpDownloader.USER_AGENT

    /**
     * Downloads [url] into [dest]. YouTube streams are fetched in 10 MB pieces with the
     * `range` parameter (the same way NewPipe does it) which avoids throttling.
     */
    suspend fun download(url: String, dest: File, onBytes: (Long) -> Unit) {
        val ctx = currentCoroutineContext()
        val isPlayback = url.contains("/videoplayback")
        var offset = 0L
        var rn = 0
        var failures = 0
        var usePost = true
        var finished = false
        val buf = ByteArray(64 * 1024)

        FileOutputStream(dest).use { out ->
            while (!finished) {
                ctx.ensureActive()
                val end = offset + CHUNK - 1
                var reqUrl = url
                val rb = Request.Builder()
                    .header("User-Agent", userAgent(url))
                    .header("Accept-Encoding", "identity")

                if (isPlayback) {
                    if (!url.contains("&rn=")) {
                        reqUrl += "&rn=$rn"
                        rn++
                    }
                    reqUrl += "&range=$offset-$end"
                    if (YoutubeParsingHelper.isWebStreamingUrl(url)) {
                        rb.header("Origin", "https://www.youtube.com")
                        rb.header("Referer", "https://www.youtube.com/")
                    }
                    if (usePost) rb.post(POST_BODY.toRequestBody()) else rb.get()
                } else {
                    if (offset > 0) rb.header("Range", "bytes=$offset-")
                    rb.get()
                }
                rb.url(reqUrl)

                try {
                    client.newCall(rb.build()).execute().use { resp ->
                        val code = resp.code
                        if (code == 416) {
                            finished = true
                        } else {
                            if (code != 200 && code != 206) throw HttpStatusException(code)
                            if (!isPlayback && offset > 0 && code == 200) {
                                throw IOException("Server doesn't support resuming")
                            }
                            val body = resp.body ?: throw IOException("Empty response")
                            var got = 0L
                            body.byteStream().use { input ->
                                while (true) {
                                    val n = input.read(buf)
                                    if (n < 0) break
                                    ctx.ensureActive()
                                    out.write(buf, 0, n)
                                    got += n
                                    offset += n
                                    onBytes(n.toLong())
                                }
                            }
                            if (!isPlayback) {
                                finished = true
                            } else if (got < CHUNK) {
                                if (got == 0L && offset == 0L) throw IOException("Empty response")
                                finished = true
                            }
                        }
                    }
                    failures = 0
                } catch (e: HttpStatusException) {
                    if (isPlayback && usePost && (e.code == 403 || e.code == 405)) {
                        usePost = false // some stream URLs prefer plain GET
                    } else {
                        failures++
                        if (failures >= 3) throw e
                        delay(700L * failures)
                    }
                } catch (e: IOException) {
                    failures++
                    if (failures >= 4) throw e
                    delay(800L * failures)
                }
            }
        }
        if (dest.length() <= 0L) throw IOException("Downloaded file is empty")
    }
}
