package com.raja.tubevault.core

import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.VideoStream

/** One thing the user can tap to download (a quality, or an audio track). */
data class FormatOption(
    val key: String,
    val label: String,
    val detail: String,
    val isAudio: Boolean,
    val video: VideoStream?,
    val audio: AudioStream?,
    val needsMerge: Boolean,
    val sizeBytes: Long,
    val hlsUrl: String? = null,
    val hlsAudioUrl: String? = null,
    val hlsAudioOnly: Boolean = false
)

data class MediaInfo(
    val id: String,
    val url: String,
    val title: String,
    val uploader: String,
    val durationSec: Long,
    val thumbnail: String?,
    val videoFormats: List<FormatOption>,
    val audioFormats: List<FormatOption>
)

enum class Status { QUEUED, DOWNLOADING, MERGING, SAVING, DONE, FAILED }

data class DownloadItem(
    val id: String,
    val title: String,
    val uploader: String,
    val thumbnail: String?,
    val label: String,
    val isAudio: Boolean,
    val status: Status,
    /** 0..1, or -1 when unknown (indeterminate) */
    val progress: Float,
    val speed: Long,
    val doneBytes: Long,
    val totalBytes: Long,
    val uri: String?,
    val error: String?,
    val createdAt: Long
)
