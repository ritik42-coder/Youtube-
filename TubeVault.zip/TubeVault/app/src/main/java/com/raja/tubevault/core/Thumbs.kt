package com.raja.tubevault.core

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaExtractor
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.Size
import okhttp3.Request
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * Thumbnails that never go black:
 *  - downloaded once and kept on the phone (works offline, survives the site deleting it)
 *  - embedded into the media file itself, so a reinstall can read it back
 *  - for files without art: a frame from the video / art from the song
 */
object Thumbs {
    private const val MAX = 720

    fun dir(ctx: Context) = File(ctx.filesDir, "thumbs").apply { mkdirs() }

    /** Downloads [url] and returns a small JPEG, or null. Blocking. */
    fun download(url: String?): ByteArray? {
        if (url.isNullOrBlank() || !url.startsWith("http")) return null
        return try {
            val req = Request.Builder().url(url).header("User-Agent", NpDownloader.USER_AGENT).build()
            Net.client.newCall(req).execute().use { r ->
                if (!r.isSuccessful) return null
                toJpeg(r.body?.bytes() ?: return null)
            }
        } catch (_: Throwable) {
            null
        }
    }

    /** Any image bytes (webp, png, jpeg…) -> JPEG at most 720 px, so it is small and every app can read it. */
    fun toJpeg(bytes: ByteArray): ByteArray? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= MAX) sample *= 2
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
        bmp?.let { encode(it) }
    } catch (_: Throwable) {
        null
    }

    private fun encode(src: Bitmap): ByteArray {
        val scale = minOf(1f, MAX.toFloat() / maxOf(src.width, src.height))
        val bmp = if (scale < 1f) Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true) else src
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
        return out.toByteArray()
    }

    /** Saves JPEG bytes as files/thumbs/<key>.jpg and returns its file:// uri. */
    fun saveLocal(ctx: Context, key: String, jpeg: ByteArray?): String? {
        if (jpeg == null || jpeg.isEmpty()) return null
        return try {
            val f = File(dir(ctx), key.replace(Regex("[^A-Za-z0-9_-]"), "_") + ".jpg")
            f.writeBytes(jpeg)
            Uri.fromFile(f).toString()
        } catch (_: Throwable) {
            null
        }
    }

    fun deleteLocal(thumb: String?) {
        if (thumb == null || !thumb.startsWith("file://")) return
        try {
            Uri.parse(thumb).path?.let { File(it).delete() }
        } catch (_: Throwable) {
        }
    }

    /** Reads cover art embedded in a song, or a frame of a video. Works on content:// and file:// uris. */
    fun fromMedia(ctx: Context, uri: Uri, audio: Boolean): ByteArray? {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            r.embeddedPicture?.let { pic -> toJpeg(pic)?.let { return it } }
            if (!audio) {
                val frame = r.getFrameAtTime(2_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    ?: r.getFrameAtTime(-1)
                if (frame != null) return encode(frame)
            }
        } catch (_: Throwable) {
        } finally {
            try { r.release() } catch (_: Throwable) {}
        }
        if (Build.VERSION.SDK_INT >= 29 && uri.scheme == "content") {
            try {
                return encode(ctx.contentResolver.loadThumbnail(uri, Size(MAX, MAX), null))
            } catch (_: Throwable) {
            }
        }
        return null
    }

    /** Sanity check after tagging: the file still opens and still has its tracks. */
    fun stillPlayable(file: File, expectTracks: Int): Boolean = try {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(file.absolutePath)
            ex.trackCount >= expectTracks && expectTracks > 0
        } finally {
            ex.release()
        }
    } catch (_: Throwable) {
        false
    }

    fun trackCount(file: File): Int = try {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(file.absolutePath); ex.trackCount
        } finally {
            ex.release()
        }
    } catch (_: Throwable) {
        0
    }

    /** Tags [file] in place-ish: returns the tagged copy, or the original if tagging wasn't safe. */
    fun embed(file: File, title: String, artist: String, cover: ByteArray?): File {
        val ext = file.extension.lowercase()
        if (ext !in setOf("mp4", "m4a", "m4v")) return file
        val before = trackCount(file)
        if (before <= 0) return file
        val tagged = File(file.parentFile, "tagged_" + file.name)
        return if (Mp4Tagger.tag(file, tagged, title, artist, cover) && stillPlayable(tagged, before)) {
            file.delete()
            tagged
        } else {
            tagged.delete()
            file
        }
    }
}
