package com.raja.tubevault.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.raja.tubevault.core.PlItem
import com.raja.tubevault.core.PlaylistController
import com.raja.tubevault.core.formatDuration

/** Sheet to download a whole YouTube playlist (opens when you paste a playlist link). */
@Composable
fun PlaylistHost() {
    val show = PlaylistController.visible
    BackHandler(enabled = show) { PlaylistController.close() }
    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(show, enter = fadeIn(tween(220)), exit = fadeOut(tween(220))) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color(0xAA000000))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                        PlaylistController.close()
                    }
            )
        }
        AnimatedVisibility(
            show,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(spring(dampingRatio = 0.8f, stiffness = 300f)) { h -> h } + fadeIn(tween(200)),
            exit = slideOutVertically(tween(250)) { h -> h } + fadeOut(tween(180))
        ) { PlaylistDlSheet() }
    }
}

@Composable
private fun PlaylistDlSheet() {
    val shape = RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp)
    val d = PlaylistController.data
    Column(
        Modifier
            .fillMaxWidth()
            .fillMaxHeight(0.9f)
            .clip(shape)
            .background(Color(0xFA101018))
            .border(BorderStroke(1.dp, GlassBorder), shape)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
            .navigationBarsPadding()
    ) {
        // ---------------- header
        Row(
            Modifier.padding(start = 20.dp, end = 12.dp, top = 18.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Download playlist", color = TextLo, fontSize = 12.sp)
                Text(
                    d?.title ?: "Loading…",
                    color = TextHi, fontWeight = FontWeight.Black, fontSize = 20.sp,
                    maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                if (d != null) {
                    val up = if (d.uploader.isNotEmpty()) d.uploader + "  •  " else ""
                    val have = if (PlaylistController.existing.isNotEmpty()) "  •  " + PlaylistController.existing.size + " already in Library" else ""
                    Text(up + d.items.size + " videos" + have, color = TextLo, fontSize = 12.sp)
                }
            }
            Box(
                Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Glass)
                    .clickable { PlaylistController.close() },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Rounded.Close, null, tint = Color.White) }
        }

        if (PlaylistController.loading) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = Pink, strokeWidth = 3.dp)
                    Spacer(Modifier.height(12.dp))
                    Text("Reading the playlist…", color = TextLo, fontSize = 14.sp)
                }
            }
        } else if (PlaylistController.error != null) {
            Box(Modifier.weight(1f).fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(PlaylistController.error ?: "", color = Pink, fontSize = 14.sp, textAlign = TextAlign.Center)
            }
        } else if (d != null) {
            // ---------------- options
            Column(Modifier.padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Segmented(listOf("Audio", "Video 720p", "Best video"), PlaylistController.preset) { PlaylistController.preset = it }
                SaveToSelector(PlaylistController.place, showCaption = false) { PlaylistController.place = it }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MiniChip("All") { PlaylistController.selectAll() }
                    if (PlaylistController.existing.isNotEmpty()) MiniChip("Only new") { PlaylistController.selectNew() }
                    MiniChip("None") { PlaylistController.selectNone() }
                }
            }
            Spacer(Modifier.height(6.dp))
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp)
            ) {
                items(d.items, key = { it.url }) { v -> PlRow(v) }
            }

            // ---------------- bottom bar
            Column(Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
                if (PlaylistController.queuing || PlaylistController.finished) {
                    GradientProgress(PlaylistController.queueProgress, Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    val msg = if (PlaylistController.queuing) {
                        "Adding " + PlaylistController.queued + " of " + PlaylistController.queueTotal + " to your downloads…"
                    } else {
                        "Added " + PlaylistController.queued + " videos to your downloads" +
                            (if (PlaylistController.failed > 0) " (" + PlaylistController.failed + " couldn't be read)" else "")
                    }
                    Text(msg, color = TextLo, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                }
                val n = PlaylistController.selected.size
                val label = if (PlaylistController.queuing) "Adding…"
                else if (n == 0) "Pick some videos"
                else "Download " + n + (if (n == 1) " video" else " videos")
                GradientButton(label, PlaylistController.queuing) { if (n > 0) PlaylistController.startDownload() }
                Text(
                    "Files download 3 at a time. You can close this sheet, downloads keep going.",
                    color = TextLo, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
    }
}

@Composable
private fun MiniChip(text: String, onClick: () -> Unit) {
    Text(
        text, color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Glass)
            .border(BorderStroke(1.dp, GlassBorder), RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 7.dp)
    )
}

@Composable
private fun PlRow(v: PlItem) {
    val ctx = LocalContext.current
    val on = v.url in PlaylistController.selected
    val have = v.url in PlaylistController.existing
    val bg by animateColorAsState(if (on) Color(0x22FF3D77) else Color.Transparent, tween(180), label = "plbg")
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(bg)
            .clickable { PlaylistController.toggle(v.url) }
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = ImageRequest.Builder(ctx).data(v.thumb).crossfade(true).build(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .width(96.dp)
                .height(54.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Glass)
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(v.title, color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            val dur = if (v.durationSec > 0) formatDuration(v.durationSec) else ""
            Text(dur + (if (have) "  •  already in Library" else ""), color = if (have) Orange else TextLo, fontSize = 11.sp)
        }
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier
                .size(26.dp)
                .clip(CircleShape)
                .background(if (on) AccentBrush else Brush.linearGradient(listOf(Glass, Glass)))
                .border(BorderStroke(1.dp, if (on) Color.Transparent else GlassBorder), CircleShape),
            contentAlignment = Alignment.Center
        ) { if (on) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(16.dp)) }
    }
}
