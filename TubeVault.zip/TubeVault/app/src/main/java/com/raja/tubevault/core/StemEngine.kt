package com.raja.tubevault.core

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min

/**
 * MDX-Net separation loop (same algorithm as Ultimate Vocal Remover / python-audio-separator):
 * the song is cut in overlapping chunks, every chunk goes through STFT -> network -> iSTFT,
 * and the results are blended with a Hann window. Output is streamed, so memory stays small.
 *
 * Pure Kotlin (no Android classes) so it can be unit-tested on a normal JVM.
 */
class StemEngine(private val dsp: MdxDsp, private val compensate: Float, private val overlap: Float) {

    private fun hann(n: Int): FloatArray {
        val w = FloatArray(n)
        if (n == 1) {
            w[0] = 1f
            return w
        }
        for (j in 0 until n) w[j] = (0.5 - 0.5 * cos(2.0 * PI * j / (n - 1))).toFloat()
        return w
    }

    fun chunkCount(frames: Int): Int {
        val chunk = dsp.chunk
        val gen = chunk - 2 * dsp.trim
        val pad = gen + dsp.trim - (frames % gen)
        val total = dsp.trim + frames + pad
        val step = stepSize()
        return (total + step - 1) / step
    }

    private fun stepSize(): Int = max(1, ((1f - overlap) * dsp.chunk).toInt())

    /**
     * @param pcm interleaved 16-bit stereo, [frames] frames, 44.1 kHz
     * @param model network: spectrogram [4*dimF*dimT] -> spectrogram of the wanted stem (same size)
     * @param sink receives finished interleaved 16-bit stereo audio, in order: (buffer, frameCount)
     * @return false when cancelled
     */
    fun run(
        pcm: ShortArray,
        frames: Int,
        model: (FloatArray) -> FloatArray,
        sink: (ShortArray, Int) -> Unit,
        onProgress: (Int, Int) -> Unit,
        isCancelled: () -> Boolean
    ): Boolean {
        val chunk = dsp.chunk
        val trim = dsp.trim
        val gen = chunk - 2 * trim
        val pad = gen + trim - (frames % gen)
        val total = trim + frames + pad
        val step = stepSize()
        val nChunks = (total + step - 1) / step

        val l = FloatArray(chunk)
        val r = FloatArray(chunk)
        val oL = FloatArray(chunk)
        val oR = FloatArray(chunk)
        val spec = FloatArray(4 * dsp.dimF * dsp.dimT)
        val accL = FloatArray(chunk)
        val accR = FloatArray(chunk)
        val div = FloatArray(chunk)
        val fullWin = if (overlap > 0f) hann(chunk) else null
        val outBuf = ShortArray(step * 2 + 4)

        var i = 0
        var ci = 0
        while (i < total) {
            if (isCancelled()) return false
            val end = min(i + chunk, total)
            val actual = end - i
            for (j in 0 until chunk) {
                val s = i + j - trim
                if (j < actual && s >= 0 && s < frames) {
                    l[j] = pcm[2 * s] / 32768f
                    r[j] = pcm[2 * s + 1] / 32768f
                } else {
                    l[j] = 0f
                    r[j] = 0f
                }
            }
            dsp.stft(l, r, spec, 0)
            dsp.zeroLowBins(spec, 0)
            val out = model(spec)
            dsp.istft(out, 0, oL, oR)

            if (fullWin == null) {
                for (j in 0 until actual) {
                    accL[j] += oL[j]
                    accR[j] += oR[j]
                    div[j] += 1f
                }
            } else {
                val w = if (actual == chunk) fullWin else hann(actual)
                for (j in 0 until actual) {
                    accL[j] += oL[j] * w[j]
                    accR[j] += oR[j] * w[j]
                    div[j] += w[j]
                }
            }

            val last = i + step >= total
            val fc = if (last) actual else min(step, actual)
            var cnt = 0
            for (j in 0 until fc) {
                val q = i + j - trim
                if (q < 0 || q >= frames) continue
                val dv = div[j]
                val lv = if (dv > 1e-9f) accL[j] / dv * compensate else 0f
                val rv = if (dv > 1e-9f) accR[j] / dv * compensate else 0f
                outBuf[2 * cnt] = toShort(lv)
                outBuf[2 * cnt + 1] = toShort(rv)
                cnt++
            }
            if (cnt > 0) sink(outBuf, cnt)

            if (!last) {
                System.arraycopy(accL, step, accL, 0, chunk - step)
                System.arraycopy(accR, step, accR, 0, chunk - step)
                System.arraycopy(div, step, div, 0, chunk - step)
                java.util.Arrays.fill(accL, chunk - step, chunk, 0f)
                java.util.Arrays.fill(accR, chunk - step, chunk, 0f)
                java.util.Arrays.fill(div, chunk - step, chunk, 0f)
            }
            ci++
            onProgress(ci, nChunks)
            i += step
        }
        return true
    }

    private fun toShort(v: Float): Short {
        val x = Math.round(v * 32767f)
        return (if (x > 32767) 32767 else if (x < -32768) -32768 else x).toShort()
    }
}
