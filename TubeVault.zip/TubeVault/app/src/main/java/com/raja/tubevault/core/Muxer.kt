package com.raja.tubevault.core

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.nio.ByteBuffer

/** Merges a video-only and an audio-only MP4/M4A into one MP4 using Android's MediaMuxer. */
object Muxer {

    private class Src(val ex: MediaExtractor, val idx: Int) {
        var done = false
    }

    suspend fun merge(video: File, audio: File, out: File) =
        withContext(Dispatchers.IO) { mux(listOf(video, audio), out) }

    /** Re-wraps a fragmented audio file into a normal, seekable .m4a */
    suspend fun remux(audio: File, out: File) =
        withContext(Dispatchers.IO) { mux(listOf(audio), out) }

    private suspend fun mux(inputs: List<File>, out: File) {
        val ctx = currentCoroutineContext()
        if (out.exists()) out.delete()
        val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val srcs = ArrayList<Src>()
        var started = false
        try {
            for (f in inputs) {
                val ex = MediaExtractor()
                ex.setDataSource(f.absolutePath)
                var track = -1
                for (i in 0 until ex.trackCount) {
                    val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
                    if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                        track = i
                        break
                    }
                }
                if (track < 0) {
                    ex.release()
                    throw IOException("No media track found in ${f.name}")
                }
                ex.selectTrack(track)
                val idx = muxer.addTrack(ex.getTrackFormat(track))
                srcs.add(Src(ex, idx))
            }

            muxer.start()
            started = true

            val buf = ByteBuffer.allocateDirect(6 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()

            while (true) {
                ctx.ensureActive()
                // always write the sample with the earliest timestamp -> properly interleaved file
                var best: Src? = null
                var bestT = Long.MAX_VALUE
                for (s in srcs) {
                    if (s.done) continue
                    val t = s.ex.sampleTime
                    if (t < 0) {
                        s.done = true
                        continue
                    }
                    if (t < bestT) {
                        bestT = t
                        best = s
                    }
                }
                val s = best ?: break
                buf.clear()
                val size = s.ex.readSampleData(buf, 0)
                if (size < 0) {
                    s.done = true
                    continue
                }
                val isSync = (s.ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0
                info.set(0, size, s.ex.sampleTime, if (isSync) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                muxer.writeSampleData(s.idx, buf, info)
                s.ex.advance()
            }
            muxer.stop()
            started = false
        } finally {
            try {
                if (started) muxer.stop()
            } catch (_: Throwable) {
            }
            try {
                muxer.release()
            } catch (_: Throwable) {
            }
            for (s in srcs) {
                try {
                    s.ex.release()
                } catch (_: Throwable) {
                }
            }
        }
    }
}
