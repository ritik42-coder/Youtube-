package com.raja.tubevault.core

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.nio.ByteBuffer

/** Joins / re-wraps media into a normal MP4 or M4A using Android's MediaMuxer. */
object Muxer {

    private class Src(val ex: MediaExtractor, val map: Map<Int, Int>) {
        var done = false
    }

    /** video file + audio file -> one MP4 */
    suspend fun merge(video: File, audio: File, out: File) =
        withContext(Dispatchers.IO) { mux(listOf(video, audio), out, false) }

    /** One file (fragmented or muxed) -> normal seekable file. [onlyAudio] drops the video track. */
    suspend fun remux(file: File, out: File, onlyAudio: Boolean = false) =
        withContext(Dispatchers.IO) { mux(listOf(file), out, onlyAudio) }

    private suspend fun mux(inputs: List<File>, out: File, onlyAudio: Boolean) {
        val ctx = currentCoroutineContext()
        if (out.exists()) out.delete()
        val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val srcs = ArrayList<Src>()
        var started = false
        try {
            for (f in inputs) {
                val ex = MediaExtractor()
                ex.setDataSource(f.absolutePath)
                var vTrack = -1
                var aTrack = -1
                for (i in 0 until ex.trackCount) {
                    val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
                    if (mime.startsWith("video/") && vTrack < 0 && !onlyAudio) vTrack = i
                    if (mime.startsWith("audio/") && aTrack < 0) aTrack = i
                }
                if (vTrack < 0 && aTrack < 0) {
                    ex.release()
                    throw IOException("No media track found in the downloaded file")
                }
                val map = HashMap<Int, Int>()
                for (t in listOf(vTrack, aTrack)) {
                    if (t < 0) continue
                    ex.selectTrack(t)
                    map[t] = muxer.addTrack(ex.getTrackFormat(t))
                }
                srcs.add(Src(ex, map))
            }

            muxer.start()
            started = true

            val buf = ByteBuffer.allocateDirect(8 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()

            while (true) {
                ctx.ensureActive()
                var best: Src? = null
                var bestT = Long.MAX_VALUE
                for (s in srcs) {
                    if (s.done) continue
                    val t = s.ex.sampleTime
                    if (t < 0) {
                        s.done = true
                        continue
                    }
                    if (t < bestT) {
                        bestT = t
                        best = s
                    }
                }
                val s = best ?: break
                val outIdx = s.map[s.ex.sampleTrackIndex]
                buf.clear()
                val size = s.ex.readSampleData(buf, 0)
                if (size < 0) {
                    s.done = true
                    continue
                }
                if (outIdx != null) {
                    val isSync = (s.ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0
                    info.set(0, size, s.ex.sampleTime, if (isSync) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                    muxer.writeSampleData(outIdx, buf, info)
                }
                s.ex.advance()
            }
            muxer.stop()
            started = false
        } finally {
            try {
                if (started) muxer.stop()
            } catch (_: Throwable) {
            }
            try {
                muxer.release()
            } catch (_: Throwable) {
            }
            for (s in srcs) {
                try {
                    s.ex.release()
                } catch (_: Throwable) {
                }
            }
        }
    }
}
