package com.raja.tubevault.core

import android.Manifest
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageInstaller
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.pm.PackageInfoCompat
import com.raja.tubevault.BuildConfig
import com.raja.tubevault.MainActivity
import com.raja.tubevault.R
import com.raja.tubevault.ui.AppSettings
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.security.MessageDigest

/** One highlight card ("What's new" item). [icon] is a short name, see iconFor() in UpdateUi.kt. */
data class Highlight(val icon: String, val title: String, val desc: String)

data class ReleaseInfo(
    val versionCode: Int,
    val versionName: String,
    val title: String,
    val subtitle: String,
    val highlights: List<Highlight>,
    val apkUrl: String,
    val size: Long,
    val sha256: String
)

sealed interface UpdateState {
    data object Idle : UpdateState
    data object Checking : UpdateState
    data object UpToDate : UpdateState
    data class Available(val info: ReleaseInfo) : UpdateState
    data class Downloading(val info: ReleaseInfo, val done: Long, val total: Long, val speed: Long) : UpdateState
    data class Ready(val info: ReleaseInfo, val file: File) : UpdateState
    data class Installing(val info: ReleaseInfo) : UpdateState
    data class Failed(val message: String, val info: ReleaseInfo) : UpdateState
}

/**
 * Self-updater. New builds are published as GitHub Releases by the workflow
 * (TubeVault.apk + update.json). The app reads
 *   https://github.com/<owner>/<repo>/releases/latest/download/update.json
 * downloads the APK, verifies it and hands it to Android's PackageInstaller.
 * The repo name is baked in at build time (BuildConfig.UPDATE_REPO = GITHUB_REPOSITORY).
 */
object Updater {
    const val ACTION_STATUS = "com.raja.tubevault.UPDATE_STATUS"
    const val CH_UPDATE = "tv_update"

    private const val PREFS = "tubevault_update"
    private const val CHECK_EVERY_MS = 3L * 3600_000L

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var dlJob: Job? = null
    private var checkJob: Job? = null
    private var prefs: SharedPreferences? = null
    private var installingFrom: UpdateState.Ready? = null

    var state by mutableStateOf<UpdateState>(UpdateState.Idle)
        private set

    /** The animated update sheet is open. */
    var sheetOpen by mutableStateOf(false)

    /** The animated "What's new" screen (null = hidden). */
    var whatsNew by mutableStateOf<ReleaseInfo?>(null)
        private set

    /** Waiting for the user to allow "install unknown apps" for TubeVault. */
    var needsInstallPermission by mutableStateOf(false)
        private set

    /** Short result of the last manual check ("You're on the latest version", errors...). */
    var lastMessage by mutableStateOf<String?>(null)
        private set

    private val repo: String get() = BuildConfig.UPDATE_REPO
    val configured: Boolean get() = repo.contains("/")

    private fun p(ctx: Context): SharedPreferences =
        prefs ?: ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).also { prefs = it }

    // ------------------------------------------------------------------ lifecycle hooks

    /** Called once the intro is over: cleanup, What's-new decision, restore pending update, auto check. */
    fun onAppReady(ctx: Context) {
        val app = ctx.applicationContext
        decideWhatsNew(app)
        scope.launch {
            cleanup(app)
            restorePending(app)
            if (dueForAutoCheck(app)) doCheck(app, manual = false)
        }
    }

    /** Called from Activity.onResume. */
    fun onAppResumed(ctx: Context) {
        val app = ctx.applicationContext
        if (needsInstallPermission && canInstall(app)) {
            needsInstallPermission = false
            install(ctx)
            return
        }
        val s = state
        if (s is UpdateState.Idle || s is UpdateState.UpToDate) {
            if (dueForAutoCheck(app)) checkAsync(app, manual = false)
        }
    }

    private fun dueForAutoCheck(ctx: Context): Boolean {
        if (!AppSettings.autoUpdate || !configured) return false
        return System.currentTimeMillis() - p(ctx).getLong("last_check", 0L) >= CHECK_EVERY_MS
    }

    // ------------------------------------------------------------------ check

    fun checkAsync(ctx: Context, manual: Boolean) {
        val app = ctx.applicationContext
        val s = state
        if (manual && (s is UpdateState.Available || s is UpdateState.Ready ||
                s is UpdateState.Downloading || s is UpdateState.Installing || s is UpdateState.Failed)
        ) {
            sheetOpen = true
            return
        }
        if (checkJob?.isActive == true) return
        checkJob = scope.launch { doCheck(app, manual) }
    }

    private suspend fun doCheck(ctx: Context, manual: Boolean) {
        if (!configured) {
            if (manual) lastMessage = "Updates work on builds made by your GitHub workflow."
            return
        }
        if (manual) {
            lastMessage = null
            state = UpdateState.Checking
        }
        try {
            val url = "https://github.com/$repo/releases/latest/download/update.json"
            val req = Request.Builder()
                .url(url)
                .header("Cache-Control", "no-cache")
                .header("User-Agent", "TubeVault/" + BuildConfig.VERSION_NAME)
                .build()
            val body: String? = Net.client.newCall(req).execute().use { r ->
                if (r.code == 404) null
                else {
                    if (!r.isSuccessful) throw HttpStatusException(r.code)
                    r.body?.string()
                }
            }
            val pr = p(ctx)
            pr.edit().putLong("last_check", System.currentTimeMillis()).apply()

            if (body == null) {
                if (state is UpdateState.Checking) state = UpdateState.Idle
                if (manual) lastMessage = "No update published yet."
                return
            }
            val info = parseRelease(JSONObject(body))
            if (info.versionCode > BuildConfig.VERSION_CODE && info.apkUrl.isNotBlank()) {
                pr.edit().putString("pending_json", body).apply()
                val cur = state
                if (cur !is UpdateState.Downloading && cur !is UpdateState.Ready && cur !is UpdateState.Installing) {
                    state = UpdateState.Available(info)
                }
                val skipped = pr.getInt("skipped", 0) == info.versionCode
                val prompted = pr.getInt("prompted", 0) == info.versionCode
                if (manual || (!skipped && !prompted)) {
                    sheetOpen = true
                    pr.edit().putInt("prompted", info.versionCode).apply()
                }
                if (state is UpdateState.Available && AppSettings.autoDownloadUpdate && !skipped && onUnmetered(ctx)) {
                    startDownload(ctx)
                }
            } else {
                pr.edit().remove("pending_json").apply()
                state = UpdateState.UpToDate
                if (manual) lastMessage = "You're on the latest version."
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            if (state is UpdateState.Checking) state = UpdateState.Idle
            if (manual) lastMessage = friendly(e)
        }
    }

    private fun restorePending(ctx: Context) {
        if (state !is UpdateState.Idle) return
        val json = p(ctx).getString("pending_json", null) ?: return
        try {
            val info = parseRelease(JSONObject(json))
            if (info.versionCode <= BuildConfig.VERSION_CODE) {
                p(ctx).edit().remove("pending_json").apply()
                return
            }
            val f = apkFile(ctx, info)
            state = if (f.exists() && verify(ctx, f, info)) UpdateState.Ready(info, f) else UpdateState.Available(info)
        } catch (_: Throwable) {
        }
    }

    // ------------------------------------------------------------------ download

    fun startDownload(ctx: Context) {
        val app = ctx.applicationContext
        val info = when (val s = state) {
            is UpdateState.Available -> s.info
            is UpdateState.Failed -> s.info
            else -> return
        }
        if (dlJob?.isActive == true) return
        dlJob = scope.launch { downloadInternal(app, info) }
    }

    fun cancelDownload() {
        val s = state
        dlJob?.cancel()
        if (s is UpdateState.Downloading) state = UpdateState.Available(s.info)
    }

    private fun apkFile(ctx: Context, info: ReleaseInfo): File =
        File(File(ctx.cacheDir, "updates").apply { mkdirs() }, "TubeVault-${info.versionCode}.apk")

    private suspend fun downloadInternal(ctx: Context, info: ReleaseInfo) {
        val dest = apkFile(ctx, info)
        val part = File(dest.parentFile, dest.name + ".part")
        try {
            // keep only the file for this version
            dest.parentFile?.listFiles()?.forEach { f ->
                if (f.name != dest.name && f.name != part.name) f.delete()
            }
            if (dest.exists()) {
                if (verify(ctx, dest, info)) {
                    state = UpdateState.Ready(info, dest)
                    return
                }
                dest.delete()
            }
            var have = if (part.exists()) part.length() else 0L
            if (info.size > 0 && have > info.size) {
                part.delete()
                have = 0L
            }
            state = UpdateState.Downloading(info, have, info.size, 0L)

            val rb = Request.Builder()
                .url(info.apkUrl)
                .header("User-Agent", "TubeVault/" + BuildConfig.VERSION_NAME)
            if (have > 0) rb.header("Range", "bytes=$have-")

            Net.client.newCall(rb.build()).execute().use { resp ->
                if (resp.code == 416) {
                    part.delete()
                    throw IOException("Download was interrupted. Tap Try again.")
                }
                if (!resp.isSuccessful) throw HttpStatusException(resp.code)
                val append = resp.code == 206
                var done = if (append) have else 0L
                val body = resp.body ?: throw IOException("Empty response")
                val total = if (info.size > 0) info.size else done + body.contentLength()
                val buf = ByteArray(64 * 1024)
                var lastT = System.nanoTime()
                var lastB = done
                var speed = 0L
                FileOutputStream(part, append).use { out ->
                    body.byteStream().use { ins ->
                        while (true) {
                            currentCoroutineContext().ensureActive()
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            val now = System.nanoTime()
                            if (now - lastT > 350_000_000L) {
                                val inst = (done - lastB) * 1_000_000_000L / (now - lastT)
                                speed = if (speed == 0L) inst else (speed * 6 + inst * 4) / 10
                                lastT = now
                                lastB = done
                                state = UpdateState.Downloading(info, done, total, speed)
                            }
                        }
                    }
                }
            }
            if (dest.exists()) dest.delete()
            if (!part.renameTo(dest)) throw IOException("Could not save the update file.")
            if (!verify(ctx, dest, info)) {
                dest.delete()
                throw IOException("The update file is damaged. Tap Try again.")
            }
            state = UpdateState.Ready(info, dest)
        } catch (e: CancellationException) {
            state = UpdateState.Available(info)
            throw e
        } catch (e: Throwable) {
            state = UpdateState.Failed(friendly(e), info)
        }
    }

    private fun verify(ctx: Context, f: File, info: ReleaseInfo): Boolean {
        return try {
            if (!f.exists()) return false
            if (info.size > 0 && f.length() != info.size) return false
            if (info.sha256.isNotBlank()) {
                val md = MessageDigest.getInstance("SHA-256")
                f.inputStream().use { ins ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        md.update(buf, 0, n)
                    }
                }
                val hex = md.digest().joinToString("") { b -> "%02x".format(b) }
                if (hex != info.sha256) return false
            }
            val pkg = ctx.packageManager.getPackageArchiveInfo(f.absolutePath, 0) ?: return false
            if (pkg.packageName != ctx.packageName) return false
            PackageInfoCompat.getLongVersionCode(pkg) > BuildConfig.VERSION_CODE
        } catch (_: Throwable) {
            false
        }
    }

    // ------------------------------------------------------------------ install

    fun canInstall(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.O || ctx.packageManager.canRequestPackageInstalls()

    fun install(ctx: Context) {
        val st = state as? UpdateState.Ready ?: return
        val app = ctx.applicationContext
        if (!canInstall(app)) {
            needsInstallPermission = true
            try {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + app.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Throwable) {
            }
            return
        }
        needsInstallPermission = false
        scope.launch { runInstall(app, st) }
    }

    private fun runInstall(ctx: Context, st: UpdateState.Ready) {
        installingFrom = st
        state = UpdateState.Installing(st.info)
        try {
            val installer = ctx.packageManager.packageInstaller
            val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
            params.setAppPackageName(ctx.packageName)
            params.setSize(st.file.length())
            if (Build.VERSION.SDK_INT >= 31) {
                params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
            }
            val id = installer.createSession(params)
            installer.openSession(id).use { session ->
                st.file.inputStream().use { ins ->
                    session.openWrite("TubeVault.apk", 0, st.file.length()).use { out ->
                        ins.copyTo(out)
                        session.fsync(out)
                    }
                }
                val intent = Intent(ctx, UpdateReceiver::class.java).setAction(ACTION_STATUS)
                var flags = PendingIntent.FLAG_UPDATE_CURRENT
                if (Build.VERSION.SDK_INT >= 31) flags = flags or PendingIntent.FLAG_MUTABLE
                val pending = PendingIntent.getBroadcast(ctx, id, intent, flags)
                session.commit(pending.intentSender)
            }
        } catch (e: Throwable) {
            state = UpdateState.Failed(friendly(e), st.info)
        }
    }

    /** Result from the system installer (see UpdateReceiver). */
    internal fun onInstallResult(status: Int, message: String?) {
        when (status) {
            PackageInstaller.STATUS_SUCCESS -> {
                // the app is normally restarted/killed by Android here
                state = UpdateState.Idle
            }
            PackageInstaller.STATUS_FAILURE_ABORTED -> {
                // user pressed Cancel on Android's install screen: keep the downloaded file ready
                val back = installingFrom
                if (back != null) state = back
            }
            else -> {
                val info = installingFrom?.info ?: (state as? UpdateState.Installing)?.info ?: return
                val m = (message ?: "").uppercase()
                val text = when {
                    m.contains("INCOMPATIBLE") || m.contains("SIGNATURE") ->
                        "This update was signed with a different key. Uninstall TubeVault once, then install the new APK."
                    m.contains("STORAGE") -> "Not enough free storage to install the update."
                    m.contains("DOWNGRADE") -> "This version is older than the installed one."
                    else -> if (!message.isNullOrBlank()) message else "Android could not install the update."
                }
                state = UpdateState.Failed(text, info)
            }
        }
    }

    fun retry(ctx: Context) {
        val s = state as? UpdateState.Failed ?: return
        val f = apkFile(ctx, s.info)
        if (f.exists() && s.message.contains("install", ignoreCase = true)) {
            state = UpdateState.Ready(s.info, f)
            install(ctx)
        } else {
            startDownload(ctx)
        }
    }

    fun skipVersion(ctx: Context) {
        val info = when (val s = state) {
            is UpdateState.Available -> s.info
            is UpdateState.Ready -> s.info
            is UpdateState.Failed -> s.info
            else -> null
        }
        if (info != null) p(ctx).edit().putInt("skipped", info.versionCode).apply()
        sheetOpen = false
    }

    // ------------------------------------------------------------------ what's new

    private fun decideWhatsNew(ctx: Context) {
        try {
            val pr = p(ctx)
            val seen = pr.getInt("seen_code", 0)
            val cur = BuildConfig.VERSION_CODE
            if (seen >= cur) return
            pr.edit().putInt("seen_code", cur).apply()
            val upgraded = try {
                val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
                pi.lastUpdateTime - pi.firstInstallTime > 5000L
            } catch (_: Throwable) {
                false
            }
            // a brand-new install has nothing to compare with
            if (seen == 0 && !upgraded) return
            whatsNew = loadBundled(ctx)
        } catch (_: Throwable) {
        }
    }

    private fun loadBundled(ctx: Context): ReleaseInfo? = try {
        val txt = ctx.assets.open("whatsnew.json").bufferedReader().use { it.readText() }
        parseRelease(JSONObject(txt)).copy(
            versionCode = BuildConfig.VERSION_CODE,
            versionName = BuildConfig.VERSION_NAME
        )
    } catch (_: Throwable) {
        null
    }

    fun showWhatsNew(ctx: Context) {
        whatsNew = loadBundled(ctx.applicationContext)
    }

    fun dismissWhatsNew() {
        whatsNew = null
    }

    // ------------------------------------------------------------------ misc

    fun notifyUpdated(ctx: Context) {
        try {
            if (Build.VERSION.SDK_INT >= 33 &&
                ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) return
            val open = Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val pi = PendingIntent.getActivity(
                ctx, 7, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val n = NotificationCompat.Builder(ctx, CH_UPDATE)
                .setSmallIcon(R.drawable.ic_stat_download)
                .setContentTitle("TubeVault updated")
                .setContentText("You're now on version " + BuildConfig.VERSION_NAME + ". Tap to see what's new.")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .build()
            NotificationManagerCompat.from(ctx).notify(7001, n)
        } catch (_: Throwable) {
        }
    }

    private fun cleanup(ctx: Context) {
        try {
            val rx = Regex("""TubeVault-(\d+)\.apk""")
            File(ctx.cacheDir, "updates").listFiles()?.forEach { f ->
                val code = rx.find(f.name)?.groupValues?.get(1)?.toIntOrNull()
                if (code != null && code <= BuildConfig.VERSION_CODE) f.delete()
            }
        } catch (_: Throwable) {
        }
    }

    private fun onUnmetered(ctx: Context): Boolean {
        return try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val metered = cm.isActiveNetworkMetered
            !metered
        } catch (_: Throwable) {
            false
        }
    }

    private fun parseRelease(j: JSONObject): ReleaseInfo {
        val list = ArrayList<Highlight>()
        val arr = j.optJSONArray("highlights")
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                list.add(Highlight(o.optString("icon", "spark"), o.optString("title", ""), o.optString("desc", "")))
            }
        }
        return ReleaseInfo(
            versionCode = j.optInt("versionCode", 0),
            versionName = j.optString("versionName", ""),
            title = j.optString("title", "What's new"),
            subtitle = j.optString("subtitle", ""),
            highlights = list,
            apkUrl = j.optString("apk", ""),
            size = j.optLong("size", 0L),
            sha256 = j.optString("sha256", "").lowercase()
        )
    }

    private fun friendly(e: Throwable): String = when (e) {
        is java.net.UnknownHostException -> "No internet connection."
        is java.net.SocketTimeoutException -> "Connection timed out. Please try again."
        is HttpStatusException ->
            if (e.code == 404) "Update file not found. Make sure the GitHub repo is public."
            else "Server error (" + e.code + "). Please try again."
        else -> e.message ?: "Something went wrong. Please try again."
    }
}

/** Receives the result of the PackageInstaller session (and asks the user to confirm when needed). */
class UpdateReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Updater.ACTION_STATUS) return
        val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
        val message = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE)
        if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            val confirm: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(Intent.EXTRA_INTENT)
            }
            if (confirm != null) {
                try {
                    confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(confirm)
                } catch (_: Throwable) {
                    Updater.onInstallResult(PackageInstaller.STATUS_FAILURE, "Could not open the install screen.")
                }
            }
            return
        }
        Updater.onInstallResult(status, message)
    }
}

/** After the app was replaced by an update: tell the user and offer a way back in. */
class ReplacedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) Updater.notifyUpdated(context)
    }
}
