@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.raja.tubevault.core

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.raja.tubevault.MainActivity

/**
 * One ExoPlayer for the whole app. It lives in the process (not in a screen), so music keeps
 * playing when you leave the player, switch apps or turn the screen off.
 */
object PlayerHub {
    private var p: ExoPlayer? = null
    val processor = FxProcessor()

    var queue by mutableStateOf<List<DownloadItem>>(emptyList())
    var index by mutableIntStateOf(0)
    var isPlaying by mutableStateOf(false)
    var queueKey by mutableStateOf("")

    /** -1 = went to previous song, 1 = went to next song (for slide animations) */
    var slideDir by mutableIntStateOf(1)
    var volume by mutableFloatStateOf(1f)
    var muted by mutableStateOf(false)
    var vizStyle by mutableIntStateOf(0)
    var shuffle by mutableStateOf(false)
    var repeatAll by mutableStateOf(true)

    val current: DownloadItem? get() = queue.getOrNull(index)
    val hasMusic: Boolean get() = queue.isNotEmpty() && queue.first().isAudio

    fun player(ctx: Context): ExoPlayer = p ?: build(ctx.applicationContext).also { p = it }

    private fun build(c: Context): ExoPlayer {
        Fx.load(c)
        val factory = object : DefaultRenderersFactory(c) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink? = DefaultAudioSink.Builder(context)
                .setEnableFloatOutput(false)
                .setEnableAudioTrackPlaybackParams(false)
                .setAudioProcessors(arrayOf<AudioProcessor>(processor))
                .build()
        }
        val player = ExoPlayer.Builder(c, factory)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(), true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val n = player.currentMediaItemIndex
                if (n != index) {
                    slideDir = if (n >= index) 1 else -1
                    index = n
                }
            }
        })
        return player
    }

    private fun toItem(d: DownloadItem): MediaItem = MediaItem.Builder()
        .setMediaId(d.id)
        .setUri(d.uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(d.title)
                .setArtist(d.uploader.ifEmpty { "TubeVault" })
                .setArtworkUri(d.thumbnail?.let { Uri.parse(it) })
                .build()
        ).build()

    fun load(ctx: Context, items: List<DownloadItem>, start: Int, startPosMs: Long = 0L) {
        if (items.isEmpty()) return
        val pl = player(ctx)
        val s = start.coerceIn(0, items.lastIndex)
        queue = items
        queueKey = items.joinToString(",") { it.id }
        index = s
        slideDir = 1
        pl.setMediaItems(items.map { toItem(it) }, s, startPosMs)
        pl.repeatMode = if (items.first().isAudio && repeatAll) Player.REPEAT_MODE_ALL else Player.REPEAT_MODE_OFF
        pl.shuffleModeEnabled = shuffle
        pl.prepare()
        pl.playWhenReady = true
        if (items.first().isAudio) startService(ctx)
    }

    fun setRepeatAll(ctx: Context, on: Boolean) {
        repeatAll = on
        player(ctx).repeatMode = if (on) Player.REPEAT_MODE_ALL else Player.REPEAT_MODE_OFF
    }

    fun setShuffle(ctx: Context, on: Boolean) {
        shuffle = on
        player(ctx).shuffleModeEnabled = on
    }

    fun startService(ctx: Context) {
        try {
            ctx.applicationContext.startService(Intent(ctx.applicationContext, PlaybackService::class.java))
        } catch (_: Throwable) {
        }
    }

    /** Stop everything: used by the island's close button and when a video is closed. */
    fun stop(ctx: Context) {
        try {
            p?.let {
                it.pause()
                it.stop()
                it.clearMediaItems()
            }
        } catch (_: Throwable) {
        }
        queue = emptyList()
        queueKey = ""
        index = 0
        isPlaying = false
        try {
            ctx.applicationContext.stopService(Intent(ctx.applicationContext, PlaybackService::class.java))
        } catch (_: Throwable) {
        }
    }

    fun playPause(ctx: Context) {
        val pl = player(ctx)
        if (pl.playbackState == Player.STATE_ENDED) {
            pl.seekTo(0, 0L)
            pl.play()
        } else if (pl.playWhenReady) pl.pause() else pl.play()
    }

    fun next(ctx: Context) {
        val pl = player(ctx)
        slideDir = 1
        pl.seekToNextMediaItem()
    }

    fun previous(ctx: Context) {
        val pl = player(ctx)
        slideDir = -1
        if (pl.currentPosition > 3000L) pl.seekTo(0L) else pl.seekToPreviousMediaItem()
    }

    fun jumpTo(ctx: Context, i: Int) {
        val pl = player(ctx)
        slideDir = if (i >= index) 1 else -1
        pl.seekTo(i, 0L)
        pl.play()
    }
}

/** Keeps music alive in the background with a lock-screen / notification player. */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val player = PlayerHub.player(this)
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        session = MediaSession.Builder(this, player).setSessionActivity(open).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Swiped the app away: keep playing if music is playing, otherwise shut down.
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        session?.release()
        session = null
        super.onDestroy()
    }
}
