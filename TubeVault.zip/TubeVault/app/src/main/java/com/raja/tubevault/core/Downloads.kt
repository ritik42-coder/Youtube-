package com.raja.tubevault.core

import android.Manifest
import android.app.Application
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.raja.tubevault.App
import com.raja.tubevault.MainActivity
import com.raja.tubevault.R
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/** App-wide download queue. UI observes [items]; the work runs here (kept alive by DownloadService). */
object Downloads {
    private lateinit var app: Application
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _items = MutableStateFlow<List<DownloadItem>>(emptyList())
    val items: StateFlow<List<DownloadItem>> = _items.asStateFlow()

    private class Req(val info: MediaInfo, val opt: FormatOption, val place: Place)

    private val jobs = ConcurrentHashMap<String, Job>()
    private val requests = ConcurrentHashMap<String, Req>()
    private val gate = Semaphore(3)

    val ACTIVE = setOf(Status.QUEUED, Status.DOWNLOADING, Status.MERGING, Status.SAVING)

    private const val PRIVATE_TITLE = "Private download"

    fun init(application: Application) {
        if (::app.isInitialized) return
        app = application
        _items.value = dedupe(loadHistory())
        scope.launch {
            delay(1500)
            repairLibrary()
        }
    }

    // ---------------------------------------------------------------- public API

    fun enqueue(info: MediaInfo, opt: FormatOption, place: Place) {
        val id = UUID.randomUUID().toString()
        val secret = place == Place.VAULT
        val item = DownloadItem(
            id = id,
            title = if (secret) PRIVATE_TITLE else info.title,
            uploader = if (secret) "Goes straight into your Vault" else info.uploader,
            thumbnail = if (secret) null else info.thumbnail,
            label = if (opt.isAudio) "Audio M4A" else opt.label,
            isAudio = opt.isAudio,
            status = Status.QUEUED,
            progress = 0f,
            speed = 0L,
            doneBytes = 0L,
            totalBytes = opt.sizeBytes,
            uri = null,
            error = null,
            createdAt = System.currentTimeMillis(),
            place = place
        )
        requests[id] = Req(info, opt, place)
        _items.update { listOf(item) + it }
        DownloadService.start(app)
        launchJob(id)
    }

    fun retry(id: String) {
        val it = _items.value.firstOrNull { x -> x.id == id } ?: return
        if (it.status != Status.FAILED || !requests.containsKey(id)) return
        patch(id) { x -> x.copy(status = Status.QUEUED, progress = 0f, speed = 0L, doneBytes = 0L, error = null) }
        DownloadService.start(app)
        launchJob(id)
    }

    fun cancel(id: String) {
        requests.remove(id)
        UniversalRepo.cancel(id)
        jobs[id]?.cancel()
        _items.update { list -> list.filterNot { x -> x.id == id } }
    }

    fun remove(id: String, deleteFile: Boolean) {
        val item = _items.value.firstOrNull { it.id == id } ?: return
        if (item.status in ACTIVE) {
            cancel(id)
            return
        }
        if (deleteFile && item.uri != null) deleteMedia(item.uri)
        if (deleteFile) Thumbs.deleteLocal(item.thumbnail)
        requests.remove(id)
        _items.update { list -> list.filterNot { x -> x.id == id } }
        saveHistory()
    }

    /** Puts an already finished file into the Library (used when moving out of the Vault). */
    fun addFinished(item: DownloadItem) {
        _items.update { listOf(item) + it }
        saveHistory()
    }

    // ---------------------------------------------------------------- moving between places

    /**
     * Moves a Library item to [target]. Runs in the background; [done] gets a short message
     * for the user (on the main thread).
     */
    fun move(id: String, target: Place, done: (String) -> Unit) {
        scope.launch {
            val msg = try {
                moveBlocking(id, target)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                "Couldn't move it: " + Errors.friendly(e)
            }
            withContext(Dispatchers.Main) { done(msg) }
        }
    }

    private fun moveBlocking(id: String, target: Place): String {
        val item = _items.value.firstOrNull { it.id == id } ?: return "Item not found"
        val uri = item.uri ?: return "This file isn't ready yet"
        if (item.place == target) return "Already there"
        val name = displayName(item)
        val mime = LocalStore.mimeOf(name, item.isAudio)
        val tmpDir = File(app.cacheDir, "move/$id").apply { mkdirs() }
        try {
            return when (target) {
                Place.VAULT -> {
                    val cover = coverBytes(item)
                    openInput(uri).use {
                        Vault.add(it, item.title, item.uploader, item.label, item.isAudio, name.substringAfterLast('.', "mp4"), cover)
                    }
                    val removed = deleteMedia(uri)
                    Thumbs.deleteLocal(item.thumbnail)
                    _items.update { l -> l.filterNot { it.id == id } }
                    saveHistory()
                    if (removed) "Moved to your Vault 🔒"
                    else "Locked in your Vault. Android didn't let TubeVault remove the old Gallery copy — delete it from your Gallery app."
                }
                Place.GALLERY -> {
                    val tmp = File(tmpDir, "f." + name.substringAfterLast('.', "mp4"))
                    openInput(uri).use { inp -> tmp.outputStream().use { inp.copyTo(it, 256 * 1024) } }
                    val newUri = MediaSaver.save(app, tmp, name, mime, item.isAudio)
                    deleteMedia(uri)
                    patch(id) { it.copy(uri = newUri.toString(), place = Place.GALLERY) }
                    saveHistory()
                    "Saved to your Gallery"
                }
                Place.PRIVATE -> {
                    val newUri = openInput(uri).use { LocalStore.save(app, it, name) }
                    val removed = deleteMedia(uri)
                    patch(id) { it.copy(uri = newUri, place = Place.PRIVATE) }
                    saveHistory()
                    if (removed) "Hidden from your Gallery"
                    else "Copied into TubeVault. Android didn't let TubeVault remove the Gallery copy — delete it from your Gallery app."
                }
            }
        } finally {
            tmpDir.deleteRecursively()
        }
    }

    private fun openInput(uri: String) =
        LocalStore.fileOf(uri)?.inputStream()
            ?: app.contentResolver.openInputStream(Uri.parse(uri))
            ?: throw IllegalStateException("The file was moved or deleted")

    /** Deletes a library file. Returns false if Android refused (e.g. a Gallery file from an older install). */
    private fun deleteMedia(uri: String): Boolean = try {
        val f = LocalStore.fileOf(uri)
        if (f != null) f.delete() || !f.exists()
        else app.contentResolver.delete(Uri.parse(uri), null, null) > 0
    } catch (_: Throwable) {
        false
    }

    private fun displayName(item: DownloadItem): String {
        val uri = item.uri ?: return MediaSaver.sanitize(item.title) + if (item.isAudio) ".m4a" else ".mp4"
        LocalStore.fileOf(uri)?.let { return it.name }
        try {
            app.contentResolver.query(Uri.parse(uri), arrayOf(android.provider.MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0)?.let { return it } }
        } catch (_: Throwable) {
        }
        return MediaSaver.sanitize(item.title) + if (item.isAudio) ".m4a" else ".mp4"
    }

    private fun coverBytes(item: DownloadItem): ByteArray? {
        val t = item.thumbnail
        if (t != null && t.startsWith("file://")) {
            try {
                return Uri.parse(t).path?.let { File(it).readBytes() }
            } catch (_: Throwable) {
            }
        }
        if (t != null && t.startsWith("http")) Thumbs.download(t)?.let { return it }
        return item.uri?.let { Thumbs.fromMedia(app, Uri.parse(it), item.isAudio) }
    }

    // ---------------------------------------------------------------- engine

    private fun launchJob(id: String) {
        jobs[id] = scope.launch {
            try {
                gate.withPermit { process(id) }
            } finally {
                jobs.remove(id)
            }
        }
    }

    private fun patch(id: String, f: (DownloadItem) -> DownloadItem) {
        _items.update { list -> list.map { if (it.id == id) f(it) else it } }
    }

    private suspend fun process(id: String) {
        val req = requests[id] ?: return
        val info = req.info
        val opt = req.opt
        val place = req.place
        val dir = File(app.cacheDir, "dl/$id").apply { mkdirs() }
        try {
            patch(id) { it.copy(status = Status.DOWNLOADING, progress = if (opt.sizeBytes > 0) 0f else -1f) }

            // Cover art downloads at the same time as the video.
            val coverJob = scope.async { Thumbs.download(info.thumbnail) }

            val total = opt.sizeBytes
            val done = AtomicLong(0)
            val meter = Any()
            var lastT = SystemClock.elapsedRealtime()
            var lastD = 0L
            var speed = 0L
            val onBytes: (Long) -> Unit = { n ->
                val d = done.addAndGet(n)
                synchronized(meter) {
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastT >= 300) {
                        val inst = ((d - lastD) * 1000.0 / (now - lastT)).toLong()
                        speed = if (speed == 0L) inst else (speed * 0.6 + inst * 0.4).toLong()
                        lastT = now
                        lastD = d
                        val p = if (total > 0) (d.toFloat() / total).coerceIn(0f, 0.99f) else -1f
                        patch(id) { it.copy(progress = p, speed = speed, doneBytes = d) }
                    }
                }
            }

            var out: File
            if (opt.ytdlpFormat != null) {
                // Universal engine (yt-dlp): any supported site
                out = UniversalRepo.download(info.url, opt, dir, id) { pr ->
                    if (pr.postProcessing) {
                        patch(id) { it.copy(status = Status.MERGING, progress = -1f, speed = 0L) }
                    } else {
                        val d = if (total > 0) (total * pr.fraction).toLong() else 0L
                        patch(id) {
                            it.copy(status = Status.DOWNLOADING, progress = pr.fraction, speed = pr.speed, doneBytes = d)
                        }
                    }
                }
            } else if (opt.hlsUrl != null) {
                val v = File(dir, "hls_v.bin")
                var aFile: File? = null
                coroutineScope {
                    val a = if (opt.hlsAudioUrl != null && !opt.hlsAudioOnly) async {
                        File(dir, "hls_a.bin").also { Hls.download(opt.hlsAudioUrl, it, onBytes) }
                    } else null
                    Hls.download(opt.hlsUrl, v, onBytes)
                    aFile = a?.await()
                }
                patch(id) { it.copy(status = Status.MERGING, progress = -1f, speed = 0L) }
                out = File(dir, if (opt.isAudio) "out.m4a" else "out.mp4")
                val af = aFile
                if (af != null) Muxer.merge(v, af, out) else Muxer.remux(v, out, opt.isAudio)
            } else if (opt.needsMerge) {
                val v = File(dir, "v.mp4")
                val a = File(dir, "a.m4a")
                // video + audio download at the same time (faster)
                coroutineScope {
                    val aj = async { Net.download(opt.audio!!.content, a, onBytes) }
                    Net.download(opt.video!!.content, v, onBytes)
                    aj.await()
                }
                patch(id) { it.copy(status = Status.MERGING, progress = -1f, speed = 0L) }
                out = File(dir, "out.mp4")
                Muxer.merge(v, a, out)
                v.delete()
                a.delete()
            } else if (opt.isAudio) {
                val a = File(dir, "a.m4a")
                Net.download(opt.audio!!.content, a, onBytes)
                patch(id) { it.copy(status = Status.MERGING, progress = -1f, speed = 0L) }
                val remuxed = File(dir, "out.m4a")
                out = try {
                    Muxer.remux(a, remuxed)
                    remuxed
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    a // fall back to the raw file – still plays fine
                }
            } else {
                out = File(dir, "out.mp4")
                Net.download(opt.video!!.content, out, onBytes)
            }

            patch(id) { it.copy(status = Status.SAVING, progress = -1f, speed = 0L) }
            val cover = try { coverJob.await() } catch (_: Throwable) { null }
            // Title, artist and cover go INSIDE the file (survives reinstalls, shows in music apps)
            out = Thumbs.embed(out, info.title, info.uploader, cover)

            val ext = out.extension.lowercase().ifEmpty { if (opt.isAudio) "m4a" else "mp4" }
            val name = MediaSaver.sanitize(info.title) +
                (if (opt.isAudio) "" else " (${opt.label.replace(" ", "")})") + "." + ext
            val mime = LocalStore.mimeOf(name, opt.isAudio)
            val size = out.length()

            when (place) {
                Place.VAULT -> {
                    Vault.addFile(out, info.title, info.uploader, if (opt.isAudio) "Audio M4A" else opt.label, opt.isAudio, cover)
                    patch(id) {
                        it.copy(
                            status = Status.DONE, progress = 1f, speed = 0L, doneBytes = size,
                            totalBytes = size, uri = null, error = null, label = "Locked in your Vault"
                        )
                    }
                    requests.remove(id)
                    notifyDone(PRIVATE_TITLE, null, opt.isAudio, true, null, secret = true)
                    // the Library card disappears after the celebration
                    scope.launch {
                        delay(4500)
                        _items.update { l -> l.filterNot { it.id == id } }
                    }
                }
                else -> {
                    val localThumb = Thumbs.saveLocal(app, id, cover) ?: info.thumbnail
                    val uri: Uri = if (place == Place.GALLERY) MediaSaver.save(app, out, name, mime, opt.isAudio)
                    else Uri.parse(LocalStore.save(app, out, name))
                    patch(id) {
                        it.copy(
                            status = Status.DONE, progress = 1f, speed = 0L, doneBytes = size,
                            totalBytes = size, uri = uri.toString(), error = null, thumbnail = localThumb
                        )
                    }
                    requests.remove(id)
                    saveHistory()
                    notifyDone(info.title, if (place == Place.GALLERY) uri else null, opt.isAudio, true, mime)
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            if (!requests.containsKey(id)) return // cancelled by the user
            patch(id) { it.copy(status = Status.FAILED, speed = 0L, progress = 0f, error = Errors.friendly(e)) }
            notifyDone(if (place == Place.VAULT) PRIVATE_TITLE else info.title, null, opt.isAudio, false, secret = place == Place.VAULT)
        } finally {
            dir.deleteRecursively()
        }
    }

    // ---------------------------------------------------------------- notifications

    private fun notifyDone(
        title: String, uri: Uri?, audio: Boolean, ok: Boolean, mime: String? = null, secret: Boolean = false
    ) {
        try {
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(app, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) return

            val pi: PendingIntent = if (ok && uri != null) {
                val view = Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, mime ?: if (audio) "audio/mp4" else "video/mp4")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                PendingIntent.getActivity(
                    app, uri.hashCode(), view, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            } else {
                PendingIntent.getActivity(
                    app, 0, Intent(app, MainActivity::class.java),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            }
            val n = NotificationCompat.Builder(app, App.CH_DONE)
                .setSmallIcon(R.drawable.ic_stat_download)
                .setContentTitle(if (ok) "Download complete" else "Download failed")
                .setContentText(title)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setVisibility(if (secret) NotificationCompat.VISIBILITY_SECRET else NotificationCompat.VISIBILITY_PRIVATE)
                .build()
            NotificationManagerCompat.from(app).notify((System.nanoTime() % 100000).toInt() + 100, n)
        } catch (_: Throwable) {
        }
    }

    // ---------------------------------------------------------------- restore & repair

    /**
     * One file = one card. MediaStore gives the same file different-looking uris
     * (".../external_primary/audio/media/42" vs ".../external/audio/media/42"), which used to
     * make every song appear twice after a restore. The numeric media id is the real identity.
     */
    private fun keyOf(i: DownloadItem): String {
        val u = i.uri ?: return "id:" + i.id
        return if (u.startsWith("content://media/")) "media:" + (Uri.parse(u).lastPathSegment ?: u) else "uri:$u"
    }

    private fun dedupe(list: List<DownloadItem>): List<DownloadItem> {
        val best = LinkedHashMap<String, DownloadItem>()
        for (i in list) {
            val k = if (i.status == Status.DONE) keyOf(i) else "id:" + i.id
            val old = best[k]
            best[k] = if (old == null) i else pickBetter(old, i)
        }
        return best.values.toList()
    }

    private fun pickBetter(a: DownloadItem, b: DownloadItem): DownloadItem {
        fun score(x: DownloadItem) = (if (x.id.startsWith("restored_")) 0 else 2) + (if (x.thumbnail != null) 1 else 0)
        return if (score(b) > score(a)) b else a
    }

    /**
     * Finds files already saved in Movies/TubeVault and Music/TubeVault that are not in the list
     * (e.g. after a reinstall) and puts them back into the Library, with their thumbnails.
     * Returns how many were added.
     */
    @Suppress("DEPRECATION")
    fun restoreFromStorage(): Int {
        if (!::app.isInitialized) return 0
        return try {
            val known = _items.value.map { keyOf(it) }.toHashSet()
            val found = ArrayList<DownloadItem>()
            for (audio in listOf(true, false)) {
                val coll = if (audio) android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                else android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                val proj = arrayOf(
                    android.provider.MediaStore.MediaColumns._ID,
                    android.provider.MediaStore.MediaColumns.DISPLAY_NAME,
                    android.provider.MediaStore.MediaColumns.SIZE,
                    android.provider.MediaStore.MediaColumns.DATE_ADDED
                )
                val dir = if (audio) "Music" else "Movies"
                val sel: String
                val args: Array<String>
                if (Build.VERSION.SDK_INT >= 29) {
                    sel = android.provider.MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?"
                    args = arrayOf("$dir/TubeVault%")
                } else {
                    sel = android.provider.MediaStore.MediaColumns.DATA + " LIKE ?"
                    args = arrayOf("%/$dir/TubeVault/%")
                }
                app.contentResolver.query(coll, proj, sel, args, null)?.use { c ->
                    while (c.moveToNext()) {
                        val mediaId = c.getLong(0)
                        val uri = android.content.ContentUris.withAppendedId(coll, mediaId)
                        val tmp = DownloadItem(
                            id = "restored_$mediaId", title = "", uploader = "", thumbnail = null, label = "",
                            isAudio = audio, status = Status.DONE, progress = 1f, speed = 0L, doneBytes = 0L,
                            totalBytes = 0L, uri = uri.toString(), error = null, createdAt = 0L
                        )
                        if (!known.add(keyOf(tmp))) continue
                        val name = c.getString(1) ?: continue
                        val thumb = Thumbs.saveLocal(app, "restored_$mediaId", Thumbs.fromMedia(app, uri, audio))
                        val stem = name.substringBeforeLast('.')
                        found.add(
                            tmp.copy(
                                title = if (audio) stem else stem.replace(Regex("\\s*\\(\\d{3,4}p\\d*\\)$"), ""),
                                thumbnail = thumb,
                                label = if (audio) "Audio M4A" else Regex("\\((\\d{3,4}p\\d*)\\)").find(stem)?.groupValues?.get(1)
                                    ?: name.substringAfterLast('.', "").uppercase(),
                                doneBytes = c.getLong(2), totalBytes = c.getLong(2),
                                createdAt = c.getLong(3) * 1000L,
                                place = Place.GALLERY
                            )
                        )
                    }
                }
            }
            if (found.isNotEmpty()) {
                _items.update { dedupe((it + found).sortedByDescending { x -> x.createdAt }) }
                saveHistory()
            }
            found.size
        } catch (_: Throwable) {
            0
        }
    }

    /**
     * Background pass after start:
     *  - removes duplicate cards
     *  - gives every item a local thumbnail (online ones are saved to the phone, missing ones
     *    are taken from the file), so nothing shows black
     *  - writes cover art into older songs saved to the Gallery, so they keep it after a reinstall
     */
    private fun repairLibrary() {
        try {
            val prefs = app.getSharedPreferences("tubevault", Context.MODE_PRIVATE)
            val tagged = prefs.getStringSet("tagged", emptySet())!!.toMutableSet()
            var changed = false
            _items.update { dedupe(it) }
            for (item in _items.value.filter { it.status == Status.DONE && it.uri != null && it.place != Place.VAULT }) {
                val t = item.thumbnail
                var jpeg: ByteArray? = null
                if (t == null || t.startsWith("http")) {
                    jpeg = if (t != null) Thumbs.download(t) else null
                    if (jpeg == null) jpeg = Thumbs.fromMedia(app, Uri.parse(item.uri), item.isAudio)
                    val local = Thumbs.saveLocal(app, item.id, jpeg)
                    if (local != null) {
                        patch(item.id) { it.copy(thumbnail = local) }
                        changed = true
                    }
                } else if (t.startsWith("file://") && !File(Uri.parse(t).path ?: "").exists()) {
                    jpeg = Thumbs.fromMedia(app, Uri.parse(item.uri), item.isAudio)
                    patch(item.id) { it.copy(thumbnail = Thumbs.saveLocal(app, item.id, jpeg)) }
                    changed = true
                }
                if (item.isAudio && item.place == Place.GALLERY && item.id !in tagged && !item.id.startsWith("restored_")) {
                    val cover = jpeg ?: coverBytes(item)
                    if (retagGalleryFile(item, cover)) {
                        tagged.add(item.id)
                        prefs.edit().putStringSet("tagged", HashSet(tagged)).apply()
                    }
                }
            }
            if (changed) saveHistory()
        } catch (_: Throwable) {
        }
    }

    /** Rewrites an older Gallery song with its cover inside. Checked before it is written back. */
    private fun retagGalleryFile(item: DownloadItem, cover: ByteArray?): Boolean {
        if (cover == null) return false
        val uri = Uri.parse(item.uri ?: return false)
        val dir = File(app.cacheDir, "retag").apply { mkdirs() }
        val src = File(dir, "in.m4a")
        val dst = File(dir, "out.m4a")
        return try {
            app.contentResolver.openInputStream(uri)?.use { i -> src.outputStream().use { i.copyTo(it, 256 * 1024) } } ?: return false
            val tracks = Thumbs.trackCount(src)
            if (tracks <= 0) return false
            if (!Mp4Tagger.tag(src, dst, item.title, item.uploader, cover) || !Thumbs.stillPlayable(dst, tracks)) return false
            app.contentResolver.openOutputStream(uri, "wt")?.use { o -> dst.inputStream().use { it.copyTo(o, 256 * 1024) } } ?: return false
            true
        } catch (_: Throwable) {
            false
        } finally {
            dir.deleteRecursively()
        }
    }

    // ---------------------------------------------------------------- history

    private fun saveHistory() {
        val arr = JSONArray()
        for (i in _items.value) {
            if (i.status != Status.DONE || i.uri == null || i.place == Place.VAULT) continue
            arr.put(
                JSONObject()
                    .put("id", i.id).put("title", i.title).put("uploader", i.uploader)
                    .put("thumb", i.thumbnail ?: "").put("label", i.label).put("audio", i.isAudio)
                    .put("uri", i.uri).put("size", i.totalBytes).put("time", i.createdAt)
                    .put("place", i.place.name)
            )
        }
        app.getSharedPreferences("tubevault", Context.MODE_PRIVATE)
            .edit().putString("history", arr.toString()).apply()
    }

    private fun loadHistory(): List<DownloadItem> {
        return try {
            val raw = app.getSharedPreferences("tubevault", Context.MODE_PRIVATE)
                .getString("history", null) ?: return emptyList()
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { idx ->
                val o = arr.getJSONObject(idx)
                val uri = o.getString("uri")
                // a private file that no longer exists -> drop the card
                LocalStore.fileOf(uri)?.let { if (!it.exists()) return@mapNotNull null }
                DownloadItem(
                    id = o.getString("id"),
                    title = o.getString("title"),
                    uploader = o.optString("uploader"),
                    thumbnail = o.optString("thumb").ifEmpty { null },
                    label = o.optString("label"),
                    isAudio = o.optBoolean("audio"),
                    status = Status.DONE,
                    progress = 1f,
                    speed = 0L,
                    doneBytes = o.optLong("size"),
                    totalBytes = o.optLong("size"),
                    uri = uri,
                    error = null,
                    createdAt = o.optLong("time"),
                    place = try { Place.valueOf(o.optString("place", "GALLERY")) } catch (_: Exception) { Place.GALLERY }
                )
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }
}
