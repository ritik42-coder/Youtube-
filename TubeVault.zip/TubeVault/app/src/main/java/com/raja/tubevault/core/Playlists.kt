package com.raja.tubevault.core

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Playlist(val id: String, val name: String, val ids: List<String>)

/** User playlists (plus a built-in Favourites list). Stored on the phone. */
object Playlists {
    const val FAV = "favorites"
    private lateinit var app: Context

    var all by mutableStateOf<List<Playlist>>(emptyList())
        private set

    fun init(c: Context) {
        app = c.applicationContext
        all = load()
        if (all.none { it.id == FAV }) all = listOf(Playlist(FAV, "Favourites", emptyList())) + all
    }

    fun create(name: String, ids: List<String> = emptyList()): Playlist {
        val p = Playlist(UUID.randomUUID().toString(), name.trim().ifEmpty { "My playlist" }.take(40), ids)
        all = all + p
        save()
        return p
    }

    fun delete(id: String) {
        if (id == FAV) return
        all = all.filterNot { it.id == id }
        save()
    }

    fun rename(id: String, name: String) {
        all = all.map { if (it.id == id && id != FAV) it.copy(name = name.trim().take(40).ifEmpty { it.name }) else it }
        save()
    }

    fun add(id: String, itemId: String) {
        all = all.map { if (it.id == id && itemId !in it.ids) it.copy(ids = it.ids + itemId) else it }
        save()
    }

    fun remove(id: String, itemId: String) {
        all = all.map { if (it.id == id) it.copy(ids = it.ids - itemId) else it }
        save()
    }

    fun toggleFav(itemId: String) {
        val fav = all.firstOrNull { it.id == FAV } ?: return
        if (itemId in fav.ids) remove(FAV, itemId) else add(FAV, itemId)
    }

    fun isFav(itemId: String): Boolean = all.firstOrNull { it.id == FAV }?.ids?.contains(itemId) == true

    fun items(p: Playlist, library: List<DownloadItem>): List<DownloadItem> {
        val map = library.associateBy { it.id }
        return p.ids.mapNotNull { map[it] }.filter { it.status == Status.DONE && it.uri != null }
    }

    private fun save() {
        val arr = JSONArray()
        for (p in all) {
            arr.put(JSONObject().put("id", p.id).put("name", p.name).put("ids", JSONArray(p.ids)))
        }
        app.getSharedPreferences("tubevault_playlists", Context.MODE_PRIVATE)
            .edit().putString("lists", arr.toString()).apply()
    }

    private fun load(): List<Playlist> = try {
        val raw = app.getSharedPreferences("tubevault_playlists", Context.MODE_PRIVATE)
            .getString("lists", null)
        if (raw == null) emptyList() else {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val ids = o.getJSONArray("ids")
                Playlist(o.getString("id"), o.getString("name"), (0 until ids.length()).map { ids.getString(it) })
            }
        }
    } catch (_: Throwable) {
        emptyList()
    }
}

/** Remembers what you listen to, for the smart mixes (Most played / Recently played). */
object PlayStats {
    private lateinit var app: Context
    private var counts = HashMap<String, Int>()
    private var last = HashMap<String, Long>()

    fun init(c: Context) {
        app = c.applicationContext
        try {
            val o = JSONObject(app.getSharedPreferences("tubevault_stats", Context.MODE_PRIVATE).getString("s", "{}") ?: "{}")
            val cs = o.optJSONObject("c"); val ls = o.optJSONObject("l")
            cs?.keys()?.forEach { counts[it] = cs.getInt(it) }
            ls?.keys()?.forEach { last[it] = ls.getLong(it) }
        } catch (_: Throwable) {
        }
    }

    fun record(id: String) {
        counts[id] = (counts[id] ?: 0) + 1
        last[id] = System.currentTimeMillis()
        try {
            val o = JSONObject().put("c", JSONObject(counts as Map<*, *>)).put("l", JSONObject(last as Map<*, *>))
            app.getSharedPreferences("tubevault_stats", Context.MODE_PRIVATE).edit().putString("s", o.toString()).apply()
        } catch (_: Throwable) {
        }
    }

    fun count(id: String) = counts[id] ?: 0
    fun lastPlayed(id: String) = last[id] ?: 0L
}
