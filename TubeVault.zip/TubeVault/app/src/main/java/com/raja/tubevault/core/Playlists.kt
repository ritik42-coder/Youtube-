package com.raja.tubevault.core

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Playlist(val id: String, val name: String, val ids: List<String>)

/** Saved playlists, kept in shared preferences as JSON so they survive restarts and updates. */
object Playlists {

    private var app: Context? = null

    var all by mutableStateOf<List<Playlist>>(emptyList())
        private set

    fun init(ctx: Context) {
        if (app != null) return
        app = ctx.applicationContext
        all = load()
    }

    /** Saves [ids] as a new playlist; returns the new playlist, or null if there is nothing to save. */
    fun create(name: String, ids: List<String>): Playlist? {
        if (ids.isEmpty()) return null
        val pl = Playlist(UUID.randomUUID().toString(), name, ids.distinct())
        all = all + pl
        save()
        return pl
    }

    fun rename(id: String, name: String) {
        all = all.map { if (it.id == id) it.copy(name = name) else it }
        save()
    }

    fun addTo(id: String, itemId: String) {
        all = all.map {
            if (it.id == id && itemId !in it.ids) it.copy(ids = it.ids + itemId) else it
        }
        save()
    }

    fun removeFrom(id: String, itemId: String) {
        all = all.map { if (it.id == id) it.copy(ids = it.ids - itemId) else it }
        save()
    }

    fun delete(id: String) {
        all = all.filterNot { it.id == id }
        save()
    }

    // --------------------------------------------------------------- storage

    private fun save() {
        val c = app ?: return
        val arr = JSONArray()
        for (p in all) {
            val o = JSONObject()
            o.put("id", p.id)
            o.put("name", p.name)
            val ids = JSONArray()
            p.ids.forEach { ids.put(it) }
            o.put("ids", ids)
            arr.put(o)
        }
        c.getSharedPreferences("tubevault_playlists", Context.MODE_PRIVATE)
            .edit().putString("data", arr.toString()).apply()
    }

    private fun load(): List<Playlist> {
        val c = app ?: return emptyList()
        val raw = c.getSharedPreferences("tubevault_playlists", Context.MODE_PRIVATE)
            .getString("data", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val ids = o.optJSONArray("ids") ?: JSONArray()
                Playlist(
                    id = o.optString("id", UUID.randomUUID().toString()),
                    name = o.optString("name", "Playlist"),
                    ids = (0 until ids.length()).map { ids.getString(it) }
                )
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }
}
