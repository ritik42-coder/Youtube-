package com.raja.tubevault.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.FlashOn
import androidx.compose.material.icons.rounded.BugReport
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Update
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raja.tubevault.BuildConfig
import com.raja.tubevault.core.Downloads
import com.raja.tubevault.core.Highlight
import com.raja.tubevault.core.ReleaseInfo
import com.raja.tubevault.core.UpdateState
import com.raja.tubevault.core.Updater
import com.raja.tubevault.core.formatBytes
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// ============================================================ helpers

private fun iconFor(name: String): ImageVector = when (name.lowercase()) {
    "update", "sync", "download" -> Icons.Rounded.Update
    "shield", "security", "safe" -> Icons.Rounded.Security
    "settings", "tune" -> Icons.Rounded.Settings
    "notifications", "bell" -> Icons.Rounded.Notifications
    "bolt", "fast", "speed" -> Icons.Rounded.FlashOn
    "music", "audio" -> Icons.Rounded.MusicNote
    "lock", "vault" -> Icons.Rounded.Lock
    "palette", "theme" -> Icons.Rounded.Palette
    "heart", "favorite" -> Icons.Rounded.Favorite
    "star" -> Icons.Rounded.Star
    "bug", "fix" -> Icons.Rounded.BugReport
    "cloud" -> Icons.Rounded.CloudDownload
    "video" -> Icons.Rounded.Videocam
    "eq", "visualizer" -> Icons.Rounded.GraphicEq
    "wifi" -> Icons.Rounded.Wifi
    "gauge" -> Icons.Rounded.Speed
    else -> Icons.Rounded.AutoAwesome
}

private val tilePairs = listOf(
    Pink to Orange,
    Violet to Pink,
    Cyan to Violet,
    Green to Cyan,
    Orange to Pink
)

private fun infoOf(st: UpdateState): ReleaseInfo? = when (st) {
    is UpdateState.Available -> st.info
    is UpdateState.Downloading -> st.info
    is UpdateState.Ready -> st.info
    is UpdateState.Installing -> st.info
    is UpdateState.Failed -> st.info
    else -> null
}

@Composable
private fun ActionButton(
    text: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val t = rememberInfiniteTransition(label = "ab")
    val v by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "abv")
    Row(
        modifier
            .fillMaxWidth()
            .height(58.dp)
            .pressable(onClick)
            .clip(RoundedCornerShape(20.dp))
            .background(AccentBrush2)
            .drawWithContent {
                drawContent()
                if (v < 0.5f) {
                    val k = v / 0.5f
                    val x = (k * 1.6f - 0.3f) * size.width
                    drawRect(
                        Brush.linearGradient(
                            listOf(Color.Transparent, Color.White.copy(alpha = 0.35f), Color.Transparent),
                            start = Offset(x, 0f),
                            end = Offset(x + size.height * 1.2f, size.height)
                        )
                    )
                }
            },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
    }
}

@Composable
private fun TextAction(text: String, color: Color = TextLo, onClick: () -> Unit) {
    Text(
        text,
        color = color,
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp)
    )
}

// ============================================================ host

@Composable
fun UpdateHost(ready: Boolean) {
    val ctx = LocalContext.current
    LaunchedEffect(ready) { if (ready) Updater.onAppReady(ctx) }

    val wn = Updater.whatsNew
    val st = Updater.state
    val showSheet = ready && wn == null && Updater.sheetOpen &&
        st !is UpdateState.Idle && st !is UpdateState.Checking && st !is UpdateState.UpToDate

    // keep the last content alive while the exit animation runs
    val lastWn = remember { arrayOfNulls<ReleaseInfo>(1) }
    if (wn != null) lastWn[0] = wn
    val lastSt = remember { arrayOfNulls<UpdateState>(1) }
    if (showSheet) lastSt[0] = st

    BackHandler(enabled = wn != null) { Updater.dismissWhatsNew() }
    BackHandler(enabled = showSheet) { Updater.sheetOpen = false }

    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(showSheet, enter = fadeIn(tween(250)), exit = fadeOut(tween(250))) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color(0xAA000000))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                        Updater.sheetOpen = false
                    }
            )
        }
        AnimatedVisibility(
            showSheet,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(spring(dampingRatio = 0.78f, stiffness = 300f)) { it } + fadeIn(tween(200)),
            exit = slideOutVertically(tween(260)) { it } + fadeOut(tween(200))
        ) {
            val s = if (showSheet) st else (lastSt[0] ?: st)
            UpdateSheet(s)
        }
        AnimatedVisibility(wn != null, enter = fadeIn(tween(450)), exit = fadeOut(tween(300))) {
            val info = lastWn[0]
            if (info != null) WhatsNewScreen(info)
        }
    }
}

// ============================================================ update sheet

@Composable
private fun UpdateHero(progress: Float, st: UpdateState, heroSize: Dp = 124.dp) {
    val t = rememberInfiniteTransition(label = "hero")
    val pulse by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "pulse")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "spin")
    val bob by t.animateFloat(
        -4f, 4f,
        infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bob"
    )
    val dots = remember { listOf(Pink, Orange, Violet, Cyan, Green) }
    Box(Modifier.size(heroSize + 56.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val base = this.size.minDimension / 2f
            for (k in 0..2) {
                val p = (pulse + k / 3f) % 1f
                drawCircle(
                    Pink.copy(alpha = (1f - p) * 0.35f),
                    radius = base * (0.55f + 0.45f * p),
                    center = c,
                    style = Stroke(2.dp.toPx())
                )
            }
            drawCircle(
                Brush.radialGradient(listOf(Pink.copy(alpha = 0.40f), Color.Transparent), center = c, radius = base * 0.9f),
                radius = base * 0.9f,
                center = c
            )
            for (i in 0 until 5) {
                val a = (spin + i * 72f) * (PI.toFloat() / 180f)
                val r = base * 0.74f
                drawCircle(
                    dots[i].copy(alpha = 0.9f),
                    radius = 3.5.dp.toPx(),
                    center = Offset(c.x + cos(a) * r, c.y + sin(a) * r)
                )
            }
        }
        RingProgress(progress, Modifier.size(heroSize), stroke = 6.dp) {
            when (st) {
                is UpdateState.Downloading -> {
                    val pct = if (st.total > 0) (st.done * 100 / st.total).toInt() else 0
                    Text("$pct%", color = TextHi, fontWeight = FontWeight.Black, fontSize = 30.sp)
                }
                is UpdateState.Ready -> AnimatedCheck(Green, Modifier.size(50.dp))
                is UpdateState.Installing -> CircularProgressIndicator(
                    modifier = Modifier.size(34.dp), color = Color.White, strokeWidth = 3.dp
                )
                else -> Icon(
                    Icons.Rounded.ArrowUpward, null, tint = Color.White,
                    modifier = Modifier.size(46.dp).offset(y = bob.dp)
                )
            }
        }
    }
}

@Composable
private fun UpdateSheet(st: UpdateState) {
    val ctx = LocalContext.current
    val info = infoOf(st) ?: return
    val shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)
    val items by Downloads.items.collectAsState()
    val busy = items.count { it.status in Downloads.ACTIVE }

    val progress = when (st) {
        is UpdateState.Downloading -> if (st.total > 0) st.done.toFloat() / st.total else -1f
        is UpdateState.Ready -> 1f
        is UpdateState.Installing -> -1f
        else -> 0f
    }

    Box(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Color(0xF7101018))
            .border(BorderStroke(1.dp, GlassBorder), shape)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(Brush.verticalGradient(listOf(Pink.copy(alpha = 0.22f), Color.Transparent)))
        )
        if (st is UpdateState.Ready) {
            ConfettiBurst(Modifier.fillMaxWidth().height(260.dp), 0.5f, 0.28f, 40, 1500)
        }
        Column(
            Modifier
                .heightIn(max = 760.dp)
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(horizontal = 22.dp)
                .padding(top = 12.dp, bottom = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier
                    .width(42.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(0x33FFFFFF))
            )
            Spacer(Modifier.height(10.dp))
            UpdateHero(progress, st)

            val headline = when (st) {
                is UpdateState.Downloading -> "Downloading update"
                is UpdateState.Ready -> "Ready to install"
                is UpdateState.Installing -> "Installing…"
                is UpdateState.Failed -> "Update didn't finish"
                else -> "New version available"
            }
            ShimmerTitle(headline, 26.sp)
            Spacer(Modifier.height(10.dp))

            // version chip:  v2.4  ->  v2.5   •   48 MB
            Row(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(Glass)
                    .border(BorderStroke(1.dp, GlassBorder), RoundedCornerShape(50))
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("v" + BuildConfig.VERSION_NAME, color = TextLo, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Spacer(Modifier.width(8.dp))
                Icon(Icons.Rounded.ArrowUpward, null, tint = Pink, modifier = Modifier.size(15.dp).graphicsLayer { rotationZ = 90f })
                Spacer(Modifier.width(8.dp))
                Text(
                    "v" + info.versionName,
                    color = TextHi, fontWeight = FontWeight.Black, fontSize = 15.sp
                )
                if (info.size > 0) {
                    Spacer(Modifier.width(10.dp))
                    Text("•  " + formatBytes(info.size), color = TextLo, fontSize = 13.sp)
                }
            }
            Spacer(Modifier.height(16.dp))

            // highlights of the new version
            if (info.highlights.isNotEmpty()) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.AutoAwesome, null, tint = Orange, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("What's new", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                Spacer(Modifier.height(8.dp))
                info.highlights.forEachIndexed { i, h ->
                    Staggered(i, Modifier.fillMaxWidth()) { MiniHighlight(i, h) }
                }
                Spacer(Modifier.height(8.dp))
            } else if (info.subtitle.isNotBlank()) {
                Text(info.subtitle, color = TextLo, fontSize = 14.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
            }

            // ---------------- state specific area
            when (st) {
                is UpdateState.Downloading -> {
                    GradientProgress(
                        if (st.total > 0) (st.done.toFloat() / st.total).coerceIn(0f, 1f) else 0f,
                        Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    val speedTxt = if (st.speed > 0) formatBytes(st.speed) + "/s" else "starting…"
                    val eta = if (st.speed > 0 && st.total > st.done) "  •  " + formatEta((st.total - st.done) / st.speed) + " left" else ""
                    Text(
                        formatBytes(st.done) + " / " + formatBytes(st.total) + "  •  " + speedTxt + eta,
                        color = TextLo, fontSize = 12.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    Row {
                        TextAction("Hide") { Updater.sheetOpen = false }
                        TextAction("Cancel", Pink) { Updater.cancelDownload() }
                    }
                }
                is UpdateState.Ready -> {
                    if (Updater.needsInstallPermission) {
                        Text(
                            "Allow TubeVault to install apps in the screen that just opened, then come back. The update continues by itself.",
                            color = Orange, fontSize = 12.sp, textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(8.dp))
                    }
                    if (busy > 0) {
                        Text(
                            "A download is still running. Installing restarts TubeVault and will stop it.",
                            color = Orange, fontSize = 12.sp, textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(8.dp))
                    }
                    Text(
                        "Downloaded and verified ✓",
                        color = Green, fontWeight = FontWeight.SemiBold, fontSize = 13.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    ActionButton("Install now", Icons.Rounded.Update) { Updater.install(ctx) }
                    Spacer(Modifier.height(4.dp))
                    Row {
                        TextAction("Later") { Updater.sheetOpen = false }
                        TextAction("Skip this version") { Updater.skipVersion(ctx) }
                    }
                }
                is UpdateState.Installing -> {
                    Text(
                        "Installing… If Android asks, tap Update. TubeVault restarts when it is done.",
                        color = TextLo, fontSize = 13.sp, textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(12.dp))
                }
                is UpdateState.Failed -> {
                    Text(st.message, color = Pink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(10.dp))
                    ActionButton("Try again", Icons.Rounded.Refresh) { Updater.retry(ctx) }
                    Spacer(Modifier.height(4.dp))
                    TextAction("Close") { Updater.sheetOpen = false }
                }
                else -> {
                    ActionButton("Update now", Icons.Rounded.Download) { Updater.startDownload(ctx) }
                    Spacer(Modifier.height(4.dp))
                    Row {
                        TextAction("Later") { Updater.sheetOpen = false }
                        TextAction("Skip this version") { Updater.skipVersion(ctx) }
                    }
                }
            }
        }
    }
}

@Composable
private fun MiniHighlight(index: Int, h: Highlight) {
    val pair = tilePairs[index % tilePairs.size]
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(Brush.linearGradient(listOf(pair.first, pair.second))),
            contentAlignment = Alignment.Center
        ) { Icon(iconFor(h.icon), null, tint = Color.White, modifier = Modifier.size(22.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(h.title, color = TextHi, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            if (h.desc.isNotBlank()) Text(h.desc, color = TextLo, fontSize = 12.sp)
        }
    }
}

// ============================================================ What's new

@Composable
private fun WhatsNewScreen(info: ReleaseInfo) {
    val t = rememberInfiniteTransition(label = "wn")
    val drift by t.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse),
        label = "drift"
    )
    val rise by t.animateFloat(0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "rise")

    Box(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val c1 = Offset(w * (0.15f + 0.6f * drift), h * 0.16f)
            val c2 = Offset(w * (0.95f - 0.6f * drift), h * 0.55f)
            val c3 = Offset(w * (0.3f + 0.4f * drift), h * 0.95f)
            drawCircle(Brush.radialGradient(listOf(Pink.copy(alpha = 0.38f), Color.Transparent), center = c1, radius = w * 0.85f), radius = w * 0.85f, center = c1)
            drawCircle(Brush.radialGradient(listOf(Violet.copy(alpha = 0.34f), Color.Transparent), center = c2, radius = w * 0.85f), radius = w * 0.85f, center = c2)
            drawCircle(Brush.radialGradient(listOf(Cyan.copy(alpha = 0.22f), Color.Transparent), center = c3, radius = w * 0.8f), radius = w * 0.8f, center = c3)
            // rising sparkles
            for (i in 0 until 28) {
                val ph = (rise + i / 28f) % 1f
                val x = (sin(i * 37.1f) * 0.5f + 0.5f) * w
                val y = h - ph * h
                val a = sin(ph * PI.toFloat())
                drawCircle(Color.White.copy(alpha = a * 0.55f), radius = (1f + (i % 3)) * density, center = Offset(x, y))
            }
        }

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 22.dp)
        ) {
            Spacer(Modifier.height(34.dp))
            Staggered(0) {
                Row(
                    Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Glass)
                        .border(BorderStroke(1.dp, GlassBorder), RoundedCornerShape(50))
                        .padding(horizontal = 14.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.AutoAwesome, null, tint = Orange, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(7.dp))
                    Text("VERSION " + info.versionName, color = TextHi, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
            Staggered(1) { ShimmerTitle(info.title, 34.sp) }
            if (info.subtitle.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Staggered(2) { Text(info.subtitle, color = TextLo, fontSize = 15.sp) }
            }
            Spacer(Modifier.height(18.dp))
            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
            ) {
                info.highlights.forEachIndexed { i, h -> HighlightCard(i, h) }
                Spacer(Modifier.height(8.dp))
            }
            Spacer(Modifier.height(10.dp))
            ActionButton("Let's go", Icons.Rounded.AutoAwesome) { Updater.dismissWhatsNew() }
            Spacer(Modifier.height(14.dp))
        }
        ConfettiBurst(Modifier.fillMaxSize(), 0.5f, 0.14f, 46, 1800)
    }
}

@Composable
private fun HighlightCard(index: Int, h: Highlight) {
    val prog = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(520L + index * 170L)
        prog.animateTo(1f, spring(dampingRatio = 0.62f, stiffness = 180f))
    }
    val pair = tilePairs[index % tilePairs.size]
    val t = rememberInfiniteTransition(label = "hc$index")
    val glow by t.animateFloat(
        0.25f, 0.85f,
        infiniteRepeatable(tween(1800 + index * 220, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glow"
    )
    val shape = RoundedCornerShape(22.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .graphicsLayer {
                alpha = prog.value.coerceIn(0f, 1f)
                translationX = (1f - prog.value) * 140f
                val s = 0.92f + 0.08f * prog.value.coerceIn(0f, 1f)
                scaleX = s
                scaleY = s
            }
            .clip(shape)
            .background(Glass)
            .border(BorderStroke(1.dp, pair.first.copy(alpha = glow * 0.6f)), shape)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(17.dp))
                .background(Brush.linearGradient(listOf(pair.first, pair.second))),
            contentAlignment = Alignment.Center
        ) { Icon(iconFor(h.icon), null, tint = Color.White, modifier = Modifier.size(27.dp)) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(h.title, color = TextHi, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            if (h.desc.isNotBlank()) {
                Spacer(Modifier.height(2.dp))
                Text(h.desc, color = TextLo, fontSize = 13.sp)
            }
        }
    }
}

// ============================================================ settings card

@Composable
fun UpdateSettingsCard() {
    val ctx = LocalContext.current
    val st = Updater.state
    val pending = st is UpdateState.Available || st is UpdateState.Downloading ||
        st is UpdateState.Ready || st is UpdateState.Installing || st is UpdateState.Failed
    val name = infoOf(st)?.versionName ?: ""
    val status = when (st) {
        is UpdateState.Checking -> "Checking for updates…"
        is UpdateState.Available -> "Version $name is available"
        is UpdateState.Downloading -> {
            val pct = if (st.total > 0) (st.done * 100 / st.total).toInt() else 0
            "Downloading version $name… $pct%"
        }
        is UpdateState.Ready -> "Version $name is ready to install"
        is UpdateState.Installing -> "Installing version $name…"
        is UpdateState.Failed -> st.message
        else -> Updater.lastMessage ?: ("TubeVault v" + BuildConfig.VERSION_NAME)
    }
    val t = rememberInfiniteTransition(label = "usc")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(1100, easing = LinearEasing)), label = "usp")
    val checking = st is UpdateState.Checking

    GlassCard(Modifier.fillMaxWidth(), corner = 20.dp, borderColor = if (pending) Pink.copy(alpha = 0.6f) else GlassBorder) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (pending) AccentBrush else Brush.linearGradient(listOf(Glass, Glass))),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Rounded.Update, null, tint = if (pending) Color.White else TextLo,
                    modifier = Modifier.graphicsLayer { rotationZ = if (checking) spin else 0f }
                )
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("App updates", color = TextHi, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(2.dp))
                Text(status, color = if (st is UpdateState.Failed) Pink else TextLo, fontSize = 12.sp)
            }
            Spacer(Modifier.width(10.dp))
            if (pending) {
                PillButton(Icons.Rounded.Update, "View", true) { Updater.sheetOpen = true }
            } else if (!checking) {
                PillButton(Icons.Rounded.Refresh, "Check", false) { Updater.checkAsync(ctx, true) }
            }
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(GlassBorder)
        )
        Row(
            Modifier
                .fillMaxWidth()
                .clickable { Updater.showWhatsNew(ctx) }
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.AutoAwesome, null, tint = Orange, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(10.dp))
            Text("See what's new in this version", color = TextHi, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        }
    }
}
