package com.raja.tubevault.core

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.Request
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import kotlin.coroutines.coroutineContext
import kotlin.math.abs

// ============================================================================ Whisper models

data class WhisperModel(val key: String, val label: String, val file: String, val approxMb: Int, val preset: Int)

object WhisperModels {
    /** quantised (q5_1) multilingual models: much smaller than the originals, almost the same accuracy */
    val all = listOf(
        WhisperModel("tiny", "Fast", "ggml-tiny-q5_1.bin", 31, 0),
        WhisperModel("base", "Balanced", "ggml-base-q5_1.bin", 57, 1),
        WhisperModel("small", "Best", "ggml-small-q5_1.bin", 181, 2)
    )

    private const val BASE_URL = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/"

    fun file(ctx: Context, m: WhisperModel): File =
        File(File(ctx.applicationContext.filesDir, "whisper").also { it.mkdirs() }, m.file)

    fun isReady(ctx: Context, m: WhisperModel): Boolean {
        val f = file(ctx, m)
        return f.exists() && f.length() > 10L * 1024 * 1024
    }

    /** Downloads the model once (HTTPS, with a real progress value). */
    suspend fun ensure(ctx: Context, m: WhisperModel, onProgress: (Float) -> Unit) = withContext(Dispatchers.IO) {
        if (isReady(ctx, m)) return@withContext
        val dest = file(ctx, m)
        val part = File(dest.parentFile, dest.name + ".part")
        val req = Request.Builder().url(BASE_URL + m.file).header("User-Agent", "TubeVault").build()
        try {
            Net.client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) throw IOException("Model download failed (HTTP ${resp.code})")
                val body = resp.body ?: throw IOException("Model download returned nothing")
                val total = body.contentLength()
                var done = 0L
                body.byteStream().use { input ->
                    FileOutputStream(part).use { output ->
                        val buf = ByteArray(128 * 1024)
                        var lastReport = 0L
                        while (true) {
                            coroutineContext.ensureActive()
                            val n = input.read(buf)
                            if (n < 0) break
                            output.write(buf, 0, n)
                            done += n
                            val now = System.currentTimeMillis()
                            if (now - lastReport > 150) {
                                lastReport = now
                                onProgress(if (total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else -1f)
                            }
                        }
                    }
                }
            }
            // a real ggml model starts with the bytes "lmgg"; anything else is an error page
            val magic = ByteArray(4)
            part.inputStream().use { it.read(magic) }
            if (String(magic, Charsets.ISO_8859_1) != "lmgg" || part.length() < 10L * 1024 * 1024) {
                throw IOException("The downloaded speech model is not valid. Check your connection and try again.")
            }
            if (dest.exists()) dest.delete()
            if (!part.renameTo(dest)) throw IOException("Couldn't save the speech model")
            onProgress(1f)
        } catch (t: Throwable) {
            part.delete()
            throw t
        }
    }
}

// ============================================================================ synced lyrics from LRCLIB (optional)

object Lrclib {
    private fun clean(s: String): String = s
        .replace(Regex("""[\(\[][^)\]]*[)\]]"""), " ")
        .replace(Regex("""(?i)\b(official|video|audio|lyrics?|lyrical|music|full song|hd|hq|4k|remastered|visualizer)\b"""), " ")
        .replace(Regex("""(?i)\s*-\s*topic$"""), "")
        .replace(Regex("""(?i)vevo$"""), "")
        .substringBefore("|")
        .replace(Regex("\\s+"), " ")
        .trim()

    /** @return the raw .lrc text of the best match, or null */
    suspend fun find(title: String, uploader: String, durationMs: Long): String? = withContext(Dispatchers.IO) {
        val t = clean(title)
        val queries = LinkedHashSet<String>()
        if (t.isNotEmpty()) queries.add(t)
        if (t.contains(" - ")) {
            val song = t.substringAfter(" - ").trim()
            val who = t.substringBefore(" - ").trim()
            if (song.isNotEmpty()) queries.add("$who $song")
            if (song.isNotEmpty()) queries.add(song)
        } else if (t.isNotEmpty()) {
            val up = clean(uploader)
            if (up.isNotEmpty()) queries.add("$up $t")
        }
        for (q in queries.take(3)) {
            coroutineContext.ensureActive()
            val url = "https://lrclib.net/api/search".toHttpUrl().newBuilder().addQueryParameter("q", q).build()
            val req = Request.Builder().url(url).header("User-Agent", "TubeVault (Android)").build()
            val text = try {
                Net.client.newCall(req).execute().use { r -> if (r.isSuccessful) r.body?.string() else null }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Throwable) {
                null
            } ?: continue
            val arr = try {
                JSONArray(text)
            } catch (_: Throwable) {
                continue
            }
            var best: String? = null
            var bestDiff = Long.MAX_VALUE
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                if (o.optBoolean("instrumental", false)) continue
                if (o.isNull("syncedLyrics")) continue
                val synced = o.optString("syncedLyrics", "")
                if (synced.isBlank()) continue
                val d = (o.optDouble("duration", 0.0) * 1000.0).toLong()
                val diff = if (durationMs > 0 && d > 0) abs(d - durationMs) else 0L
                if (durationMs > 0 && d > 0 && diff > 5000L) continue // a different recording
                if (diff < bestDiff) {
                    bestDiff = diff
                    best = synced
                }
            }
            if (best != null) return@withContext best
        }
        null
    }
}

// ============================================================================ the karaoke engine

enum class KStatus { IDLE, DECODING, MODEL, TRANSCRIBING, FETCHING, READY, FAILED }

/**
 * Holds everything the karaoke screen shows. One song is processed at a time, in the background
 * (the job keeps running when you leave the player screen). Finished lyrics are saved, so a song
 * is only transcribed once.
 */
object Karaoke {
    /** karaoke stage visible instead of the spinning disc */
    var stageOn by mutableStateOf(false)

    var forId by mutableStateOf("")
        private set
    var status by mutableStateOf(KStatus.IDLE)
        private set
    var progress by mutableFloatStateOf(0f)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var timeline by mutableStateOf<List<LyricLine>>(emptyList())
        private set
    var lineCount by mutableIntStateOf(0)
        private set
    var source by mutableStateOf("")
        private set
    var offsetMs by mutableLongStateOf(0L)
        private set

    /** song being processed right now (may differ from [forId] if you skipped to another song) */
    var busyId by mutableStateOf<String?>(null)
        private set

    var modelIndex by mutableIntStateOf(1)
        private set
    var language by mutableStateOf("auto")
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private var prefsLoaded = false

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("tubevault_karaoke", Context.MODE_PRIVATE)

    private fun loadPrefs(ctx: Context) {
        if (prefsLoaded) return
        prefsLoaded = true
        val p = prefs(ctx)
        modelIndex = p.getInt("model", 1).coerceIn(0, WhisperModels.all.lastIndex)
        language = p.getString("lang", "auto") ?: "auto"
    }

    fun chooseModel(ctx: Context, i: Int) {
        modelIndex = i.coerceIn(0, WhisperModels.all.lastIndex)
        prefs(ctx).edit().putInt("model", modelIndex).apply()
    }

    fun chooseLanguage(ctx: Context, code: String) {
        language = code
        prefs(ctx).edit().putString("lang", code).apply()
    }

    private fun offsetKey(id: String) = "off_" + Integer.toHexString(id.hashCode())

    fun setOffset(ctx: Context, id: String, ms: Long) {
        offsetMs = ms.coerceIn(-5000L, 5000L)
        prefs(ctx).edit().putLong(offsetKey(id), offsetMs).apply()
    }

    private fun showDoc(ctx: Context, id: String, doc: LyricsDoc) {
        forId = id
        timeline = LyricsTimeline.withBreaks(doc.lines)
        lineCount = doc.lines.size
        source = when {
            doc.source.startsWith("whisper-") -> "Whisper " + doc.source.removePrefix("whisper-")
            doc.source == "lrclib" -> "LRCLIB"
            else -> doc.source
        }
        offsetMs = prefs(ctx).getLong(offsetKey(id), 0L)
        error = null
        progress = 1f
        status = KStatus.READY
    }

    /** Call whenever the song changes: shows saved lyrics, or the "create lyrics" state. */
    fun select(ctx: Context, item: DownloadItem) {
        loadPrefs(ctx)
        val doc = LyricsStore.load(ctx, item.id)
        if (doc != null) {
            showDoc(ctx, item.id, doc)
            return
        }
        forId = item.id
        timeline = emptyList()
        lineCount = 0
        source = ""
        offsetMs = prefs(ctx).getLong(offsetKey(item.id), 0L)
        if (busyId == item.id) { // still working on this very song: show its live progress
            error = null
            status = jobStatus
            progress = jobProgress
            return
        }
        error = null
        progress = 0f
        status = KStatus.IDLE
    }

    // what the running job is doing (so the screen can pick it up again if you leave and come back)
    private var jobStatus = KStatus.IDLE
    private var jobProgress = 0f

    private fun setState(id: String, s: KStatus, p: Float) {
        if (busyId == id) {
            jobStatus = s
            jobProgress = p
        }
        if (forId == id) {
            status = s
            progress = p
        }
    }

    private fun fail(id: String, msg: String) {
        if (forId == id) {
            error = msg
            status = KStatus.FAILED
        }
    }

    private fun finish(ctx: Context, id: String, doc: LyricsDoc) {
        LyricsStore.save(ctx, id, doc)
        if (forId == id) showDoc(ctx, id, doc)
    }

    fun cancel() {
        job?.cancel()
        WhisperNative.nativeAbortSafe()
    }

    fun reset(ctx: Context, item: DownloadItem) {
        LyricsStore.delete(ctx, item.id)
        if (forId == item.id) {
            timeline = emptyList()
            lineCount = 0
            error = null
            progress = 0f
            status = KStatus.IDLE
        }
    }

    // ------------------------------------------------------------ Whisper (on-device)

    fun startWhisper(ctx: Context, item: DownloadItem) {
        loadPrefs(ctx)
        val app = ctx.applicationContext
        if (busyId != null) return
        val id = item.id
        val uri = item.uri?.let { Uri.parse(it) }
        forId = id
        error = null
        if (uri == null) {
            fail(id, "This song has no file to read.")
            return
        }
        if (!WhisperNative.available()) {
            fail(id, "The on-device speech engine could not start on this phone (it needs a 64-bit ARM phone).")
            return
        }
        val model = WhisperModels.all[modelIndex]
        val lang = language
        busyId = id
        setState(id, KStatus.DECODING, 0f)
        job = scope.launch {
            var handle = 0L
            try {
                var pcm: FloatArray? = AudioDecoder.decode16kMono(app, uri) { p -> setState(id, KStatus.DECODING, p * 0.1f) }
                if (!WhisperModels.isReady(app, model)) {
                    setState(id, KStatus.MODEL, 0f)
                    WhisperModels.ensure(app, model) { p -> setState(id, KStatus.MODEL, p) }
                }
                coroutineContext.ensureActive()
                setState(id, KStatus.TRANSCRIBING, 0.1f)
                val threads = (Runtime.getRuntime().availableProcessors() - 2).coerceIn(2, 4)
                val raw = withContext(Dispatchers.Default) {
                    handle = WhisperNative.nativeInit(WhisperModels.file(app, model).absolutePath, model.preset)
                    if (handle == 0L) throw IOException("Couldn't load the speech model")
                    val samples = pcm!!
                    pcm = null
                    WhisperNative.nativeTranscribe(handle, samples, lang, threads, object : WhisperProgress {
                        override fun onProgress(percent: Int) {
                            setState(id, KStatus.TRANSCRIBING, 0.1f + 0.9f * (percent / 100f))
                        }
                    })
                }
                coroutineContext.ensureActive()
                if (raw == null) throw IOException("Transcription stopped")
                val lines = WhisperParser.parse(raw)
                if (lines.isEmpty()) {
                    fail(id, "No singing was recognised. Try picking the language yourself, or the Best model.")
                } else {
                    finish(app, id, LyricsDoc("whisper-" + model.key, lang, lines))
                }
            } catch (e: CancellationException) {
                setState(id, KStatus.IDLE, 0f)
            } catch (e: OutOfMemoryError) {
                fail(id, "Not enough memory for this model. Try the Fast model.")
            } catch (e: AudioDecoder.TooLongException) {
                fail(id, "Songs longer than 15 minutes aren't supported yet.")
            } catch (e: Throwable) {
                fail(id, e.message?.takeIf { it.isNotBlank() } ?: "Couldn't create lyrics for this song.")
            } finally {
                if (handle != 0L) WhisperNative.nativeFree(handle)
                busyId = null
            }
        }
    }

    // ------------------------------------------------------------ synced lyrics from the internet (optional)

    fun startOnline(ctx: Context, item: DownloadItem, durationMs: Long) {
        loadPrefs(ctx)
        val app = ctx.applicationContext
        if (busyId != null) return
        val id = item.id
        forId = id
        error = null
        busyId = id
        setState(id, KStatus.FETCHING, -1f)
        job = scope.launch {
            try {
                val text = Lrclib.find(item.title, item.uploader, durationMs)
                if (text == null) {
                    fail(id, "No synced lyrics were found online for this song. Try creating them with Whisper.")
                } else {
                    val lines = LrcParser.parse(text, durationMs)
                    if (lines.isEmpty()) fail(id, "The online lyrics could not be read.")
                    else finish(app, id, LyricsDoc("lrclib", "auto", lines))
                }
            } catch (e: CancellationException) {
                setState(id, KStatus.IDLE, 0f)
            } catch (e: Throwable) {
                fail(id, "Couldn't reach the lyrics service. Check your connection.")
            } finally {
                busyId = null
            }
        }
    }
}
