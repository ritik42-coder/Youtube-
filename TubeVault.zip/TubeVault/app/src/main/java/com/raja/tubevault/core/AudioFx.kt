package com.raja.tubevault.core

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Visualizer
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Everything that listens to (and shapes) the sound of the player:
 *
 *  - [bands] – 32 live spectrum values taken from the real audio output, so the
 *    bars on the player move with the song instead of with a sine wave,
 *  - a studio equaliser with presets (Flat / Bass / Vocal / Rock / DJ / Night),
 *  - a bass boost.
 *
 * All of it is attached to the ExoPlayer audio session, so it also keeps working
 * while the screen is off.
 */
object AudioFx {

    const val BANDS = 32

    /** Names shown in the sound panel. */
    val PRESETS = listOf("Flat", "Bass", "Vocal", "Rock", "DJ", "Night")

    /** Gain per preset, low -> high, in the range -1 .. 1. */
    private val GAINS = arrayOf(
        floatArrayOf(0.00f, 0.00f, 0.00f, 0.00f, 0.00f),
        floatArrayOf(0.95f, 0.60f, 0.10f, -0.05f, -0.10f),
        floatArrayOf(-0.35f, -0.05f, 0.55f, 0.60f, 0.20f),
        floatArrayOf(0.60f, 0.30f, -0.20f, 0.45f, 0.60f),
        floatArrayOf(1.00f, 0.75f, -0.10f, 0.35f, 0.85f),
        floatArrayOf(-0.30f, 0.05f, 0.45f, 0.25f, -0.20f)
    )

    private val spectrum = FloatArray(BANDS)

    @Volatile
    var hasVisualizer: Boolean = false
        private set

    var preset: Int = 0
        private set

    /** 0 .. 100 */
    var bass: Int = 0
        private set

    private var app: Context? = null
    private var session = 0
    private var viz: Visualizer? = null
    private var eq: Equalizer? = null
    private var boost: BassBoost? = null

    /** The array the UI reads every frame. Contents change on the audio thread. */
    fun bands(): FloatArray = spectrum

    fun init(ctx: Context) {
        if (app != null) return
        app = ctx.applicationContext
        val sp = ctx.getSharedPreferences("tubevault_audio", Context.MODE_PRIVATE)
        preset = sp.getInt("preset", 0).coerceIn(0, PRESETS.size - 1)
        bass = sp.getInt("bass", 0).coerceIn(0, 100)
    }

    // ------------------------------------------------------------------ session

    @Synchronized
    fun attach(sessionId: Int) {
        if (sessionId <= 0) return
        if (sessionId == session && (viz != null || eq != null)) return
        releaseEffects()
        session = sessionId
        openVisualizer(sessionId)
        openShaping(sessionId)
    }

    @Synchronized
    fun detach() {
        releaseEffects()
        session = 0
        for (i in spectrum.indices) spectrum[i] = 0f
    }

    private fun releaseEffects() {
        val v = viz
        if (v != null) {
            try {
                v.enabled = false
                v.release()
            } catch (_: Throwable) {
            }
        }
        viz = null
        val e = eq
        if (e != null) {
            try {
                e.enabled = false
                e.release()
            } catch (_: Throwable) {
            }
        }
        eq = null
        val b = boost
        if (b != null) {
            try {
                b.enabled = false
                b.release()
            } catch (_: Throwable) {
            }
        }
        boost = null
        hasVisualizer = false
    }

    // --------------------------------------------------------------- visualiser

    private fun openVisualizer(sessionId: Int) {
        val c = app ?: return
        if (ContextCompat.checkSelfPermission(c, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) return
        try {
            val v = Visualizer(sessionId)
            val range = Visualizer.getCaptureSizeRange()
            val size = if (range.size > 1) range[1] else 1024
            v.captureSize = size
            v.setDataCaptureListener(
                object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(
                        visualizer: Visualizer?, waveform: ByteArray?, samplingRate: Int
                    ) = Unit

                    override fun onFftDataCapture(
                        visualizer: Visualizer?, fft: ByteArray?, samplingRate: Int
                    ) {
                        if (fft != null) feed(fft)
                    }
                },
                Visualizer.getMaxCaptureRate() / 2,
                false,
                true
            )
            v.enabled = true
            viz = v
            hasVisualizer = true
        } catch (_: Throwable) {
            viz = null
            hasVisualizer = false
        }
    }

    /** Turns the raw FFT into 32 smooth, log-spaced bars. Runs on the audio thread. */
    private fun feed(fft: ByteArray) {
        val bins = fft.size / 2
        if (bins < 8) return
        for (b in 0 until BANDS) {
            val lo = max(1, bins.toDouble().pow(b.toDouble() / BANDS).toInt())
            val hi = max(lo + 1, bins.toDouble().pow((b + 1).toDouble() / BANDS).toInt())
            var peak = 0f
            var i = lo
            while (i < hi && i < fft.size) {
                val m = abs(fft[i].toInt()).toFloat() / 128f
                if (m > peak) peak = m
                i++
            }
            val v = peak.coerceIn(0f, 1f)
            // fast attack, slow release, so the bars punch and then settle
            spectrum[b] = if (v > spectrum[b]) v else spectrum[b] * 0.80f
        }
    }

    // ---------------------------------------------------------------- shaping

    private fun openShaping(sessionId: Int) {
        try {
            val e = Equalizer(0, sessionId)
            eq = e
        } catch (_: Throwable) {
            eq = null
        }
        try {
            val b = BassBoost(0, sessionId)
            boost = b
        } catch (_: Throwable) {
            boost = null
        }
        apply()
    }

    fun setPreset(index: Int) {
        preset = index.coerceIn(0, PRESETS.size - 1)
        app?.getSharedPreferences("tubevault_audio", Context.MODE_PRIVATE)
            ?.edit()?.putInt("preset", preset)?.apply()
        apply()
    }

    fun setBass(level: Int) {
        bass = level.coerceIn(0, 100)
        app?.getSharedPreferences("tubevault_audio", Context.MODE_PRIVATE)
            ?.edit()?.putInt("bass", bass)?.apply()
        apply()
    }

    private fun apply() {
        val e = eq
        if (e != null) {
            try {
                val range = e.bandLevelRange
                val min = range[0].toInt()
                val maxL = range[1].toInt()
                val gains = GAINS[preset.coerceIn(0, GAINS.size - 1)]
                val n = e.numberOfBands.toInt()
                for (i in 0 until n) {
                    val pos = if (n <= 1) 0f else i.toFloat() / (n - 1)
                    val g = lerpGain(gains, pos)
                    val level = (g * if (g >= 0f) maxL else -min).roundToInt()
                    e.setBandLevel(i.toShort(), level.coerceIn(min, maxL).toShort())
                }
                e.enabled = true
            } catch (_: Throwable) {
            }
        }
        val b = boost
        if (b != null) {
            try {
                b.setStrength((bass * 10).toShort())
                b.enabled = bass > 0
            } catch (_: Throwable) {
            }
        }
    }

    private fun lerpGain(gains: FloatArray, pos: Float): Float {
        if (gains.isEmpty()) return 0f
        val x = pos.coerceIn(0f, 1f) * (gains.size - 1)
        val i = x.toInt().coerceIn(0, gains.size - 1)
        val j = (i + 1).coerceAtMost(gains.size - 1)
        val f = x - i
        return gains[i] * (1f - f) + gains[j] * f
    }
}
