@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.raja.tubevault.core

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh

// ============================================================================ settings

/** A sound preset: 5 EQ bands (dB) + effect amounts. */
data class FxPreset(
    val name: String,
    val eq: List<Float>,
    val bass: Float = 0f,
    val width: Float = 0f,
    val reverb: Float = 0f,
    val echo: Float = 0f,
    val spin8d: Boolean = false,
    val dj: Float = 0f
)

/** All sound-lab settings. Compose state, read directly by the audio thread. */
object Fx {
    val BAND_HZ = floatArrayOf(60f, 230f, 910f, 3600f, 14000f)
    val BAND_LABELS = listOf("60", "230", "910", "3.6k", "14k")

    var eq by mutableStateOf(listOf(0f, 0f, 0f, 0f, 0f))
    var bass by mutableFloatStateOf(0f)
    var width by mutableFloatStateOf(0f)
    var reverb by mutableFloatStateOf(0f)
    var echo by mutableFloatStateOf(0f)
    var spin8d by mutableStateOf(false)
    var dj by mutableFloatStateOf(0f)
    /** volume boost above 100%: 0..1 -> up to +12 dB */
    var boost by mutableFloatStateOf(0f)
    var preset by mutableStateOf("Flat")
    var enabled by mutableStateOf(true)

    // hold-to-trigger DJ pads (momentary)
    var padBass by mutableStateOf(false)
    var padEcho by mutableStateOf(false)
    var padWash by mutableStateOf(false)

    var version by mutableIntStateOf(0)

    val presets = listOf(
        FxPreset("Flat", listOf(0f, 0f, 0f, 0f, 0f)),
        FxPreset("Bass Boost", listOf(6f, 3f, 0f, 0f, 0f), bass = 0.7f),
        FxPreset("Club DJ", listOf(5f, 2f, -1f, 3f, 5f), bass = 0.55f, width = 0.35f, reverb = 0.15f),
        FxPreset("Vocal", listOf(-3f, -1f, 3f, 4f, 1f)),
        FxPreset("Treble", listOf(-2f, 0f, 0f, 4f, 7f)),
        FxPreset("Rock", listOf(4f, 2f, -2f, 3f, 4f), width = 0.15f),
        FxPreset("Lo-Fi", listOf(2f, 3f, 1f, -5f, -9f)),
        FxPreset("8D Party", listOf(2f, 0f, 0f, 1f, 2f), bass = 0.3f, width = 0.4f, reverb = 0.3f, spin8d = true),
        FxPreset("Concert", listOf(1f, 0f, 1f, 2f, 3f), width = 0.6f, reverb = 0.5f),
        FxPreset("Slowed Reverb", listOf(3f, 1f, 0f, -2f, -4f), bass = 0.3f, width = 0.3f, reverb = 0.75f)
    )

    fun apply(p: FxPreset) {
        eq = p.eq; bass = p.bass; width = p.width; reverb = p.reverb
        echo = p.echo; spin8d = p.spin8d; dj = p.dj; preset = p.name
        touch()
    }

    fun setBand(i: Int, db: Float) {
        eq = eq.toMutableList().also { it[i] = db.coerceIn(-12f, 12f) }
        preset = "Custom"
        touch()
    }

    fun touch() {
        version++
    }

    fun isNeutral(): Boolean =
        eq.all { abs(it) < 0.05f } && bass < 0.01f && width < 0.01f && reverb < 0.01f &&
            echo < 0.01f && !spin8d && abs(dj) < 0.02f && boost < 0.005f &&
            !padBass && !padEcho && !padWash

    // ---------------------------------------------------------------- persistence
    private fun sp(c: Context) = c.getSharedPreferences("tubevault_fx", Context.MODE_PRIVATE)

    fun load(c: Context) {
        try {
            val s = sp(c)
            val e = s.getString("eq", null)?.split(",")?.mapNotNull { it.toFloatOrNull() }
            if (e != null && e.size == 5) eq = e
            bass = s.getFloat("bass", 0f); width = s.getFloat("width", 0f)
            reverb = s.getFloat("reverb", 0f); echo = s.getFloat("echo", 0f)
            spin8d = s.getBoolean("spin", false); dj = 0f
            preset = s.getString("preset", "Flat") ?: "Flat"
            enabled = s.getBoolean("enabled", true)
            touch()
        } catch (_: Throwable) {
        }
    }

    fun save(c: Context) {
        try {
            sp(c).edit()
                .putString("eq", eq.joinToString(","))
                .putFloat("bass", bass).putFloat("width", width)
                .putFloat("reverb", reverb).putFloat("echo", echo)
                .putBoolean("spin", spin8d).putString("preset", preset)
                .putBoolean("enabled", enabled)
                .apply()
        } catch (_: Throwable) {
        }
    }
}

// ============================================================================ visual data

/**
 * Real spectrum of what is actually being played. The audio thread pushes timestamped
 * frames; the UI reads the frame that matches what you are hearing right now
 * (output latency compensated).
 */
object Viz {
    const val BANDS = 32
    private const val RING = 48
    private val ring = Array(RING) { FloatArray(BANDS + 2) }   // bands..., level, bass
    private val stamp = LongArray(RING)

    @Volatile
    private var head = 0

    /** how long audio takes from our tap to your ears */
    @Volatile
    var latencyMs = 170L

    fun push(bands: FloatArray, level: Float, bass: Float, atNanos: Long) {
        val i = (head + 1) % RING
        val r = ring[i]
        System.arraycopy(bands, 0, r, 0, BANDS)
        r[BANDS] = level
        r[BANDS + 1] = bass
        stamp[i] = atNanos
        head = i
    }

    /** Fills [out] (BANDS + 2 floats). Returns false when nothing is playing. */
    fun read(out: FloatArray): Boolean {
        val now = System.nanoTime()
        val want = now - latencyMs * 1_000_000L
        val h = head
        for (k in 0 until RING) {
            val i = (h - k + RING) % RING
            val s = stamp[i]
            if (s == 0L) continue
            if (s <= want) {
                if (want - s > 450_000_000L) return false
                System.arraycopy(ring[i], 0, out, 0, BANDS + 2)
                return true
            }
        }
        return false
    }
}

// ============================================================================ DSP bits

private class Biq {
    var b0 = 1f; var b1 = 0f; var b2 = 0f; var a1 = 0f; var a2 = 0f
    var z1 = 0f; var z2 = 0f

    fun proc(x: Float): Float {
        val y = b0 * x + z1
        z1 = b1 * x - a1 * y + z2
        z2 = b2 * x - a2 * y
        return y
    }

    private fun set(nb0: Float, nb1: Float, nb2: Float, a0: Float, na1: Float, na2: Float) {
        b0 = nb0 / a0; b1 = nb1 / a0; b2 = nb2 / a0; a1 = na1 / a0; a2 = na2 / a0
    }

    fun identity() { b0 = 1f; b1 = 0f; b2 = 0f; a1 = 0f; a2 = 0f }

    fun peaking(fs: Float, f0: Float, db: Float, q: Float) {
        val a = 10f.pow(db / 40f)
        val w = 2f * PI.toFloat() * f0 / fs
        val al = sin(w) / (2f * q)
        val c = cos(w)
        set(1f + al * a, -2f * c, 1f - al * a, 1f + al / a, -2f * c, 1f - al / a)
    }

    fun lowShelf(fs: Float, f0: Float, db: Float) {
        val a = 10f.pow(db / 40f)
        val w = 2f * PI.toFloat() * f0 / fs
        val c = cos(w)
        val al = sin(w) / 2f * 1.41421356f
        val sa = sqrt(a)
        set(
            a * ((a + 1f) - (a - 1f) * c + 2f * sa * al),
            2f * a * ((a - 1f) - (a + 1f) * c),
            a * ((a + 1f) - (a - 1f) * c - 2f * sa * al),
            (a + 1f) + (a - 1f) * c + 2f * sa * al,
            -2f * ((a - 1f) + (a + 1f) * c),
            (a + 1f) + (a - 1f) * c - 2f * sa * al
        )
    }

    fun lowPass(fs: Float, f0: Float, q: Float) {
        val w = 2f * PI.toFloat() * f0 / fs
        val c = cos(w)
        val al = sin(w) / (2f * q)
        set((1f - c) / 2f, 1f - c, (1f - c) / 2f, 1f + al, -2f * c, 1f - al)
    }

    fun highPass(fs: Float, f0: Float, q: Float) {
        val w = 2f * PI.toFloat() * f0 / fs
        val c = cos(w)
        val al = sin(w) / (2f * q)
        set((1f + c) / 2f, -(1f + c), (1f + c) / 2f, 1f + al, -2f * c, 1f - al)
    }
}

private class Comb(size: Int) {
    private val buf = FloatArray(max(size, 8))
    private var i = 0
    private var store = 0f
    fun proc(x: Float, fb: Float, damp: Float): Float {
        val o = buf[i]
        store = o * (1f - damp) + store * damp
        buf[i] = x + store * fb
        if (++i >= buf.size) i = 0
        return o
    }
}

private class AllPass(size: Int) {
    private val buf = FloatArray(max(size, 8))
    private var i = 0
    fun proc(x: Float): Float {
        val b = buf[i]
        val o = -x + b
        buf[i] = x + b * 0.5f
        if (++i >= buf.size) i = 0
        return o
    }
}

private class Delay(size: Int) {
    private val buf = FloatArray(max(size, 8))
    private var i = 0
    fun read(): Float = buf[i]
    fun write(v: Float) {
        buf[i] = v
        if (++i >= buf.size) i = 0
    }
}

// ============================================================================ the processor

/**
 * Sits inside ExoPlayer's audio pipeline: EQ, bass, DJ filter, width, 8D, reverb, echo,
 * soft limiter - and measures the real spectrum for the visualiser.
 */
class FxProcessor : BaseAudioProcessor() {
    private var rate = 44100
    private var chn = 2
    private var seenVersion = -1

    private val eqF = Array(2) { Array(5) { Biq() } }
    private val bassF = Array(2) { Biq() }
    private val djF = Array(2) { Biq() }
    private var djMode = 0

    private var combs: Array<Array<Comb>> = emptyArray()
    private var allp: Array<Array<AllPass>> = emptyArray()
    private var dly: Array<Delay> = emptyArray()
    private var phase8d = 0f

    // locals refreshed per buffer
    private var active = false
    private var preGain = 1f
    private var postGain = 1f
    private var width = 0f
    private var rev = 0f
    private var echo = 0f
    private var spin = false

    // analysis
    private val N = 1024
    private val win = FloatArray(N)
    private val re = FloatArray(N)
    private val im = FloatArray(N)
    private val ring = FloatArray(N)
    private var ringPos = 0
    private var hopCount = 0
    private val bandsOut = FloatArray(Viz.BANDS)
    private val cosT = FloatArray(N / 2)
    private val sinT = FloatArray(N / 2)
    private val bandLo = IntArray(Viz.BANDS)
    private val bandHi = IntArray(Viz.BANDS)

    init {
        for (i in 0 until N) win[i] = (0.5f - 0.5f * cos(2f * PI.toFloat() * i / (N - 1)))
        for (i in 0 until N / 2) {
            cosT[i] = cos(2f * PI.toFloat() * i / N)
            sinT[i] = -sin(2f * PI.toFloat() * i / N)
        }
    }

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT || inputAudioFormat.channelCount !in 1..2) {
            return AudioProcessor.AudioFormat.NOT_SET
        }
        rate = inputAudioFormat.sampleRate
        chn = inputAudioFormat.channelCount
        buildState()
        return inputAudioFormat
    }

    private fun buildState() {
        val k = rate / 44100f
        fun s(n: Int) = (n * k).toInt()
        combs = Array(2) { c ->
            arrayOf(Comb(s(1116 + c * 23)), Comb(s(1188 + c * 23)), Comb(s(1277 + c * 23)), Comb(s(1356 + c * 23)))
        }
        allp = Array(2) { c -> arrayOf(AllPass(s(556 + c * 23)), AllPass(s(441 + c * 23))) }
        dly = Array(2) { Delay((rate * (0.30f + it * 0.04f)).toInt()) }
        for (c in 0 until 2) {
            for (f in eqF[c]) { f.z1 = 0f; f.z2 = 0f }
            bassF[c].z1 = 0f; bassF[c].z2 = 0f
            djF[c].z1 = 0f; djF[c].z2 = 0f
        }
        // log-spaced analyser bands 35 Hz .. 16 kHz
        val lo = 35f
        val hi = min(16000f, rate / 2f - 100f)
        for (b in 0 until Viz.BANDS) {
            val f0 = lo * (hi / lo).pow(b / Viz.BANDS.toFloat())
            val f1 = lo * (hi / lo).pow((b + 1) / Viz.BANDS.toFloat())
            val b0 = (f0 * N / rate).toInt().coerceIn(1, N / 2 - 1)
            val b1 = (f1 * N / rate).toInt().coerceIn(b0, N / 2 - 1)
            bandLo[b] = b0; bandHi[b] = b1
        }
        seenVersion = -1
    }

    private fun refresh() {
        val on = Fx.enabled
        val eq = Fx.eq
        val bass = if (Fx.padBass) 1f else Fx.bass
        val dj = Fx.dj
        for (c in 0 until 2) {
            for (b in 0 until 5) {
                val db = if (on) eq[b] else 0f
                if (abs(db) < 0.05f) eqF[c][b].identity()
                else eqF[c][b].peaking(rate.toFloat(), Fx.BAND_HZ[b].coerceAtMost(rate * 0.45f), db, 0.9f)
            }
            if (on && bass > 0.01f) bassF[c].lowShelf(rate.toFloat(), 110f, bass * 13f) else bassF[c].identity()
        }
        djMode = when {
            !on || abs(dj) < 0.02f -> 0
            dj < 0f -> 1
            else -> 2
        }
        if (djMode == 1) {
            val f = 20000f * 0.01f.pow(-dj)
            for (c in 0 until 2) djF[c].lowPass(rate.toFloat(), f.coerceAtMost(rate * 0.45f), 1.1f)
        } else if (djMode == 2) {
            val f = 20f * 300f.pow(dj)
            for (c in 0 until 2) djF[c].highPass(rate.toFloat(), f, 1.1f)
        }
        val maxBoost = max(eq.maxOrNull() ?: 0f, 0f) + bass * 9f
        preGain = if (on) 10f.pow(-maxBoost * 0.55f / 20f) else 1f
        postGain = 10f.pow(Fx.boost * 12f / 20f)
        width = if (on) Fx.width else 0f
        rev = if (on) (if (Fx.padWash) max(Fx.reverb, 0.85f) else Fx.reverb) else 0f
        echo = if (on) (if (Fx.padEcho) max(Fx.echo, 0.7f) else Fx.echo) else 0f
        spin = on && Fx.spin8d
        active = on && (maxBoost > 0.01f || djMode != 0 || width > 0.01f || rev > 0.01f || echo > 0.01f || spin ||
            eq.any { abs(it) > 0.05f })
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val n = inputBuffer.remaining()
        if (n <= 0) return
        val v = Fx.version + (if (Fx.padBass) 1000 else 0) + (if (Fx.padEcho) 2000 else 0) +
            (if (Fx.padWash) 4000 else 0)
        if (v != seenVersion) {
            seenVersion = v
            refresh()
        }
        val out = replaceOutputBuffer(n)
        val frames = n / (2 * chn)
        val t0 = System.nanoTime()
        val doPost = active || postGain > 1.001f
        for (f in 0 until frames) {
            var l = readS(inputBuffer) / 32768f
            var r = if (chn == 2) readS(inputBuffer) / 32768f else l
            if (doPost) {
                if (active) {
                    l *= preGain; r *= preGain
                    for (b in 0 until 5) { l = eqF[0][b].proc(l); r = eqF[1][b].proc(r) }
                    l = bassF[0].proc(l); r = bassF[1].proc(r)
                    if (djMode != 0) { l = djF[0].proc(l); r = djF[1].proc(r) }
                    if (width > 0.01f) {
                        val m = (l + r) * 0.5f
                        val s = (l - r) * 0.5f * (1f + 2.2f * width)
                        l = m + s; r = m - s
                    }
                    if (spin) {
                        phase8d += 2f * PI.toFloat() / (rate * 7f)
                        if (phase8d > 6.2831853f) phase8d -= 6.2831853f
                        val pan = sin(phase8d)
                        val m = (l + r) * 0.5f
                        l = m * sqrt((1f - pan) * 0.5f) * 1.45f
                        r = m * sqrt((1f + pan) * 0.5f) * 1.45f
                    }
                    if (rev > 0.01f) {
                        val inp = (l + r) * 0.5f * 0.3f
                        var wl = 0f; var wr = 0f
                        for (c in 0 until 4) {
                            wl += combs[0][c].proc(inp, 0.84f, 0.25f)
                            wr += combs[1][c].proc(inp, 0.84f, 0.25f)
                        }
                        wl = allp[0][1].proc(allp[0][0].proc(wl))
                        wr = allp[1][1].proc(allp[1][0].proc(wr))
                        l += wl * rev * 0.9f; r += wr * rev * 0.9f
                    }
                    if (echo > 0.01f) {
                        val dl = dly[0].read(); val dr = dly[1].read()
                        dly[0].write(l + dr * 0.38f)
                        dly[1].write(r + dl * 0.38f)
                        l += dl * echo * 0.8f; r += dr * echo * 0.8f
                    }
                }
                l *= postGain; r *= postGain
                l = soft(l); r = soft(r)
            }
            out.put(toB(l, 0)).put(toB(l, 1))
            if (chn == 2) out.put(toB(r, 0)).put(toB(r, 1))
            // ---- analysis (post-FX, what you hear)
            ring[ringPos] = (l + r) * 0.5f
            ringPos = (ringPos + 1) % N
            if (++hopCount >= 512) {
                hopCount = 0
                analyse(t0 + (f.toLong() * 1_000_000_000L / rate))
            }
        }
        out.flip()
    }

    private fun readS(b: ByteBuffer): Float {
        val lo = b.get().toInt() and 0xFF
        val hi = b.get().toInt()
        return ((hi shl 8) or lo).toShort().toFloat()
    }

    private fun toB(x: Float, which: Int): Byte {
        val s = (x.coerceIn(-1f, 1f) * 32767f).toInt()
        return if (which == 0) (s and 0xFF).toByte() else ((s shr 8) and 0xFF).toByte()
    }

    private fun soft(x: Float): Float {
        val a = abs(x)
        if (a < 0.82f) return x
        val y = 0.82f + 0.18f * tanh((a - 0.82f) / 0.18f)
        return if (x < 0f) -y else y
    }

    private fun analyse(atNanos: Long) {
        var sumSq = 0f
        for (i in 0 until N) {
            val x = ring[(ringPos + i) % N]
            re[i] = x * win[i]
            im[i] = 0f
            sumSq += x * x
        }
        fft()
        var bassSum = 0f
        for (b in 0 until Viz.BANDS) {
            var m = 0f
            for (k in bandLo[b]..bandHi[b]) {
                val mag = sqrt(re[k] * re[k] + im[k] * im[k]) / (N / 4f)
                if (mag > m) m = mag
            }
            val db = 20f * log10(m + 1e-7f)
            val v = ((db + 66f) / 52f + b * 0.006f).coerceIn(0f, 1f)
            bandsOut[b] = v
            if (b < 6) bassSum += v
        }
        val level = sqrt(sumSq / N).let { (it * 3.2f).coerceIn(0f, 1f) }
        Viz.push(bandsOut, level, bassSum / 6f, atNanos)
    }

    private fun fft() {
        // bit reversal
        var j = 0
        for (i in 1 until N) {
            var bit = N shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
            }
        }
        var len = 2
        while (len <= N) {
            val half = len / 2
            val step = N / len
            var i = 0
            while (i < N) {
                var k = 0
                for (m in 0 until half) {
                    val wr = cosT[k]; val wi = sinT[k]
                    val a = i + m; val b = a + half
                    val xr = re[b] * wr - im[b] * wi
                    val xi = re[b] * wi + im[b] * wr
                    re[b] = re[a] - xr; im[b] = im[a] - xi
                    re[a] += xr; im[a] += xi
                    k += step
                }
                i += len
            }
            len = len shl 1
        }
    }

    override fun onFlush() {
        for (c in 0 until 2) {
            for (f in eqF[c]) { f.z1 = 0f; f.z2 = 0f }
            bassF[c].z1 = 0f; bassF[c].z2 = 0f
            djF[c].z1 = 0f; djF[c].z2 = 0f
        }
        ring.fill(0f)
        hopCount = 0
    }
}
