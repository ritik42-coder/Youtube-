plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// ---------------------------------------------------------------- signing
// A single, permanent release key lives in the repo (app/tubevault-release.jks).
// Because every build is signed with the same key, a new APK installs straight
// over the old one: no uninstall, no lost downloads, no lost library.
val releaseStore = rootProject.file(
    (project.findProperty("TV_STORE_FILE") as String?) ?: "app/tubevault-release.jks"
)
val hasReleaseKey = releaseStore.exists()

android {
    namespace = "com.raja.tubevault"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.raja.tubevault"
        minSdk = 26
        targetSdk = 34
        // CI passes the workflow run number so every build is installable over the last one.
        versionCode = (System.getenv("TV_VERSION_CODE") ?: "2").toIntOrNull() ?: 2
        versionName = "2.0"
    }

    signingConfigs {
        create("release") {
            if (hasReleaseKey) {
                storeFile = releaseStore
                storeType = "PKCS12"
                storePassword = (project.findProperty("TV_STORE_PASSWORD") as String?) ?: "tubevault2026"
                keyAlias = (project.findProperty("TV_KEY_ALIAS") as String?) ?: "tubevault"
                keyPassword = (project.findProperty("TV_KEY_PASSWORD") as String?) ?: "tubevault2026"
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            // Same key on every build -> updates install over the old app and keep all data.
            signingConfig = if (hasReleaseKey) signingConfigs.getByName("release")
            else signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
    packaging {
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "META-INF/DEPENDENCIES",
                "META-INF/INDEX.LIST",
                "META-INF/LICENSE*",
                "META-INF/NOTICE*"
            )
            pickFirsts += setOf("META-INF/versions/9/OSGI-INF/MANIFEST.MF")
        }
    }
}

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs_nio:2.1.5")

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.1")

    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    // In-app player (Media3 ExoPlayer)
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    // Media session + media-style notification: background / screen-off playback
    implementation("androidx.media3:media3-session:1.4.1")

    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Open-source YouTube extraction engine (same one the NewPipe app uses)
    implementation("com.github.teamnewpipe:NewPipeExtractor:v0.27.1")
}
