plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.raja.tubevault"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.raja.tubevault"
        minSdk = 26
        targetSdk = 34
        // Always going up on GitHub, so every new build installs as an update.
        versionCode = (System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1) + 100
        versionName = "2.5"

        // In-app updater: the GitHub repo that hosts the releases ("owner/repo").
        // GitHub Actions provides it automatically (GITHUB_REPOSITORY), so nothing to configure.
        // For a local build you can pass -PupdateRepo=owner/repo
        val updateRepo = System.getenv("GITHUB_REPOSITORY")
            ?: (project.findProperty("updateRepo") as String?)
            ?: ""
        buildConfigField("String", "UPDATE_REPO", "\"" + updateRepo + "\"")

        // Karaoke mode: whisper.cpp (on-device speech-to-text) is built as a native library.
        // 64-bit ARM only (every modern phone) to keep the APK and build time small.
        ndk {
            abiFilters += setOf("arm64-v8a")
        }
        externalNativeBuild {
            cmake {
                arguments += listOf("-DANDROID_STL=c++_static", "-DCMAKE_BUILD_TYPE=Release")
                cppFlags += "-O3"
            }
        }
    }

    // On GitHub the runner already has an NDK: the workflow passes its version so nothing is downloaded.
    System.getenv("TV_NDK_VERSION")?.takeIf { it.isNotBlank() }?.let { ndkVersion = it }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    // ONE permanent signing key (app/tubevault-release.jks). Same key on every build =
    // the phone treats every new APK as an UPDATE: no uninstall, no lost downloads.
    // Keep this file in your repo forever and never replace it.
    signingConfigs {
        create("tubevault") {
            storeFile = file("tubevault-release.jks")
            storePassword = "tubevault123"
            keyAlias = "tubevault"
            keyPassword = "tubevault123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("tubevault")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
    packaging {
        // The universal engine (Python + yt-dlp + FFmpeg) runs from unpacked native libraries.
        jniLibs {
            useLegacyPackaging = true
        }
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "META-INF/DEPENDENCIES",
                "META-INF/INDEX.LIST",
                "META-INF/LICENSE*",
                "META-INF/NOTICE*"
            )
            pickFirsts += setOf("META-INF/versions/9/OSGI-INF/MANIFEST.MF")
        }
    }
}

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs_nio:2.1.5")

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.1")
    // Private Vault: fingerprint / face unlock
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("androidx.fragment:fragment-ktx:1.8.2")

    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")

    // In-app player (Media3 ExoPlayer)
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    implementation("androidx.media3:media3-session:1.4.1")

    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Open-source YouTube extraction engine (same one the NewPipe app uses)
    implementation("com.github.teamnewpipe:NewPipeExtractor:v0.27.1")

    // Universal engine: yt-dlp for Android (1,800+ sites) + FFmpeg for merging / audio extraction
    implementation("io.github.junkfood02.youtubedl-android:library:0.18.1")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1")
}
